﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PhD.BuildingFuzzyRulesSystem;
using PhD.HA;
using PhD.Common;


namespace PhD.PSO
{
    public class PSOParticle
    {
        public List<float> _pos; //Vị trí của particle. Lưu giá trị của các biến. 
                                //Có ba loại biến fm(c-), uL và kj.
                                //Độ dài của danh sách này là 3*(số thuộc tính).
        public List<float> _vel;    //Velocity của particle
        public List<float> _fbests; //Phương án tốt nhất
        public List<float> _pbests; //Vị trí tốt nhất
        public List<float> _fitness; //Trỏ tới không gian mục tiêu
        public int NumberOfDimention; //Số biến tham gia vào bài toán. Có ba loại biến fm(c-), u(L), kj --> Số biến = 3 * (số thuộc tính)
        public int NumberOfFunction; //Số hàm mục tiêu
        public int SizeOfRepository; // Kích thước của biến lưu trữ
        public IObjectFunction f;           //Lớp chứa hàm mục tiêu
        public FuzzyRulesSystem _bestDomRule; //Trỏ đến hệ luật tốt nhất trong không gian mục tiêu
        public List<float> _noDomFitC;
        public List<float> _noDomFCV;
        public bool _isBestMove;
        private PSOParameters _param;
        public float _evaluationValue;
        public float _evaluMSE;
        public float _evaluMAPE;
        public float _evaluME;
        public HASingleSFISystem HASystem;

        #region properties
        public PSOParameters Params
        {
            get { return _param; }
        }

        #endregion

        public void SetFitness(int i, float fvalue)
        {
            _fitness[i] = fvalue; 
        }

        public float GetFitness(int i)
        {
            return _fitness[i];
        }

        public void SetFBest(int i, float fvalue)
        {
            _fbests[i] = fvalue;
        }

        public float GetFBest(int i)
        {
            return _fbests[i];
        }

        public void SetPBest(int i, float fvalue)
        {
            _pbests[i] = fvalue;
        }

        public float GetPBest(int i)
        {
            return _pbests[i];
        }

        public void SetNonDomFitC(int i, float fvalue)
        {
            _noDomFitC[i] = fvalue;
        }

        public float GetNonDomFitC(int i)
        {
            return _noDomFitC[i];
        }

        public float GetPos(int i)
        {
            return _pos[i];
        }

        public void SetPos(int i, float fvalue)
        {
            _pos[i] = fvalue;
        }

        public float GetVelocity(int i)
        {
            return _vel[i];
        }

        public void SeVelocity(int i, float fvalue)
        {
            _vel[i] = fvalue;
        }

        public PSOParticle(PSOParameters param)
        {
            int j;

            _param = param;
            NumberOfDimention = _param.NumberOfDimension;
            NumberOfFunction = _param.NumberOfFunction;
            SizeOfRepository = _param.SizeOfRepository;
            _isBestMove = false;

            // Khoi tao cac danh sach
            _pos = new List<float>(); 
            _vel = new List<float>();
            _pbests = new List<float>();
            for (j = 0; j < NumberOfDimention; j++)
            {
                _vel.Add(0.0f);
                _pbests.Add(0.0f);
            }

            _fitness = new List<float>();
            _fbests = new List<float>();
            for (j = 0; j < NumberOfFunction; j++)
            {
                _fitness.Add(0.0f);
                _fbests.Add(0.0f);
            }

            _noDomFitC = new List<float>();
            for (j = 0; j < 4; j++)
            {
                _noDomFitC.Add(0.0f);
            }
            _noDomFCV = new List<float>();
        }

        //Hàm tính velocity của particle
        public float velocity(float W, float Vi, float C1, float C2, float r1, float r2, float Pb, float Pg, float Xi)
        {
            return W * Vi + C1 * r1 * MyRandom.Random01() * (Pb - Xi) + C2 * r2 * MyRandom.Random01() * (Pg - Xi);
        }

    }
}
