using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace PhD.PSO
{
    public partial class frmMyProgress : Form
    {
        #region Variable

        private ManualResetEvent _initEvent;
        private ProgressBarStyle _style;
        private Graphics grp;
        private Brush brush;
        private int _percen = -1;

        #endregion

        #region Delegates

        public delegate void eIncrement();
        public delegate void eSetMax(int max);
        public delegate void eSetCaption(string str);
        public delegate void eSetStyle(ProgressBarStyle style);

        #endregion

        #region Implement Interface

        public void SetMax(int MaxValue)
        {
            _initEvent.WaitOne();
            Invoke(new eSetMax(DoSetMax), new object[] { MaxValue });
        }

        public void IncreasePercent()
        {
            Invoke(new eIncrement(DoIncrement));
        }

        public void SetCaption(string strCaption)
        {
            _initEvent.WaitOne();
            Invoke(new eSetCaption(DoSetCaption), new object[] { strCaption });
        }

        public void SetStyle(ProgressBarStyle style)
        {
            _initEvent.WaitOne();
            Invoke(new eSetStyle(DoSetStyle), style);
        }

        public void RestoreStatus()
        { }

        public void SetMessage(string strMessage)
        { }

        #endregion

        #region Methods

        private void DoSetMax(int max)
        {
            progressbar.Maximum = max;
            progressbar.Value = 0;            
        }        

        private void DoIncrement()
        {
            if (progressbar.Value < progressbar.Maximum)
                progressbar.Value += 1;
            int percen = (int)(progressbar.Value * 100.0 / progressbar.Maximum);
            if (_percen != percen)
            {
                progressbar.Invalidate();
                _percen = percen;
            }
            StringFormat sf = new StringFormat();
            sf.Alignment = StringAlignment.Center;
            grp.DrawString(percen + "%", Font, brush, progressbar.Location.X + progressbar.Width / 2, progressbar.Location.Y + progressbar.Height / 2 - 20, sf);
        }

        private void DoSetCaption(string str)
        {
            Text = str;
        }

        private void DoSetStyle(ProgressBarStyle style)
        {
            _style = style;
            progressbar.Style = style;
            grp = progressbar.CreateGraphics();
        }

        public void CloseForm()
        {
            Invoke(new eIncrement(DoClose));
        }

        private void DoClose()
        {
            Close();
        }

        public void SetMarqueeSpeed(int speed)
        {
        }

        #endregion

        #region Form

        public frmMyProgress(ProgressBarStyle style)
        {
            InitializeComponent();
            _initEvent = new ManualResetEvent(false);
            _style = style;
        }

        private void frmProgress_Load(object sender, EventArgs e)
        {
            switch (_style)
            {
                case ProgressBarStyle.Marquee:
                    {
                        progressbar.Style = ProgressBarStyle.Marquee;
                        progressbar.MarqueeAnimationSpeed = 50;
                        progressbar.Step = 2;
                    }
                    break;
                default:
                    {
                        progressbar.Style = ProgressBarStyle.Continuous;
                    }
                    break;
            }
            _initEvent.Set();
            grp = progressbar.CreateGraphics();
            brush = new SolidBrush(ForeColor);
        }

        #endregion       

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}