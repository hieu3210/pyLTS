﻿//Lớp mô tả hệ khoảng tính mờ tương tự mức k
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
namespace PhD.HA
{
   public class HASFISystem
   {
       private byte _k;
       private List<Term> _list_K_Terms;  //Danh sách các hạng từ có độ dài mức k
       private List<Term> _list_K1_Terms; //Danh sách các hạng từ có độ dài mức k+
       private List<HASFI> _listHASFIS;   ////Danh sách các khoảng tính mờ tương tự mức k
       private HedgeAlgebras _ha;

       public byte K_Level
       {
           get { return _k; }
           set 
           {
               _k = value;             
           }
       }
       public HASFI this[int index]
       {
           get
           {
               try
               {
                   return _listHASFIS[index];
               }
               catch (IndexOutOfRangeException ex)
               {
                   throw ex;
               }
           }
       }
       public byte Count
       {
           get { return Convert.ToByte(_listHASFIS.Count); }
       }
       #region Constructor
       public HASFISystem(HedgeAlgebras ha, byte k)
       {
           try
           {
               _k = k;
               _ha = ha;
               _list_K_Terms = new List<Term>();
               _list_K1_Terms = new List<Term>();
               _listHASFIS = new List<HASFI>();             
           }
           catch (AccessViolationException Ex)
           {
               throw Ex;
           }
       }
       #endregion
       //Ham thuc hien sap xep cac tu da duoc sinh trong J theo thu tu dinh luong ngu nghia
        private void Sort_listTermsAtK()
        {
            Term x;
            int i, j;
            for (i = 0; i < _list_K_Terms.Count - 1; i++)
                for (j = i + 1; j < _list_K_Terms.Count(); j++)
                    if (_list_K_Terms[i].Vx > _list_K_Terms[j].Vx)
                    {
                        x = _list_K_Terms[i];
                        _list_K_Terms[i] = _list_K_Terms[j];
                        _list_K_Terms[j] = x;
                    }
        }

        /// <summary>
        /// Hàm tạo ra các hạng từ mức K
        /// </summary>
        /// <returns></returns>
        private void CreateTermsAtK() 
        {
            List<Term> temp1 = new List<Term>();
            List<Term> temp2 = new List<Term>();
            Term t;
            //Khởi tạo các khoảng tính mờ mức 1
            if (_list_K_Terms == null)
                _list_K_Terms = new List<Term>();
            _list_K_Terms.Clear();
            
            t = new Term(TermConstans.C_minus, _ha.Vx(TermConstans.C_minus));
            _list_K_Terms.Add(t);           
            t = new Term(TermConstans.C_plus, _ha.Vx(TermConstans.C_plus));
            _list_K_Terms.Add(t);          
            //Xác định các hạng tử có độ dài  >=2)
            string x1, x2;
            int i, j;
            for (i = 0; i < _list_K_Terms.Count; i++)
                temp1.Add(_list_K_Terms[i]);
            for (i = 2; i <= _k; i++)
            {
                temp2.Clear();
                for (j = 0; j < temp1.Count; j++)
                {
                    x1 = temp1[j].WordX + Hedge.Very;
                    x2 = temp1[j].WordX + Hedge.Little;
                    Term t1 = new Term(x1,_ha.Vx(x1));
                    Term t2 = new Term(x2, _ha.Vx(x2));
                    temp2.Add(t1);
                    temp2.Add(t2);                    
                    _list_K_Terms.Add(t1);
                    _list_K_Terms.Add(t2);
                }
                temp1.Clear();
                for(j=0;j<temp2.Count;j++)
                    temp1.Add(temp2[j]);
            }
            t = new Term(TermConstans.ZERO, 0);
            _list_K_Terms.Add(t);
            t = new Term(TermConstans.W, _ha.FMC_Minus);
            _list_K_Terms.Add(t);
            t = new Term(TermConstans.UNIT, 1);
            _list_K_Terms.Add(t);
            Sort_listTermsAtK();
        }
       //Ham thuc hien sap xep cac tu da duoc sinh trong J theo thu tu dinh luong ngu nghia
        private void Sort_listTermsAtKplus1()
        {
            Term x;
            int i, j;
            for (i = 0; i < _list_K1_Terms.Count - 1; i++)
                for (j = i + 1; j < _list_K1_Terms.Count(); j++)
                    if (_list_K1_Terms[i].Vx > _list_K1_Terms[j].Vx)
                    {
                        x = _list_K1_Terms[i];
                        _list_K1_Terms[i] = _list_K1_Terms[j];
                        _list_K1_Terms[j] = x;
                    }
        }

       /// <summary>
        /// Hàm tạo ra các hạng từ mức K+1
        /// </summary>
        /// <returns></returns>
        private void CreateTermsAtKplus1() 
        {
            List<Term> temp1 = new List<Term>();
            List<Term> temp2 = new List<Term>();
            Term t;
            //Khởi tạo các khoảng tính mờ mức 1
            if (_list_K1_Terms == null)
                _list_K1_Terms = new List<Term>();
            _list_K1_Terms.Clear();
            
            t = new Term(TermConstans.C_minus, _ha.Vx(TermConstans.C_minus));
            _list_K1_Terms.Add(t);           
            t = new Term(TermConstans.C_plus, _ha.Vx(TermConstans.C_plus));
            _list_K1_Terms.Add(t);          
            //Xác định các hạng tử có độ dài  >=2)
            string x1, x2;
            int i, j;
            for (i = 0; i < _list_K1_Terms.Count; i++)
                temp1.Add(_list_K1_Terms[i]);
            for (i = 2; i <= _k+1; i++)
            {
                temp2.Clear();
                for (j = 0; j < temp1.Count; j++)
                {
                    x1 = temp1[j].WordX + Hedge.Very;
                    x2 = temp1[j].WordX + Hedge.Little;
                    Term t1 = new Term(x1,_ha.Vx(x1));
                    Term t2 = new Term(x2, _ha.Vx(x2));
                    temp2.Add(t1);
                    temp2.Add(t2);                    
                    _list_K1_Terms.Add(t1);
                    _list_K1_Terms.Add(t2);
                }
                temp1.Clear();
                for(j=0;j<temp2.Count;j++)
                    temp1.Add(temp2[j]);
            }
            t = new Term(TermConstans.ZERO, 0);
            _list_K1_Terms.Add(t);
            t = new Term(TermConstans.W, _ha.FMC_Minus);
            _list_K1_Terms.Add(t);
            t = new Term(TermConstans.UNIT, 1);
            _list_K1_Terms.Add(t);
            Sort_listTermsAtKplus1();
        }
       /// <summary>
       /// 
       /// </summary>
       public void CreateSFISystem()
       {
           CreateTermsAtK();
           CreateTermsAtKplus1();
           _listHASFIS.Clear();
           for (int i = 0; i < _list_K_Terms.Count; i++)
           {
               if (i == 0)
               {
                   HASFI sfi = new HASFI(_list_K1_Terms[0].Vx, _list_K1_Terms[1].Vx, _list_K_Terms[0].Vx, _list_K_Terms[1].Vx, _list_K_Terms[0].WordX, _list_K_Terms[0].Vx);
                   _listHASFIS.Add(sfi);
               }
               else
                   if (i == _list_K_Terms.Count - 1)
                   {
                       HASFI sfi = new HASFI(_list_K1_Terms[2*i-1].Vx, _list_K1_Terms[2*i].Vx, _list_K_Terms[i-1].Vx, _list_K_Terms[i].Vx, _list_K_Terms[i].WordX, _list_K_Terms[i].Vx);
                       _listHASFIS.Add(sfi);
                   }
                   else
                   {
                       HASFI sfi = new HASFI(_list_K1_Terms[2 * i - 1].Vx, _list_K1_Terms[2 * i+1].Vx, _list_K_Terms[i - 1].Vx, _list_K_Terms[i+1].Vx, _list_K_Terms[i].WordX, _list_K_Terms[i].Vx);
                       _listHASFIS.Add(sfi); 
                   }
           }
       }
       public void WriteTermstoFile(string filename)
        {
            StreamWriter fwriter = new StreamWriter(filename);
            for (int i = 0; i < _list_K_Terms.Count; i++)
            {
                fwriter.Write(_list_K_Terms[i].Vx);
                fwriter.WriteLine("  " + _list_K_Terms[i].WordX);
            }
            fwriter.Close();
        }
       public void WriteHASFISystem(string filename)
       {
           StreamWriter fwriter = new StreamWriter(filename, true);
           for (int i = 0; i < _listHASFIS.Count; i++)
           {
               fwriter.WriteLine("<"+_listHASFIS[i].VxLeft.ToString() + "\t<" + _listHASFIS[i].Left.ToString()+ "\t<" + _listHASFIS[i].Term.Vx.ToString() + "~" + Revert(_listHASFIS[i].Term.WordX) + ">\t" + _listHASFIS[i].Right.ToString() + ">\t" +_listHASFIS[i].VxRight.ToString()+">");
           }
           fwriter.Close();
       }
       private string Revert(string s)
       {
           string w="";
           for (int i = s.Length - 1; i >= 0; i--)
               w = w + s[i];
           return w;
       }


   }
}
