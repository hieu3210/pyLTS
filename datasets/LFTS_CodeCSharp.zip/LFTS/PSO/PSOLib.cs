﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using PhD.BuildingFuzzyRulesSystem;

namespace PhD.PSO
{
    public class PSOLib
    {

        public static void copy_array (float[] s, float[] d, int l) {
	        int i ;

	        for ( i = 0; i < l; i++)
		        d[i] = s[i];
        }

        public static void copy_array(List<float> s, List<float> d, int l)
        {
            int i;

            for (i = 0; i < l; i++)
                d[i] = s[i];
        }

        public static void printBestRBOSolution(List<List<float>> noDomP, List<List<float>> noDomF, int NF, int D, int lastPart, int NumberOfRule, string fname)
        {
            int i, j;
            string txtLine;
            StreamWriter writer;

            if (File.Exists(fname))
                writer = new StreamWriter(fname);
            else
                writer = File.CreateText(fname);

            writer.WriteLine("Ket qua la: ");
            for (i = 0; i < lastPart; i++)
            {
                writer.WriteLine("--------------------------");
                writer.WriteLine("Phuong an " + (i + 1).ToString() + ":");
                writer.WriteLine("Vi tri:");
                for (j = 0; j < D; j++)
                {
                    writer.Write(Math.Round(noDomP[i][j]).ToString() + " ");
                }
                writer.WriteLine("");
                writer.WriteLine("Cac bien gia tri muc tieu: ");
                writer.WriteLine("Pte\t\t Ptr\t\t Do dai trung binh\t\t So luat");
                txtLine = "";
                for (j = 0; j < NF; j++)
                    //if ((j % 4) == 0)
                    //    txtLine += Convert.ToString((noDomF[i][j]) * 100f) + "\t\t ";
                    //else
                        txtLine += Convert.ToString(noDomF[i][j]) + "\t\t ";
                writer.WriteLine(txtLine);
            }
            writer.Close();
        }

        //Print the output
        public static void mo_out(List<List<float>>  noDomP, List<List<float>> noDomF, int NF, int D, int lastPart, string fname)
        {
            int i, j;
            string txtLine;
            StreamWriter writer;

            if (File.Exists(fname))
                writer = new StreamWriter(fname);
            else
                writer = File.CreateText(fname);

            writer.WriteLine("Ket qua la: ");            
            for(i = 0; i < lastPart; i++) {
                writer.WriteLine("--------------------------");
                writer.WriteLine("Phuong an " + (i+1).ToString() + ":");
                writer.WriteLine("++++++++++++++++++++++++++");
                writer.WriteLine("Cac tham so DSGT:");
                writer.WriteLine("fm(c-) \t\t uL \t\t kj:");
                for (j = 0; j < D / 3; j++)
                {
                    txtLine = "";
                    txtLine += Convert.ToString(noDomP[i][3 * j]) + "\t\t ";
                    txtLine += Convert.ToString(noDomP[i][3 * j + 1]) + "\t\t ";
                    txtLine += Convert.ToString(Math.Ceiling(noDomP[i][3 * j+2]));
                    writer.WriteLine(txtLine);
                }                
                writer.WriteLine("Cac bien gia tri muc tieu: ");
                writer.WriteLine("Hieu qua phan lop\t\t So luat\t\t Do dai trung binh");
                txtLine = "";
                for (j = 0; j < NF; j++)
                    //if((j % 3) == 0)
                     //   txtLine += Convert.ToString(noDomF[i][j]) + "\t\t ";
                    //else 
                    txtLine += Convert.ToString(noDomF[i][j]) + "\t\t ";
                writer.WriteLine(txtLine);
            }
            writer.Close();
        }

        public static void Print_Best_Rules(List<FuzzyRulesSystem> noDomR, int lastPart, int folderIndex, string fPath)
        {
            int i;

            for(i=1;i<=lastPart;i++)
                noDomR[i - 1].WriteToFile(fPath + "\\BestRules(" + i.ToString() + ")_" + folderIndex.ToString() + ".rul");
        }

        public static void ssh_out(float ssh, string fname)
        {

            StreamWriter writer;

            if (File.Exists(fname))
                writer = new StreamWriter(fname);
            else
                writer = File.CreateText(fname);

            writer.WriteLine(Convert.ToString(ssh) + " ");
            writer.Close();
        }

        // Inertia weight (see ratnaweera et al., IEEE trans. EC, vol. 8, no. 3)
        public static float inertia_weight(float w1, float w2, int MAXITER, int iter)
        {
            return (w1 - w2) * ((float)(MAXITER - iter) / (float)MAXITER) + w2;

        }

        public static float acc_coef(float c_i, float c_f, int MAXITER, int iter)
        {
            return ((c_f - c_i) * (iter / MAXITER) + c_i);
        }

        public static float acc_coef1(float cont, int M)
        {
            float rate;

            rate = cont / M;

            // If the performance rate is high we need to reinforce the cognitive component
            if (rate >= 0.6f)
                return 1 / 0.9f; // 0.01 ;
            else
                // On the other hand if the performance rate i slow we need to 
                //decrease the cognitive component
                if (rate <= 0.4f)
                    return 0.9f; // -0.01;
            return 1.0f;
        }

        public static float acc_coef2(float cont, int M)
        {
            float rate;

            rate = cont / M;
            // If the performance rate is high we need to decrease the social component
            if (rate >= 0.6f)
                return 0.9f; // -0.01;
            else
                // On the other hand if the performance rate is low we need to reinforce the social component
                if (rate <= 0.4f)
                    return 1 / 0.9f; // 0.01;

            return 1.0f;
        }

    }
}
