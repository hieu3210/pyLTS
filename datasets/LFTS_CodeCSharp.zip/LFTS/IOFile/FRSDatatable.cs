﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using PhD.HA;
using System.IO;
using PhD.Common;

namespace PhD.FRSData
{
    public class FRSDatatable
    {
        private List<FRSRow> _rows;
        private List<List<int>> _folder;    //Chia tâp dữ liệu thành các folder
        private int _noRow;                 //Số mẫu dữ liệu
        private int _noTestingRows;         //Số mẫu lấy ra để test
        private int _noTraingRows;          //Số mẫu huấn luyện
        private string _fname;
        private MethodTestType _methodTest;
        private int _noAttribute;          //Số thuộc tính
        private byte _noConseqClass;        //Số lớp kết luận
        private byte _minValueOfConseqClass;
        private List<string> _listOfClassName;
        private List<int> isAttrAdded;
        private List<byte> isContinousAttr;
        public byte _dataForFeatureSel; //= 1 --> for Feature Selection, 2 --> for parameterization
        public byte _numberOfSelAttr;


        /// <summary>
        /// Trả lại mẫu dữ liệu thứ index
        /// </summary>
        /// <param name="i"></param>
        /// <returns></returns>
        public FRSRow Rows(int index)
        {
            try
            {
                return _rows[index];
            }
            catch (RankException ex)
            {
                throw ex;
            }

        }
        /// <summary>
        /// Số mẫu dữ liệu
        /// </summary>
        public int RowsCount
        {
            get { return _rows.Count; }
        }
        public int ColumnCount
        {
            get { return _numberOfSelAttr; }
        }
        /// <summary>
        /// Số folder
        /// </summary>
        public int FolderCount
        {
            get { return _folder.Count; }
        }
        /// <summary>
        /// Danh sách chỉ số các mẫu dữ liệu thuộc folder index
        /// </summary>
        /// <param name="i"></param>
        /// <returns></returns>
        public List<int> Folder(int index)
        {
            return _folder[index];
        }

        public string ClassName(int index)
        {
            return _listOfClassName[index];
        }

        public List<string> ListOfClassName
        {
            get
            {
                return _listOfClassName;
            }
        }

        public byte isContinuousAttribute(int index)
        {
            return isContinousAttr[index];
        }

        public List<byte> ListOfAttributeStatus
        {
            get
            {
                return isContinousAttr;
            }
        }

        /// <summary>
        /// Số lớp kết luận
        /// </summary>
        public byte ConseqClassCount
        {
            get { return _noConseqClass; }
        }
        /// <summary>
        /// Số thuộc tính
        /// </summary>
        public int AttibuteCount
        {
            get { return _noAttribute; }
        }

        //Số mẫu test
        public int NoTestingRows
        {
            get { return _noTestingRows; }
        }

        //Số mẫu huấn luyện
        public int NoTrainingRows
        {
            get { return _noTraingRows; }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="noClass"></param>
        /// <param name="listHASFIS"></param>
        public FRSDatatable(string fname, MethodTestType methodTest, int noAttribute, byte noConseqClass, byte minValueOfConseqClass, byte dataForFeatureSel)
        {
            _fname = fname;
            _rows = new List<FRSRow>();
            _folder = new List<List<int>>();
            _noRow = 0;
            _methodTest = methodTest;
            _noAttribute = noAttribute;
            _noConseqClass = noConseqClass;
            _noTestingRows = 0;
            _noTraingRows = 0;
            _minValueOfConseqClass = minValueOfConseqClass;
            _dataForFeatureSel = dataForFeatureSel;
            _listOfClassName = new List<string>();
            isAttrAdded = new List<int>();
            isContinousAttr = new List<byte>();
            _numberOfSelAttr = 0;
        }

        public FRSDatatable(MethodTestType methodTest, int noAttribute, byte noConseqClass, byte minValueOfConseqClass, byte dataForFeatureSel)
        {
            _rows = new List<FRSRow>();
            _folder = new List<List<int>>();
            _noRow = 0;
            _methodTest = methodTest;
            _noAttribute = noAttribute;
            _noConseqClass = noConseqClass;
            _noTestingRows = 0;
            _noTraingRows = 0;
            _minValueOfConseqClass = minValueOfConseqClass;
            _dataForFeatureSel = dataForFeatureSel;
            _listOfClassName = new List<string>();
            isAttrAdded = new List<int>();
            isContinousAttr = new List<byte>();
            _numberOfSelAttr = 0;
        }

        public void Add(FRSRow row)
        {
            _rows.Add(row);
        }

        /// <summary>
        /// Hàm thực hiện nạp dữ liệu
        /// </summary>
        /// <returns></returns>
        public int LoadData(string datasetname)
        {
            try
            {
                _rows.Clear();
                StreamReader Reader = new StreamReader(_fname);
                string Line = Reader.ReadLine(); //Doc so dong du lieu
                _noRow = Int16.Parse(Line);
                //Doc danh sach cac Class Name
                Line = Reader.ReadLine();
                string[] GN = Line.Split(new char[] { ',' });
                _listOfClassName.Clear();
                for (int j = 0; j < GN.Length; j++)
                {
                    _listOfClassName.Add(GN[j].Trim());
                }
                //Doc du lieu xac dinh tinh lien tuc hay roi rac cua thuoc tinh
                Line = Reader.ReadLine();
                GN = Line.Split(new char[] { ',' });
                isContinousAttr.Clear();
                for (int j = 0; j < GN.Length; j++)
                {
                    isContinousAttr.Add(Convert.ToByte(GN[j]));
                }
                //Doc cac thuoc tinh xem co can thiet hay khong
                Line = Reader.ReadLine();
                GN = Line.Split(new char[] { ',' });
                isAttrAdded.Clear();
                for (int j = 0; j < GN.Length; j++)
                {
                    int isSel = Convert.ToInt16(GN[j]);
                    isAttrAdded.Add(isSel);
                    if (isSel != 0) _numberOfSelAttr++;
                }
                //Doc du lieu
                for (int i = 0; i < _noRow; i++)
                {
                    FRSRow newrow = new FRSRow();
                    Line = Reader.ReadLine();
                    string[] G = Line.Split(new char[] { ',' });
                    for (int j = 0; j < G.Length - 1; j++)
                    {
                        if (isAttrAdded[j] != 0 || _dataForFeatureSel == 1)
                            newrow.Add(Convert.ToSingle(G[j]));
                    }
                    String className = G[G.Length - 1].Trim();
                    newrow.ConseqClass = 0;
                    for (byte j = 0; j < _listOfClassName.Count; j++)
                    {
                        if (className.Equals(_listOfClassName[j]))
                        {
                            newrow.ConseqClass = j; //Chỉ số Lớp kết luận
                            break;
                        }
                    }
                    _rows.Add(newrow);
                }
                if (_dataForFeatureSel != 1) ConvertDataIntoZeroOne();
                return _noRow;
            }
            catch (IOException ex)
            {
                throw ex;
            }
        }

        public void LoadFolder(string fname)
        {
            try
            {
                StreamReader rd = new StreamReader(fname);
                string s = "";
                string w;

                _folder.Clear();
                for (int k = 0; k < 10; k++)
                {
                    w = "[Number of patterns in fold-" + k.ToString() + "]";
                    do
                    {
                        s = rd.ReadLine();
                        if (s == w)
                            break;
                    } while (true);
                    rd.ReadLine();
                    rd.ReadLine();
                    s = rd.ReadLine();
                    string[] G = s.Split(new char[] { ' ' });
                    List<int> folder = new List<int>();
                    for (int i = 0; i < G.Length - 1; i++)
                        folder.Add(Convert.ToInt16(G[i]));
                    _folder.Add(folder);
                }
                rd.Close();
            }
            catch (IOException ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Hàm thực hiện nạp dữ liệu tu KEEL dataset
        /// </summary>
        /// <returns></returns>

        public void LoadKEEL10Data(int folderIndex, string filepath, string datasetname)
        {
            try
            {
                int numtestrow = 0, numtrainrow = 0;
                string fname;
                string s = "", w, Line;

                StreamReader Reader = new StreamReader(_fname);
                Line = Reader.ReadLine(); //Do dong du lieu
                _noRow = Int16.Parse(Line);
                //Doc danh sach cac Class Name
                Line = Reader.ReadLine();
                string[] GN = Line.Split(new char[] { ',' });
                _listOfClassName.Clear();
                for (int j = 0; j < GN.Length; j++)
                {
                    _listOfClassName.Add(GN[j].Trim());
                }
                //Doc du lieu xac dinh tinh lien tuc hay roi rac cua thuoc tinh
                Line = Reader.ReadLine();
                //Doc cac thuoc tinh xem co can thiet hay khong
                Line = Reader.ReadLine();
                GN = Line.Split(new char[] { ',' });
                isAttrAdded.Clear();
                for (int j = 0; j < GN.Length; j++)
                {
                    int isSel = Convert.ToInt16(GN[j]);
                    isAttrAdded.Add(isSel);
                    if (isSel != 0) _numberOfSelAttr++;
                }
                Reader.Close();

                StreamReader rd;
                //Load training data
                fname = filepath + "\\" + datasetname + "-10-fold\\" + datasetname + "-10-" + folderIndex.ToString() + "tra.dat";
                rd = new StreamReader(fname);
                w = "@data";
                do
                {
                    s = rd.ReadLine();
                    if (s == w)
                        break;
                } while (true);
                _rows.Clear();
                while (!rd.EndOfStream)
                {
                    FRSRow newrow = new FRSRow();
                    Line = rd.ReadLine();
                    string[] G = Line.Split(new char[] { ',' });
                    for (int j = 0; j < G.Length - 1; j++)
                    {
                        if (isAttrAdded[j] != 0)
                            newrow.Add(Convert.ToSingle(G[j]));
                    }
                    String className = G[G.Length - 1].Trim();
                    newrow.ConseqClass = 0;
                    for (byte j = 0; j < _listOfClassName.Count; j++)
                    {
                        if (className.Equals(_listOfClassName[j]))
                        {
                            newrow.ConseqClass = j; //Chỉ số Lớp kết luận
                            break;
                        }
                    }
                    newrow.IsTesting = false;
                    _rows.Add(newrow);
                    numtrainrow++;
                }
                rd.Close();
                //Load testing data
                fname = filepath + "\\" + datasetname + "-10-fold\\" + datasetname + "-10-" + folderIndex.ToString() + "tst.dat";
                rd = new StreamReader(fname);
                w = "@data";
                do
                {
                    s = rd.ReadLine();
                    if (s == w)
                        break;
                } while (true);
                while (!rd.EndOfStream)
                {

                    FRSRow newrow = new FRSRow();
                    Line = rd.ReadLine();
                    string[] G = Line.Split(new char[] { ',' });
                    for (int j = 0; j < G.Length - 1; j++)
                    {
                        if (isAttrAdded[j] != 0)
                            newrow.Add(Convert.ToSingle(G[j]));
                    }
                    String className = G[G.Length - 1].Trim();
                    newrow.ConseqClass = 0;
                    for (byte j = 0; j < _listOfClassName.Count; j++)
                    {
                        if (className.Equals(_listOfClassName[j]))
                        {
                            newrow.ConseqClass = j; //Chỉ số Lớp kết luận
                            break;
                        }
                    }
                    newrow.IsTesting = true;
                    _rows.Add(newrow);
                    numtestrow++;
                }
                rd.Close();

                _noTestingRows = numtestrow;
                _noTraingRows = numtrainrow;
                _noRow = numtrainrow + numtestrow;

                //Chuyen doi du lieu ve khoang [0, 1]
                ConvertDataIntoZeroOne();
            }
            catch (IOException ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="fname"></param>
        public void WritetoFile(string fname)
        {
            StreamWriter wr = new StreamWriter(fname);
            for (int i = 0; i < _rows.Count; i++)
            {

                for (int j = 0; j < _rows[i].ColumnCount; j++)
                {
                    wr.Write(_rows[i][j] + "\t");
                }
            }
            wr.Close();
        }
        /// <summary>
        /// Ánh xạ giá trị của các thuộc tính vào đoạn [0,1]
        /// </summary>
        private void ConvertDataIntoZeroOne()
        {
            float[] max = new float[_noAttribute];
            float[] min = new float[_noAttribute];

            //Tìm giá trị lớn nhất và nhỏ nhất trong từng thuộc tính
            for (int i = 0; i < _noAttribute; i++)
            {
                max[i] = float.MinValue;
                min[i] = float.MaxValue;
            }
            for (int i = 0; i < _noRow; i++)
            {
                for (int j = 0; j < _noAttribute; j++)
                {
                    if (_rows[i][j] > max[j])
                        max[j] = _rows[i][j];
                    if (_rows[i][j] < min[j])
                        min[j] = _rows[i][j];
                }
            }
            //Ánh xạ giá trị của các thuộc tính vào đoạn [0,1]
            for (int i = 0; i < _noRow; i++)
            {
                for (int j = 0; j < _noAttribute; j++)
                {
                    _rows[i][j] = (_rows[i][j] - min[j]) / (max[j] - min[j]);

                }
            }
        }

        //Hàm lấy các mẫu kiểm tra
        public FRSDatatable GetTestingPattern()
        {
            FRSDatatable testingPattern = new FRSDatatable(_methodTest, _noAttribute, _noConseqClass, _minValueOfConseqClass, 2);
            int count = 0;

            for (int i = 0; i < _rows.Count; i++)
            {
                if (_rows[i].IsTesting)
                {
                    testingPattern.Add(_rows[i]);
                    count++;
                }
            }
            testingPattern._noRow = count;

            return testingPattern;
        }

        //Hàm lấy các mẫu huấn luyện
        public FRSDatatable GetTrainingPattern()
        {
            FRSRow row = new FRSRow();
            FRSDatatable trainingPattern = new FRSDatatable(_methodTest, _noAttribute, _noConseqClass, _minValueOfConseqClass, 2);
            int count = 0;
            if (_methodTest == MethodTestType.All)
            {
                //Tập huấn luyện cũng là tập kiểm tra
                for (int i = 0; i < _rows.Count; i++)
                {
                    trainingPattern.Add(_rows[i]);
                }
                trainingPattern._noRow = _rows.Count;
            }
            else
            {
                for (int i = 0; i < _rows.Count; i++)
                {
                    if (_rows[i].IsTesting == false)
                    {
                        trainingPattern.Add(_rows[i]);
                        count++;
                    }
                }
                trainingPattern._noRow = count;
            }

            return trainingPattern;
        }

        #region Tao folder test
        public void CreateFolder()
        {
            int idxFolder;
            int idxRow;
            int noFolder;
            int noRowInOneFolder;   //Số row cho mỗi folder
            int oddnoRow;           //Số row lẻ ra sau khi chia cho các folder.
            int j;

            //rd = new Random((int)DateTime.Now.Ticks);
            //return Convert.ToSingle(rd.Next(int.MaxValue))/int.MaxValue;
            List<int> listIdxRow = new List<int>();
            for (int i = 0; i < _noRow; i++)
                listIdxRow.Add(i);
            if (_methodTest == MethodTestType.All)
                noFolder = 1;
            else
                if (_methodTest == MethodTestType.LiveOne)
                    noFolder = _rows.Count;
                else
                    if (_methodTest == MethodTestType.TenFolder)
                        noFolder = 10;
                    else
                        noFolder = 2; //fifty folder                    
            //Xác định số row cho mỗi folder và số lẻ
            noRowInOneFolder = _noRow / noFolder;   // chia lay phan nguyen
            oddnoRow = _noRow % noFolder;         //Phần lẻ
            _folder.Clear();
            if (_methodTest == MethodTestType.All)
            {
                List<int> folder = new List<int>();
                for (int i = 0; i < _rows.Count; i++)
                    folder.Add(i);
                _folder.Add(folder);
            }
            else
                if (_methodTest == MethodTestType.LiveOne)
                {
                    for (int i = 0; i < noFolder; i++)
                    {
                        List<int> folder = new List<int>();
                        folder.Add(i);
                        _folder.Add(folder);
                    }
                }
                else
                {
                    for (int i = 0; i < noFolder; i++)
                    {
                        List<int> folder = new List<int>();
                        _folder.Add(folder);
                    }
                    while (listIdxRow.Count > oddnoRow)
                    {
                        idxFolder = MyRandom.RandomN(noFolder);              //Chọn ngẫu nhiên một folder
                        if (_folder[idxFolder].Count < noRowInOneFolder)    //Nếu folder chua đủ số row
                        {
                            idxRow = MyRandom.RandomN(listIdxRow.Count);
                            _folder[idxFolder].Add(listIdxRow[idxRow]);
                            listIdxRow.RemoveAt(idxRow);
                        }
                    }
                    //Đưa phần lẻ vào các folder
                    j = 0;
                    while (listIdxRow.Count > 0)
                    {
                        _folder[j].Add(listIdxRow[0]);
                        listIdxRow.RemoveAt(0);
                        j++;
                    }
                }
        }
        public void SetFolderTest(int folderIdx)
        {
            for (int i = 0; i < _rows.Count; i++)
                _rows[i].IsTesting = false;
            if (_methodTest == MethodTestType.LiveOne)
            {
                _rows[folderIdx].IsTesting = true;
                _noTestingRows = 1;
            }
            else
            {
                if (_methodTest == MethodTestType.All)
                {
                    for (int i = 0; i < _rows.Count; i++)
                        _rows[i].IsTesting = true;
                    _noTestingRows = _rows.Count;
                }
                else
                {
                    List<int> sFolder = _folder[folderIdx];
                    for (int i = 0; i < sFolder.Count; i++)
                        _rows[sFolder[i]].IsTesting = true;
                    _noTestingRows = sFolder.Count;
                }
            }
            _noTraingRows = _rows.Count - _noTestingRows;
        }

        public void SaveFolder(string fname)
        {
            StreamWriter wr = new StreamWriter(fname);
            string txtLine;

            wr.WriteLine(_folder.Count.ToString());
            for (int i = 0; i < _folder.Count; i++)
            {
                wr.WriteLine("Folder: " + i.ToString());
                txtLine = "";
                for (int j = 0; j < _folder[i].Count; j++)
                {
                    if (j > 0) txtLine += "\t";
                    txtLine += _folder[i][j].ToString();
                }
                wr.WriteLine(txtLine);
            }
            wr.Close();
        }

        #endregion

    }
}
