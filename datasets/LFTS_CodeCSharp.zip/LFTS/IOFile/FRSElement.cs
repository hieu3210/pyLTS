﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace PhD.FRSData
//{
//    public class FRSElement
//    {
//        private float _value;
//        // Lưu chỉ số của khoảng mờ tương tự của hệ khoảng mờ mức k mà phần tử này năm vào trong nó
//        private byte _idxSFIatK;        
//        public FRSElement()
//        {
//            _value = 0;
//            _idxSFIatK = 0;           
//        }
//        public FRSElement(float value, byte idxSFIatK)
//        {
//            _value = value;
//            _idxSFIatK = idxSFIatK;
//        }
//        public FRSElement(float value)
//        {
//            _value = value;
//            _idxSFIatK = 0;
//        }
//        public float Value
//        {
//            get { return _value; }
//            set { _value = value; }
//        }
//        public byte IdxSFIatK
//        {
//            get { return _idxSFIatK; }
//            set { _idxSFIatK = value; }
//        }
       
//    }
//}
