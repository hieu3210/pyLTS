﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PhD.FRSData
{
    public class FRSRow
    {
        private List<float> _listElem;
        private List<float> _listClusterIndex;
        private byte _conseqclass;
        private bool _isTesting;        //Nhan gia tri false la du lieu thuoc tạp training
                                        //Nhan gia tri true la du lieu thuoc tap test
        public FRSRow()
        {
            _listElem = new List<float>();
            _listClusterIndex = new List<float>();
        }
        public float this[int  index]
        {
            get { return _listElem[index]; }
            set { _listElem[index] = value; }
        }
        public void Add(float elem)
        {
            _listElem.Add(elem);
            _listClusterIndex.Add(-1.0f);
        }
        public void Add(float elem, float clusIndex)
        {
            _listElem.Add(elem);
            _listClusterIndex.Add(clusIndex);
        }
        public void Remove(int indx)
        {
            _listElem.RemoveAt(indx);
            _listClusterIndex.RemoveAt(indx);
        }
        public FRSRow GetTrainingRow(List<int> isAttrAdded)
        {
            FRSRow row = new FRSRow();
            row.ConseqClass = _conseqclass;
            row.IsTesting = _isTesting;
            for (int i = 0; i < _listElem.Count; i++)
            {
                if (isAttrAdded[i] != 0)
                {
                    row.Add(_listElem[i]);
                }
            }
            return row;
        }
            
        public byte ConseqClass
        {
            get { return _conseqclass; }
            set { _conseqclass = value; }
        }
        public int ColumnCount
        {
            get { return _listElem.Count; }
        }
        public bool IsTesting
        {
            get { return _isTesting; }
            set { _isTesting = value;}
        }

        public float GetClusterIndex(int Attr)
        {
            return _listClusterIndex[Attr];
        }
        public void SetClusterIndex(int Attr, float indexValue)
        {
            _listClusterIndex[Attr] = indexValue;
        }
    }
}
