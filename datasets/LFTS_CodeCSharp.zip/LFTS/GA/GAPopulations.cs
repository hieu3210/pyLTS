﻿
//Lớp biểu diễn quần thể
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using PhD.BuildingFuzzyRulesSystem;
using PhD.Common;
using System.Windows.Forms;
namespace PhD.GA
{
    public class GAPopulations
    {
        private GAParameters _params;       
	    private List<GAIndividual>_pop;    //quần thể gốc
        private List<GAIndividual>_newpop; //quần thể mới   
        private float _optValue;           //Giá trị tối ưu      
        private float[] _ob;
        private float _totalFitnessValue;
        private float[] _optX;               //Giá trị của biến tối ưu      
        public IObjectFunction f;           //Lớp chứa hàm mục tiêu
               
        public GAParameters Params
        {
            get{ return _params;}
        }
        public float this[int index]
        {
            get
            { if(index<_params.NoGen)
                    return _optX[index]; 
            else
                return _optX[0]; 
            }

        }
        public float OptimalValue
        {
            get { return _optValue; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="param"></param>
        ///
        public GAPopulations(GAParameters param)
        {
            _params = param;      
	        _pop = new List<GAIndividual>();
            _newpop = new List<GAIndividual>();
            _ob = new float[_params.SizeOfPopulation];
            _optX = new float[_params.NoGen];           
        }
        /// <summary>
        /// 
        /// </summary>
        private void InitPop()		//Ham khoi tao quan the
        {
           _pop.Clear();
	        for(int i = 0;i< _params.SizeOfPopulation;i++)
	        {
                 GAIndividual idv = new GAIndividual(_params);
                 idv.Initial();
                _pop.Add(idv);               
            }
	    }

        /// <summary>
        /// Hàm xác định giá trị thích nghi của các cá thể
        /// </summary>
        /// <returns>Tổng giá trị thích nghi của quần thể</returns>
        private void ScalePop()
        {
            float ave; //Trung bình giá trị thích nghi
            float b, a, min, max, sum;
	        int i;            
            //Xác định giá trị thích nghi thô theo hàm mục tiêu và trung bình của chúng
            sum = float.MinValue;
	        max = float.MinValue;
	        min = float.MaxValue;
	        for(i=0; i<_params.SizeOfPopulation;i++)
	            if(sum < _pop[i].ObjectiveFunctionValue)
			        sum = _pop[i].ObjectiveFunctionValue;                    
	        ave = 0;
            for(i=0; i<_params.SizeOfPopulation;i++)
	        {
                _ob[i] = sum - _pop[i].ObjectiveFunctionValue;  //anh xa gtri ham muc tieu den gia tri thich nghi
                if(max < _ob[i])
			        max = _ob[i];
                if(min>_ob[i])
			        min = _ob[i];
		        ave += _ob[i];
	        }
	        ave /= _params.SizeOfPopulation;
	        //Xac dinh tham so a va b trong dieu chinh do thich nghi
	        if(min>(2 * ave - max))
	        {
		        a = ave / (max - ave);
		        b = a * (max - 2 * ave);
	        }
	        else
	        {
		        a = ave / (ave - min);
		        b = -min * a;
	        }
            //Tinh giá trị thích nghi theo điều chỉnh và tính tổng độ thích nghi
	        _totalFitnessValue = 0;
	        for(i=0;i<_params.SizeOfPopulation;i++)
	        {
		        _pop[i].FitnessValue = a * _ob[i] + b;	//Gia tri thich nghi cua tung ca the
		        _totalFitnessValue += _pop[i].FitnessValue;       //Tinh tong thich nghi cua quan the
	        }            
        }
     
    /// <summary>
    /// Ham thuc hien lua chon ca the bo me cho qua trinh lai ghep
    /// Dựa trên giá trị thích nghi của từng cá thể và tổng độ thích nghi
    /// của cả quần thể.
    /// </summary>   
    /// <returns>Vị trí của cá thể tốt nhất trong quần thể</returns>
        private int Selected()
        {
	        float partsum, rand;
            rand = MyRandom.Random01() * _totalFitnessValue;
	        partsum = 0;
            for(int i=0; i< _params.SizeOfPopulation; i++)
	        {
		        partsum = partsum + _pop[i].FitnessValue;
		        if(partsum >= rand)
			        return i;
	        }
	        return _params.SizeOfPopulation-1;
        }
        /// <summary>
        /// Hàm tạo sinh
        /// </summary>
        private void Generate()
        {
	        int j, mate1,mate2;
	        j=0;
            GAIndividual child1 = new GAIndividual(_params);
            GAIndividual child2 = new GAIndividual(_params);
            _newpop.Clear();
	        do
	        {
                mate1 = Selected();
		        mate2 = Selected();
               _pop[mate1].Crossover(_pop[mate2], out child1,out  child2 );
                _newpop.Add(child1);
                _newpop.Add(child2);
		        j = j + 2;
		        if(j >= _params.SizeOfPopulation) 
			        break;
	        }while(true);
	        //Nap lai quan the
            _pop.Clear();
            for(j=0;j<_params.SizeOfPopulation;j++)
		        _pop.Add(_newpop[j]);
        }
        /// <summary>
        /// Hàm thực hiện tối ưu các tham số
        /// </summary>
        /// <param name="noGenerations"> Số thế hệ</param>
        /// <param name="f"></param>
        /// <param name="LWord"></param>
        /// <returns></returns>
        public void GAOpParams(Object obj)
        {
            frmProgress frm = obj as frmProgress;
             try
            {
                
                //StreamWriter wr = new StreamWriter("Optparam.txt",true);
               // wr.WriteLine(DateTime.Now.ToString());
                _optValue = float.MinValue;
	            int i,j;
	            //Khoi tao quan the
	            InitPop();
                frm.SetMax(_params.NoGenerations*_params.SizeOfPopulation);         
                
                for (j = 0; j < _params.NoGenerations; j++) //Thuc hien lap qua cac the he
	            {                   
                    for( i=0; i< _params.SizeOfPopulation; i++)
		            {
			            //Danh gia ham muc tieu
			            _pop[i].ObjectiveFunctionValue = f.ObjectiveFunction(_pop[i].ObjectiveVariables);
                        if (_optValue < _pop[i].ObjectiveFunctionValue)
			            {
                            _optValue = _pop[i].ObjectiveFunctionValue;
                            for (int k = 0; k < _params.NoGen; k++)
                            {
                                _optX[k] = _pop[i].ObjectiveVariables[k];
                            }                        
			            }
                        System.Threading.Thread.Sleep(5);
                        frm.SetCaption("Đang thực hiện đến cá thể thứ: " + (i+1).ToString()+"/" +_params.SizeOfPopulation.ToString()+ " của thế hệ thứ: " + (j+1).ToString()+"/"+ _params.NoGenerations.ToString());
                        frm.IncreasePercent();
                    }
                    //wr.WriteLine(j.ToString() + "\t" + _optValue.ToString());
		            //Xac dinh gia tri thich nghi cua tung ca the
                    ScalePop();
		            //Tao sinh quan the moi
                    if (j<_params.NoGenerations-1)
                        Generate();               
                }               
                //wr.Close();
            } catch (System.Exception ex)
             {
                 MessageBox.Show(ex.Message, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
             }
             finally
             {
                 frm.CloseForm();
             }           
	        //return _optValue;  //Gia tri toi uu cua ham
        }       
    }
}
