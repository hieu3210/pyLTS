﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PhD.Common;

namespace PhD.GA
{
    public class GAIndividual
    {
        private List<byte>_schrom;          //Một nhiễm sắc thể (một cá thể) có nhiều gens
        private List<float> _objectiveVariables;//Luu giá trị của các biến mục tiêu
        private float _objectiveFunctionValue; //Lưu giá trị của hàm mục tiêu.
        private float _fitnessValue;           //Giá trị thịch nghi 
        private GAParameters _param;
       //private int      _Rank;
	   //private float   _mDist;
        
        #region properties
        /// <summary>
        /// Nhiễm sắc thể biểu diễn cá thể
        /// </summary>
        public List<byte> Schrom
        {
            get { return _schrom; }
            set { _schrom = value; }
        }    
        /// <summary>
        /// Giá trị của các biến ứng với cá thể này
        /// </summary>
        public List<float> ObjectiveVariables
        {
            get{ return _objectiveVariables;}
            set{ _objectiveVariables = value;}
        }
        /// <summary>
        /// Giá trị hàm mục tiêu ứng với cá thể này
        /// </summary>
        public float ObjectiveFunctionValue
        {
            get { return _objectiveFunctionValue; }
            set { _objectiveFunctionValue = value; }
        }
        /// <summary>
        /// Giá trị thích nghi của cá thể
        /// </summary>
        public float FitnessValue
        {
            get { return _fitnessValue; }
            set { _fitnessValue = value; }
        }
        public GAParameters Params
        {
            get { return _param; }
        }
        #endregion
        #region methods                
        /// <summary>
        /// 
        /// </summary>
        /// <param name="nGen">So gen cua nhiem sac the</param>
        /// <param name="lGen">Chieu dai cua mot gen khong qua 32</param>
        /// <param name="upBound">Cận trên của các biến mục tiêu</param>
        /// <param name="lowBound">Cận dưới của các biến mục tiêu</param>
        public  GAIndividual(GAParameters param)
        {
            
            _schrom = new List<byte>();
            _objectiveVariables = new List<float>();
            _objectiveFunctionValue = 0;
            _param = param;
           
        }
        public void Initial()
        {
            //Khởi tạo giá trị ban đầu cho các nhiễm sắc thể
            for (int i = 0; i < _param.NoGen * _param.LengthOfGen; i++)
            {
                _schrom.Add(MyRandom.Flip(0.5f));
                //System.Threading.Thread.Sleep(1);
            }
            //Khởi tạo giá trị ban đầu cho các biến của hàm mục tiêu
            for (int i = 0; i < _param.NoGen; i++)
                _objectiveVariables.Add(0);
            Decode();
 
        }
      
        /// <summary>
        /// 
        /// </summary>
        /// <param name="c"></param>
        /// <param name="pmu">xác suất đột biến</param>
        /// <returns></returns>
        private byte Mutation(byte c)	//Ham dot bien
        {
            if (MyRandom.Flip(_param.PMu) == 1)
                if (c == 1)
                    return 0;
                else
                    return 1;
            else
                return c;
        }
        /// <summary>
        /// Hàm lai ghép cá thể này với cá thể idv tạo ra hai con c1, c2
        /// </summary>
        /// <param name="idv">Cá thể được lai ghép</param>
        /// <param name="pCross">Xác xuất lai ghép </param>
        /// <returns></returns>
        public void Crossover(GAIndividual idv, out  GAIndividual c1, out  GAIndividual c2)
        {          
            c1 = this;
            c2 = idv; 
            int jcross;			//Vi tri lai ghep
            int i,j;
            for(i=0;i<_param.NoGen;i++)

            {
                if (MyRandom.Flip(_param.PCross) == 1)
                    jcross = Convert.ToInt16(MyRandom.Random01() * _param.LengthOfGen);
		        else
			        jcross = _param.LengthOfGen;
                for(j=0;j<jcross;j++)
                {
                    c1.Schrom[i * _param.LengthOfGen + j] = Mutation(this.Schrom[i * _param.LengthOfGen + j]);
                    c2.Schrom[i * _param.LengthOfGen + j] = Mutation(idv.Schrom[i * _param.LengthOfGen + j]);
		        }
		        for(j=jcross;j<_param.LengthOfGen;j++)
		        {
                    c1.Schrom[i * _param.LengthOfGen + j] = Mutation(idv.Schrom[i * _param.LengthOfGen + j]);
                    c2.Schrom[i * _param.LengthOfGen + j] = Mutation(this.Schrom[i * _param.LengthOfGen + j]);
		        }
	        }
            
            c1.Decode();        //Xác định giá trị của các biến mục tiêu của cá thể c1
            c2.Decode();        //Xác định giá trị của các biến mục tiêu của cá thể c2            
        }
        
        /// <summary>
        /// Hàm thực hiện giải mã các gen thành giá trị của các biến mục tiêu tương ứng 
        ///Kết quả lưu vào danh sách các biến mục tiêu ObjectiveValues.
        /// </summary>
        /// <param name="indi"></param>
        /// <param name="rate"></param>
        private void Decode()
        {
            float sum, power;
            float x;
            for (int i = 0; i <_param.NoGen; i++)
            {
                sum = 0;
                power = 1;
                for (int j = 0; j < _param.LengthOfGen; j++)
                {
                    if (Schrom[i * _param.LengthOfGen + j] == 1)
                        sum += power;
                    power *= 2;
                }
                power = sum / _param.Rate;
                x = _param.LowBound[i] + (_param.UpBound[i] - _param.LowBound[i]) * power;
                _objectiveVariables[i] = x;
            }
            _objectiveFunctionValue = 0;
        }
	    public bool  IsDominate(GAIndividual  idv)
        {
            return true;
        }

        #endregion
    }
}
