﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
namespace PhD.Common
{
    public class GAParameters
    {
        private List<float> _upBound;       //Lưu giá trị cấn trên của các biến cần tìm
        private List<float> _lowBound;      //Lưu giá trị cận dưới của các biến cần tìm
        private int _noGenerations;         //So the he
        private int _popSize;		        //Kích thước của quần thể   
        private int _noGen;				    //Số biến của hàm mục tiêu
        private int _lGen;                  //Chiều dài của một gen (thể hiện một biến của hàm mục tiêu
        private float _pMu;		            //Xác suất đột biến
        private float _pCross;		        //Xac xuat lai ghep;
        private float _rate;                //Tỉ lệ chuyển đổi từ xâu bit sang số thực tương ứng.
        private Optimal _ObjectOptimum;     //Đối tượng tối ưu       
        #region Properties
        public List<float> UpBound
        {
            get { return _upBound; }
        }
        public List<float> LowBound
        {
            get { return _lowBound; }
        }
        public int NoGenerations
        {
            get { return _noGenerations; }
            set
            {
                if (value < 1)
                    _noGenerations = 1;
                else
                    _noGenerations = value;
            }
        }
        public int SizeOfPopulation
        {
            get { return _popSize; }
            set
            {
                if (value < 2)
                    _popSize = 2;
                else
                    _popSize = value;
            }
        }
        public int NoGen
        {
            get
            {
                return _noGen;
            }
            set
            {
                _noGen = value;
            }
        }
        public int LengthOfGen
        {
            get
            {
                return _lGen;
            }
            set
            {
                _lGen = value;
                ComputeRate();        //Tính lại giá trị _rate tỉ lệ chuyển đổi từ
            }
        }
        /// <summary>
        /// Xac suat dot bien
        /// </summary>
        public float PMu
        {
            get { return _pMu; }
            set
            {
                if (value >= 0 && value <= 1)
                    _pMu = value;
                else
                    _pMu = 1;
            }
        }
        /// <summary>
        /// Xac suat lai ghep
        /// </summary>
        public float PCross
        {
            get { return _pCross; }
            set
            {
                if (value >= 0 && value <= 1)
                    _pCross = value;
                else
                    _pCross = 1;
            }
        }
        public float Rate
        {
            get { return _rate; }
        }
        public Optimal ObjectOptimum
        {
            get { return _ObjectOptimum; }
            set { _ObjectOptimum = value;}
        }     
        #endregion
        #region Constructor
        public GAParameters()
        {
            _upBound = new List<float>();
            _lowBound = new List<float>();
        }

        #endregion
        private void ComputeRate()		//Ham tinh mau so cua cong thuc chuyen doi xau bit ve so thuc ban dau cua bien
        {
            _rate = 0;
            long sum = 1;
            for (int i = 0; i < _lGen; i++)
            {
                _rate += sum;
                sum *= 2;
            }
        }
        public void LoadParameters(string fname)
        {
            try
            {
                StreamReader Reader = new StreamReader(fname);
                string Line = Reader.ReadLine();//bỏ dong hướng dẫn
                Line = Reader.ReadLine();
                Line = Reader.ReadLine();
                _noGenerations = int.Parse(Line);
                Line = Reader.ReadLine();        //bỏ dong hướng dẫn
                Line = Reader.ReadLine();
                _popSize = int.Parse(Line);

                Line = Reader.ReadLine();       //bỏ dong hướng dẫn
                Line = Reader.ReadLine();
                _noGen = int.Parse(Line);
                Line = Reader.ReadLine();       //bỏ dong hướng dẫn
                Line = Reader.ReadLine();
                LengthOfGen = int.Parse(Line);
                Line = Reader.ReadLine();       //bỏ dong hướng dẫn
                Line = Reader.ReadLine();
                _pCross = float.Parse(Line);
                Line = Reader.ReadLine();       //bỏ dong hướng dẫn
                Line = Reader.ReadLine();
                _pMu = float.Parse(Line);
                Line = Reader.ReadLine();       //bỏ dong hướng dẫn
                Line = Reader.ReadLine();
                string[] G = Line.Split(new char[] { ' ' });
                for (int j = 0; j < G.Length ; j++)
                   _lowBound.Add(float.Parse(G[j]));
                Line = Reader.ReadLine();       //bỏ dong hướng dẫn
                Line = Reader.ReadLine();
                G = Line.Split(new char[] { ' ' });
                for (int j = 0; j < G.Length ; j++)
                    _upBound.Add(float.Parse(G[j]));
                Reader.Close();
            }
            catch (IOException ex)
            {
                throw ex;
            } 
        }
        public void SaveParams(string fname)
        {
            try
            {
                StreamWriter wr = new StreamWriter(fname);            
                wr.WriteLine("[------Cac tham so cua GA----------]");
                wr.WriteLine("[So the he]");
                wr.WriteLine(_noGenerations);
                wr.WriteLine("[Kich thuoc quan the popsize]");
                wr.WriteLine(_popSize);
                wr.WriteLine("[So bien muc tieu nGen = so thuoc tinh * 3]");
                wr.WriteLine(_noGen);
                wr.WriteLine("[Chieu dai moi gen <25]");
                wr.WriteLine(LengthOfGen);
                wr.WriteLine("[Xac xuat lai ghep Pcross]");
                wr.WriteLine(_pCross);
                wr.WriteLine("[Xac xuat dot bien Pmu ]");
                wr.WriteLine(_pMu );
                wr.WriteLine("[Can duoi cua cac bien muc tieu ung voi cac thuoc tinh mfmc0 muyL0 k0 fmc1 muyL1 k1 ....]");              
                for (int j = 0; j < _lowBound.Count; j++)
                    if(j<_lowBound.Count-1)
                        wr.Write(_lowBound[j]+" ");             
                    else
                        wr.WriteLine(_lowBound[j]);
                wr.WriteLine("[Can tren cua cac bien muc tieu ung voi cac thuoc tinh mfmc0 muyL0 k0 fmc1 muyL1 k1 ....]");
                for (int j = 0; j < _upBound.Count; j++)
                    if (j < _lowBound.Count - 1)
                        wr.Write(_upBound[j] + " ");
                    else
                        wr.WriteLine(_upBound[j]);
                wr.Close();
            }
            catch (IOException ex)
            {
                throw ex;
            }
        }
    }
}
