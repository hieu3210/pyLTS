﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace PhD.Common
{
    public class PSOParameters
    {
        private List<float> _upBound;       //Lưu giá trị cấn trên của các biến cần tìm
        private List<float> _lowBound;      //Lưu giá trị cận dưới của các biến cần tìm
        private int _noGenerations;         //So the he (So lan lap)
        private int _popSize;		        //Kích thước của quần thể (Số particle)
        private int _noFun;		            //Số hàm mục tiêu   
        private int _memSize;               //Kích thước repository --> Phải lớn hơn hoặc bằng số particle
        private int _noVar;				    //Số biến của hàm mục tiêu = (Số thuộc tính * 3)
        private int _opt;                   //Tối đa hay tối thiểu hóa
        private float _inertia;             //Mặc định = 0.4
        private float _C1;
        private float _C2;
        private float _r1;
        private float _r2;
        private int _noOuterGen;
        private int _noOuterPopSize;

        #region Properties
        public List<float> UpBound
        {
            get { return _upBound; }
            set { _upBound = value; }
        }
        
        public List<float> LowBound
        {
            get { return _lowBound; }
            set { _lowBound = value; }
        }
        
        public int NoGenerations
        {
            get { return _noOuterGen; }
            set
            {
                if (value < 1)
                    _noOuterGen = 1;
                else
                    _noOuterGen = value;
            }
        }

        public int NoOuterGenerations
        {
            get { return _noGenerations; }
            set
            {
                if (value < 1)
                    _noGenerations = 1;
                else
                    _noGenerations = value;
            }
        }
       
        public int SizeOfPopulation
        {
            get { return _popSize; }
            set
            {
                if (value < 2)
                    _popSize = 2;
                else
                    _popSize = value;
            }
        }

        public int SizeOfOuterPopulation
        {
            get { return _noOuterPopSize; }
            set
            {
                if (value < 2)
                    _noOuterPopSize = 2;
                else
                    _noOuterPopSize = value;
            }
        }

        public int NumberOfFunction
        {
            get
            {
                return _noFun;
            }
            set
            {
                _noFun = value;
            }
        }

        public int SizeOfRepository
        {
            get
            {
                return _memSize;
            }
            set
            {
                _memSize = value;
            }
        }

        public int NumberOfDimension
        {
            get
            {
                return _noVar;
            }
            set
            {
                _noVar = value;
            }
        }
        /// <summary>
        /// Trọng số Intertia
        /// </summary>
        public float IntertiaWeight
        {
            get { return _inertia; }
            set { _inertia = value; }
        }

        public int Optimization
        {
            get { return _opt; }
        }

        public float C1
        {
            get { return _C1; }
            set { _C1 = value; }
        }

        public float C2
        {
            get { return _C2; }
            set { _C2 = value; }
        }
        
        public float R1
        {
            get { return _r1; }
            set { _r1 = value; }
        }
        
        public float R2
        {
            get { return _r2; }
            set { _r2 = value; }
        }

        #endregion

        #region Constructor
        public PSOParameters()
        {
            _upBound = new List<float>();
            _lowBound = new List<float>();

            //Các số liệu mặc định
            _inertia = 0.4f;    
            _C1 = 2.0f;
            _C2 = 2.0f;
            _r1 = 1.0f;
            _r2 = 1.0f;
            _opt = 0;           //Mặc định là tối thiểu hóa
            _noOuterGen = 30;
            _noOuterPopSize = 20;
        }

        #endregion

        public void LoadParameters(string fname)
        {
            try
            {
                StreamReader Reader = new StreamReader(fname);
                string Line = Reader.ReadLine();//bỏ dòng hướng dẫn
                Line = Reader.ReadLine();
                Line = Reader.ReadLine();
                _noGenerations = int.Parse(Line);
                Line = Reader.ReadLine();        //bỏ dòng hướng dẫn
                Line = Reader.ReadLine();
                _popSize = int.Parse(Line);

                Line = Reader.ReadLine();       //bỏ dòng hướng dẫn
                Line = Reader.ReadLine();
                _noVar = int.Parse(Line);

                /*Line = Reader.ReadLine();       //bỏ dòng hướng dẫn
                Line = Reader.ReadLine();
                string[] G = Line.Split(new char[] { ' ' });
                for (int j = 0; j < G.Length; j++)
                    _lowBound.Add(float.Parse(G[j]));
                Line = Reader.ReadLine();       //bỏ dòng hướng dẫn
                Line = Reader.ReadLine();
                G = Line.Split(new char[] { ' ' });
                for (int j = 0; j < G.Length; j++)
                    _upBound.Add(float.Parse(G[j])); */
                Reader.Close();
            }
            catch (IOException ex)
            {
                throw ex;
            }
        }
        public void SaveParams(string fname)
        {
            try
            {
                StreamWriter wr = new StreamWriter(fname);
                wr.WriteLine("[------Cac tham so cua PSO----------]");
                wr.WriteLine("[So the he]");
                wr.WriteLine(_noGenerations);
                wr.WriteLine("[Kich thuoc quan the popsize]");
                wr.WriteLine(_popSize);
                wr.WriteLine("[So bien muc tieu = so thuoc tinh * 3]");
                wr.WriteLine(_noVar);
                /*wr.WriteLine("[Can duoi cua cac bien muc tieu ung voi cac thuoc tinh mfmc0 muyL0 k0 fmc1 muyL1 k1 ....]");
                for (int j = 0; j < _lowBound.Count; j++)
                    if (j < _lowBound.Count - 1)
                        wr.Write(_lowBound[j] + " ");
                    else
                        wr.WriteLine(_lowBound[j]);
                wr.WriteLine("[Can tren cua cac bien muc tieu ung voi cac thuoc tinh mfmc0 muyL0 k0 fmc1 muyL1 k1 ....]");
                for (int j = 0; j < _upBound.Count; j++)
                    if (j < _lowBound.Count - 1)
                        wr.Write(_upBound[j] + " ");
                    else
                        wr.WriteLine(_upBound[j]); */
                wr.Close();
            }
            catch (IOException ex)
            {
                throw ex;
            }
        }


    }
}
