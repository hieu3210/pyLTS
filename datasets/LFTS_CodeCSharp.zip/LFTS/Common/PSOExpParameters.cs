﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace PhD.Common
{
    public class PSOExpParameters
    {
        public string FilePath;
        public string FileName;
        public int NoAttribute;
        public byte NoConsequenClass;
        public byte minValueOfConseqClass;
        public MethodTestType MethodTest;
        public ResionMethodType ResionMethod;

        public RuleWeightType WeightType;
        public PreScreeningType PreScreenType;
        public ExperimentDataType ExperimentType;
        public byte MaxRuleLength;              //Chiều dài tối đa của tập luật cần lấy
        public int NoRecievedRules;             //Số luật ứng cử cần lấy ra
        public int NoTrueReceivedRules;         //Số luật cần lấy ra để kiểm tra
        public List<string> ListOfClassName; //Danh sach cac Class Name
        //public float W1;                        //Hệ số hàm mục tiêu
        //public float W2;

        public PSOExpParameters()
        {
            ListOfClassName = new List<string>();
        }

        public void LoadParameter(string fname)
        {
            try
            {
                StreamReader rd = new StreamReader(fname);
                string s;
                int n;
                FilePath = Path.GetDirectoryName(fname);
                for (int i = 0; i < 9; i++)
                    s = rd.ReadLine();
                //Đọc tên file dữ liệu
                FileName = rd.ReadLine();
                //Đọc số thuộc tính
                s = rd.ReadLine();          //Bỏ qua dòng chú thích
                s = rd.ReadLine();
                NoAttribute = int.Parse(s);
                //Đọc số lớp kết luận
                s = rd.ReadLine();          //Bỏ qua dòng chú thích
                s = rd.ReadLine();
                NoConsequenClass = byte.Parse(s);
                //Đọc phương pháp thử nghiệm 
                s = rd.ReadLine();          //Bỏ qua dòng chú thích
                s = rd.ReadLine();
                n = Convert.ToInt16(s);
                if (n == 1)
                    MethodTest = MethodTestType.LiveOne;
                else
                    if (n == 10)
                        MethodTest = MethodTestType.TenFolder;
                    else
                        if (n == 50)
                            MethodTest = MethodTestType.FiftyFolder;
                        else
                            MethodTest = MethodTestType.All;
                //Đọc trọng số
                s = rd.ReadLine();          //Bỏ qua dòng chú thích
                s = rd.ReadLine();
                n = Convert.ToInt16(s);
                if (n == 1)
                    WeightType = RuleWeightType.CFI_CONFIDENT;
                else
                    if (n == 2)
                        WeightType = RuleWeightType.CFII_CONFIDENT_CAVE;
                    else
                        if (n == 3)
                            WeightType = RuleWeightType.CFIII_CONFIDENT_C2ND;
                        else
                            if(n==4)
                                WeightType = RuleWeightType.CFIV_CONFIDENT_CSUM;
                            else
                                WeightType = RuleWeightType.CFV;

                //Đọc sàng luật
                s = rd.ReadLine();          //Bỏ qua dòng chú thích
                s = rd.ReadLine();
                n = Convert.ToInt16(s);
                if (n == 1)
                    PreScreenType = PreScreeningType.Conf;
                else
                    if (n == 2)
                        PreScreenType = PreScreeningType.Supp;
                    else
                        PreScreenType = PreScreeningType.SuppConf;
                //Đọc phương pháp lập luận
                s = rd.ReadLine();          //Bỏ qua dòng chú thích
                s = rd.ReadLine();
                n = Convert.ToInt16(s);
                if (n == 1)
                    ResionMethod = ResionMethodType.SingleWiner;
                else
                    ResionMethod = ResionMethodType.Voted;
                //Đọc chiều dài tối đa của luật ứng cử
                s = rd.ReadLine();          //Bỏ qua dòng chú thích
                s = rd.ReadLine();
                MaxRuleLength = Convert.ToByte(s);
                //Đọc số luật ứng cử
                s = rd.ReadLine();          //Bỏ qua dòng chú thích
                s = rd.ReadLine();
                NoRecievedRules = Convert.ToInt16(s);
                //Đọc số luật cần lấy cho tập luật tối ưu
                s = rd.ReadLine();          //Bỏ qua dòng chú thích
                s = rd.ReadLine();
                NoTrueReceivedRules = Convert.ToInt16(s);
                //Đọc giá trị nhỏ nhất của lớp kết luận
                s = rd.ReadLine();          //Bỏ qua dòng chú thích
                s = rd.ReadLine();
                minValueOfConseqClass = Convert.ToByte(s);
                rd.Close();
            }
            catch (IOException ex)
            {
                throw ex;
            }

        }
        public void SaveParams(string fname)
        {
            try
            {
                StreamWriter wr = new StreamWriter(fname, true);
                wr.WriteLine("[Cac tham so cho thu nghiem]");
                wr.WriteLine("[Ten file du lieu]");
                wr.WriteLine(FileName);
                wr.WriteLine("[So thuoc tinh]");
                wr.WriteLine(NoAttribute);
                wr.WriteLine("[So lop let luan]");
                wr.WriteLine(NoConsequenClass);
                wr.WriteLine("[Phuong phap thu nghiem 100-All,50=Fifty-Fold, 10 = ten-Fold, 1-1]");
                if (MethodTest == MethodTestType.LiveOne)
                    wr.WriteLine(1);
                else
                    if (MethodTest == MethodTestType.TenFolder)
                        wr.WriteLine(10);
                    else
                        if (MethodTest == MethodTestType.FiftyFolder)
                            wr.WriteLine(50);
                        else
                            wr.WriteLine(100);
                wr.WriteLine("[Trong so 1=CF1, 2=CFII, 3=CFIII, 4=CFIV,  5=CFV]");
                if (WeightType == RuleWeightType.CFI_CONFIDENT)
                    wr.WriteLine(1);
                else
                    if (WeightType == RuleWeightType.CFII_CONFIDENT_CAVE)
                        wr.WriteLine(2);
                    else
                        if (WeightType == RuleWeightType.CFIII_CONFIDENT_C2ND)
                            wr.WriteLine(3);
                        else
                            if (WeightType == RuleWeightType.CFIV_CONFIDENT_CSUM)
                                wr.WriteLine(4);
                            else
                                wr.WriteLine(5);
                wr.WriteLine("[Phuong phap sang luat 1 - Confident 2-Support 3-Confident*Support]");
                if (PreScreenType == PreScreeningType.Conf)
                    wr.WriteLine(1);
                else
                    if (PreScreenType == PreScreeningType.Supp)
                        wr.WriteLine(2);
                    else
                        wr.WriteLine(3);
                wr.WriteLine("[Phuong phap lap luan 1-Single winer, 2-voted]");
                if (ResionMethod == ResionMethodType.SingleWiner)
                    wr.WriteLine(1);
                else
                    wr.WriteLine(2);
                wr.WriteLine("[Chieu dai toi da cua luat can tao]");
                wr.WriteLine(MaxRuleLength);
                wr.WriteLine("[So luat cua tap luat ung cu S]");
                wr.WriteLine(NoRecievedRules);
                wr.WriteLine("[So luat cua tap luat toi uu]");
                wr.WriteLine(NoTrueReceivedRules);
                /*wr.WriteLine("[He so ham muc tieu w1]");
                wr.WriteLine(W1);
                wr.WriteLine("[He so ham muc tieu w2]");
                wr.WriteLine(W2);*/
                wr.Close();
            }
            catch (IOException ex)
            {
                throw ex;
            }

        }

    }
}
