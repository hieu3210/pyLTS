﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PhD.Common
{
    public enum SGERDFitnessFuntion { FF8, FF10, FF13, FF17}
    public enum Optimal
    {
        HAParameter, FuzzyRulesSystem
    }
    //Các lớp liệt kê 
    public enum RuleWeightType
    {
        CFI_CONFIDENT = 1,
        CFII_CONFIDENT_CAVE = 2,
        CFIII_CONFIDENT_C2ND = 3,
        CFIV_CONFIDENT_CSUM = 4,
        CFV = 5
    }
    public enum PreScreeningType
    {
        Conf = 1, Supp = 2, SuppConf = 3
    }
    public enum MethodTestType
    {
        All = 100,
        LiveOne = 1,
        TenFolder = 10,
        FiftyFolder = 50
    }
    public enum ResionMethodType
    {
        SingleWiner = 1,
        Voted = 2
    }

    public enum ExperimentDataType
    {
        OnTestingData = 1,
        OnTrainingData = 2
    }

    public class LEFTRULE
    {
        public byte HA_Interval_Index;
        public byte K_Level;
        public byte Max_K_Level;

        public LEFTRULE(byte HA_Index, byte k, byte max_k)
        {
            HA_Interval_Index = HA_Index;
            K_Level = k;
            Max_K_Level = max_k;
        }
    }

    public class DontCare
    {
        public static byte Value = byte.MaxValue;
    }

    public class MyRandom
    {
        public static Random rd = new Random();
        public static float Random01()
        {           
            return Convert.ToSingle(rd.NextDouble());///(1.0f*Int32.MaxValue));           
        }
        /// <summary>
        /// Tinh so ngau nhien trong khoang [m,n]
        /// </summary>
        /// <param name="m"></param>
        /// <param name="n"></param>
        /// <returns></returns>
        public static int RandomMtoN(int m, int n)
        {
            int d = n - m+1;
            return rd.Next(d)+ m; 
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        public static byte Flip(float p)
        {
            if (Random01() < p)
                return 1;
            else
                return 0;
        }
        public static int RandomN(int n)
        {
            return rd.Next(n);
        }

        public static float RandomFloatMtoN(float m, float n)
        {
            double d = rd.NextDouble();

            return Convert.ToSingle(((n-m)*d) + m);
        }

    }

    public class MyNewRandom
    {
        public static RandomLib myrand = new RandomLib();

        /// <summary>
        /// Tinh so ngau nhien trong khoang [m,n]
        /// </summary>
        /// <param name="m"></param>
        /// <param name="n"></param>
        /// <returns></returns>
        public static int RandomMtoN(int m, int n)
        {
            return myrand.RandomInt(m, n);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        public static int Flip(float p)
        {
            return myrand.flip(p);
        }
        public static int RandomN(int n)
        {
            return myrand.RandomInt(0, n);
        }

        public static int RandomInt(int lower, int upper)
        {
            return myrand.RandomInt(lower, upper);
        }

        public static float RandomFloatMtoN(float m, float n)
        {
            return Convert.ToSingle(myrand.RandomDouble(m, n));
        }
    }

}
