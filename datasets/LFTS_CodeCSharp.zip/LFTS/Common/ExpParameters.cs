﻿//Các tham số thử nghiệm
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace PhD.Common
{
    public class ExpParameters
    {
        public string FilePath;
        public string FileName;
        public byte NoAttribute;
        public byte NoConsequenClass;
        public MethodTestType MethodTest;
        public ResionMethodType ResionMethod;

        public RuleWeightType WeightType;
        public PreScreeningType PreScreenType;       
        public byte MaxRuleLength;              //Chiều dài tối đa của tập luật cần lấy
        public int NoRecievedRules;             //Số luật ứng cử cần lấy ra
        public int NoTrueReceivedRules;         //Số luật cần lấy ra để kiểm tra
        public float W1;                        //Hệ số hàm mục tiêu
        public float W2;
        public void LoadParameter(string fname)
        {
            try
            {
                StreamReader rd = new StreamReader(fname);
                string s;
                int n;
                FilePath = Path.GetDirectoryName(fname);
                for (int i = 0; i < 19; i++)
                    s = rd.ReadLine();
                //Đọc tên file dữ liệu
                FileName = rd.ReadLine();
                //Đọc số thuộc tính
                s = rd.ReadLine();          //Bỏ qua dòng chú thích
                s = rd.ReadLine();
                NoAttribute = byte.Parse(s);
                //Đọc số lớp kết luận
                s = rd.ReadLine();          //Bỏ qua dòng chú thích
                s = rd.ReadLine();
                NoConsequenClass = byte.Parse(s);
                //Đọc phương pháp thử nghiệm 
                s = rd.ReadLine();          //Bỏ qua dòng chú thích
                s = rd.ReadLine();
                n = Convert.ToInt16(s); 
                if (n == 1)
                    MethodTest = MethodTestType.LiveOne;
                else
                    if (n == 10)
                        MethodTest = MethodTestType.TenFolder;
                    else
                        if (n == 50)
                            MethodTest = MethodTestType.FiftyFolder;
                        else
                            MethodTest = MethodTestType.All;
                //Đọc trọng số
                s = rd.ReadLine();          //Bỏ qua dòng chú thích
                s = rd.ReadLine();
                n = Convert.ToInt16(s); 
                if (n == 1)
                    WeightType = RuleWeightType.CFI_CONFIDENT;
                else
                    if (n == 2)
                        WeightType = RuleWeightType.CFII_CONFIDENT_CAVE;
                    else
                        if (n == 3)
                            WeightType = RuleWeightType.CFIII_CONFIDENT_C2ND;
                        else
                            WeightType = RuleWeightType.CFV;

                 //Đọc sàng luật
                s = rd.ReadLine();          //Bỏ qua dòng chú thích
                s = rd.ReadLine();
                n = Convert.ToInt16(s); 
                if (n == 1)
                    PreScreenType = PreScreeningType.Conf;
                else
                    if (n == 2)
                        PreScreenType = PreScreeningType.Supp;
                    else
                        PreScreenType = PreScreeningType.SuppConf;
                //Đọc phương pháp lập luận
                s = rd.ReadLine();          //Bỏ qua dòng chú thích
                s = rd.ReadLine();
                n = Convert.ToInt16(s); 
                if (n == 1)
                    ResionMethod = ResionMethodType.SingleWiner;
                else
                    ResionMethod = ResionMethodType.Voted;
                //Đọc chiều dài tối đa của luật ứng cử
                s = rd.ReadLine();          //Bỏ qua dòng chú thích
                s = rd.ReadLine();
                MaxRuleLength = Convert.ToByte(s);
                //Đọc số luật ứng cử
                s = rd.ReadLine();          //Bỏ qua dòng chú thích
                s = rd.ReadLine();
                NoRecievedRules = Convert.ToInt16(s);
                //Đọc số luật cần lấy cho tập luật tối ưu
                s = rd.ReadLine();          //Bỏ qua dòng chú thích
                s = rd.ReadLine();
                NoTrueReceivedRules =  Convert.ToInt16(s); ;
                //Đọc hế số hàm mục tiêu w1
                s = rd.ReadLine();          //Bỏ qua dòng chú thích
                s = rd.ReadLine();
                W1 = Convert.ToSingle(s);
                //Đọc hế số hàm mục tiêu w2
                s = rd.ReadLine();          //Bỏ qua dòng chú thích
                s = rd.ReadLine();
                W2 = Convert.ToSingle(s);
                rd.Close();
            }
            catch (IOException ex)
            {
                throw ex;
            }            

        }
        public void SaveParams(string fname)
        {
            try
            {
                StreamWriter wr = new StreamWriter(fname,true);
                wr.WriteLine("[Cac tham so cho thu nghiem]");
                wr.WriteLine("[Ten file du lieu]");
                wr.WriteLine(FileName);
                wr.WriteLine("[So thuoc tinh]");
                wr.WriteLine(NoAttribute);
                wr.WriteLine("[So lop let luan]");
                wr.WriteLine(NoConsequenClass);
                wr.WriteLine("[Phuong phap thu nghiem 100-All,50=Fifty-Fold, 10 = ten-Fold, 1-1]");
                if (MethodTest == MethodTestType.LiveOne)
                    wr.WriteLine(1);
                else
                    if (MethodTest == MethodTestType.TenFolder)
                        wr.WriteLine(10);
                    else
                        if (MethodTest == MethodTestType.FiftyFolder)
                            wr.WriteLine(50);
                        else
                            wr.WriteLine(100);
                wr.WriteLine("[Trong so 1=CF1, 2=CFII, 3=CFIII, 4=CFIV]");
                if (WeightType == RuleWeightType.CFI_CONFIDENT)
                    wr.WriteLine(1);
                else
                    if ( WeightType == RuleWeightType.CFII_CONFIDENT_CAVE)
                       wr.WriteLine(2);
                    else
                        if (WeightType == RuleWeightType.CFIII_CONFIDENT_C2ND)
                            wr.WriteLine(3);
                        else
                            wr.WriteLine(4);
                wr.WriteLine("[Phuong phap sang luat 1 - Confident 2-Support 3-Confident*Support]");               
                if (PreScreenType == PreScreeningType.Conf)
                    wr.WriteLine(1);
                else
                    if (PreScreenType == PreScreeningType.Supp)
                        wr.WriteLine(2);
                    else
                        wr.WriteLine(3);
                wr.WriteLine("[Phuong phap lap luan 1-Single winer, 2-voted]");
                if (ResionMethod == ResionMethodType.SingleWiner)
                    wr.WriteLine(1);
                else
                    wr.WriteLine(2);
                wr.WriteLine("[Chieu dai toi da cua luat can tao]");
                wr.WriteLine(MaxRuleLength);               
                wr.WriteLine("[So luat cua tap luat ung cu S]");
                wr.WriteLine(NoRecievedRules);
                wr.WriteLine("[So luat cua tap luat toi uu]");
                wr.WriteLine(NoTrueReceivedRules);
                wr.WriteLine("[He so ham muc tieu w1]");
                wr.WriteLine(W1);
                wr.WriteLine("[He so ham muc tieu w2]");
                wr.WriteLine(W2);
                wr.Close();
            }
            catch (IOException ex)
            {
                throw ex;
            }            

        }

    }
}
