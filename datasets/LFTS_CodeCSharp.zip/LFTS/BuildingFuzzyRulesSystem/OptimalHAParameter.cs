﻿
//Lớp thực hiện tìm tham số mờ tối ưu của đại số gia tử

using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

using PhD.FRSData;
using PhD.HA;
using PhD.Common;

namespace PhD.BuildingFuzzyRulesSystem
{
    public class OptimalHAParameter : IObjectFunction
    {
        private FRSDatatable _table;
        private FRSDatatable _testingTable;
        private FRSDatatable _trainingTable;
        private FuzzyRulesSystem _frsMaxK;      //Hệ luật độ dài K
        private FuzzyRulesSystem _frsMrules;    //Hệ luật gồm m luật tốt nhất
        private GenerateFRS _genFRS;            //Đối tượng sinh hệ luật     
        private float[] _fmcMinus;
        private float[] _muyL;
        private byte[] _k; //Muc k
        private List<HASFISystem> _listhaSFI;
        private PSOExpParameters _psoparam;

        public FuzzyRulesSystem BestRules
        {
            get { return _frsMrules; }
        }

        public OptimalHAParameter(PSOExpParameters psoparam)
        {
            _psoparam = psoparam;
            _fmcMinus = new float[_psoparam.NoAttribute];
            _muyL = new float[_psoparam.NoAttribute];
            _k = new byte[_psoparam.NoAttribute];
            _listhaSFI = new List<HASFISystem>();
            _table = new FRSDatatable(_psoparam.FilePath + "\\" + _psoparam.FileName, _psoparam.MethodTest, _psoparam.NoAttribute, _psoparam.NoConsequenClass, _psoparam.minValueOfConseqClass, 2);
            _table.LoadData(Path.GetFileNameWithoutExtension(_psoparam.FileName));
            _psoparam.ListOfClassName = _table.ListOfClassName;
            //_table.WritetoFile(FilePathExperiment.FilePath + "iris01.txt");
        }

        #region IObjectFunction Members

        public float[] ObjectiveFunction(List<float> x, int numFun, out FuzzyRulesSystem bRule)
        {
            float[] of;

            of = new float[3];

            of[0] = 0.0f;
            of[1] = 0.0f;
            of[2] = 0.0f;

            bRule = null;

            return of;
        }
        /// <summary>
        /// Thực hiện tối ưu mỗi thuộc tính một bộ tham số
        /// </summary>
        /// <param name="x"></param>
        /// <returns></returns>
        /// out FuzzyRulesSystem bRule

        public float[] ObjectiveFunction(List<float> x, int numFun, out FuzzyRulesSystem bRule, out float[] bCom)
        {
            byte i;
            bCom = new float[3];
            float[] tf = new float[numFun];

            //Xây dựng các hệ khoảng tính mờ cho các thuộc tính
            DeterminHAParam(x, _psoparam.NoAttribute);
            _listhaSFI.Clear();

            for (i = 0; i < _psoparam.NoAttribute; i++)
            {
                HedgeAlgebras ha = new HedgeAlgebras(_fmcMinus[i], _muyL[i]);
                _listhaSFI.Add(new HASFISystem(ha, _k[i]));
                _listhaSFI[i].CreateSFISystem();
                // _listhaSFI[i].WriteHASFISystem(FilePathExperiment.FilePath+"HAparam.txt");
            }
            _genFRS = new GenerateFRS(_table, _listhaSFI, _psoparam);
            //Xây dựng hệ luật mờ
            _genFRS.GenerateFRSMaxLength(_psoparam.MaxRuleLength);
            _frsMaxK = _genFRS.FRSMaxLengthK;       
            _frsMaxK.SortOnClassAndPreScreen();

            for (i = 0; i < 3; i++)
                bCom[i] = 0.0f;

            int count = 0;
            float fitnessFun = 0.0f, per = 0.0f;

            /*i = 1;
            while (i <= _psoparam.NoRecievedRules)
            {
                _frsMrules = _frsMaxK.GetBestRulesAdvance(i * 2); //Chọn ra m luật tốt nhất
                 //Thực hiện phân lớp
                count = Classification();   //Số phân lớp sai
                per = 1.0f - (count * 1.0f / _table.RowsCount); //hiệu quả phân lớp đúng
                bCom[0] += per;
                bCom[1] += _frsMrules.Rules.Count;
                bCom[2] += _frsMrules.AverageLengthOfRules;
                 fitnessFun += per * 0.99f + (1.0f - _frsMrules.Rules.Count * 1.0f / (_psoparam.NoRecievedRules * 2)) * 0.009f + (1.0f - _frsMrules.AverageLengthOfRules / _psoparam.MaxRuleLength) * 0.001f;

                i++;
            }

            for (i = 0; i < 3; i++)
                bCom[i] /= Convert.ToSingle(_psoparam.NoRecievedRules);
            
            tf[0] = fitnessFun / _psoparam.NoRecievedRules;
            */

            _frsMrules = _frsMaxK.GetBestRulesAdvance(_psoparam.NoRecievedRules); //Chọn ra m luật tốt nhất
            //Thực hiện phân lớp
            count = Classification();   //Số phân lớp sai
            per = 1.0f - (count * 1.0f / _table.RowsCount); //hiệu quả phân lớp đúng
            bCom[0] = per;
            bCom[1] = _frsMrules.Rules.Count;
            bCom[2] = _frsMrules.AverageLengthOfRules;
            fitnessFun = per * 0.99f + (1.0f - bCom[2] / _psoparam.MaxRuleLength) * 0.01f;
            tf[0] = fitnessFun;
            bRule = _frsMrules;

            return tf;
        }

        public float[] ObjectiveFunction(List<float> x, int numFun)
        {
            int i, noPattern, count;
            float[] sumOF = new float[3];
            float per;
            bool isOnTestingData = false;
            StreamWriter writer = new StreamWriter(_psoparam.FilePath + "\\detail_results.txt");


            if (_psoparam.ExperimentType == ExperimentDataType.OnTestingData)
                isOnTestingData = true;

            for (i = 0; i < 3; i++)
                sumOF[i] = 0.0f;

            //Xây dựng các hệ khoảng tính mờ cho các thuộc tính
            DeterminHAParam(x, _psoparam.NoAttribute);
            _listhaSFI.Clear();

            for (i = 0; i < _psoparam.NoAttribute; i++)
            {
                HedgeAlgebras ha = new HedgeAlgebras(_fmcMinus[i], _muyL[i]);
                _listhaSFI.Add(new HASFISystem(ha, _k[i]));
                _listhaSFI[i].CreateSFISystem();
                _listhaSFI[i].WriteTermstoFile(_psoparam.FilePath + "\\HATerm"+i.ToString()+".txt");
                _listhaSFI[i].WriteHASFISystem(_psoparam.FilePath + "\\HAparam" + i.ToString() + ".txt");
            }
            _table = new FRSDatatable(_psoparam.FilePath + "\\" + _psoparam.FileName, _psoparam.MethodTest, _psoparam.NoAttribute, _psoparam.NoConsequenClass, _psoparam.minValueOfConseqClass, 2);
            _table.LoadData(Path.GetFileNameWithoutExtension(_psoparam.FileName)); //Nạp và chuẩn hóa dữ liệu
            _psoparam.ListOfClassName = _table.ListOfClassName;
            _table.CreateFolder(); //Tạo các folder
            _table.SaveFolder(_psoparam.FilePath + "\\folder.txt");

            i = 0;
            while (i < _table.FolderCount)
            {
                _table.SetFolderTest(i);
                _testingTable = _table.GetTestingPattern();
                _trainingTable = _table.GetTrainingPattern();
                //GenerateFRS _genFRSMK = new GenerateFRS(_trainingTable, _listhaSFI, _psoparam);
                _genFRS = new GenerateFRS(_trainingTable, _listhaSFI, _psoparam);
                //Xây dựng hệ luật mờ trên dữ liệu huấn luyện
                _genFRS.FRSMaxLengthK.Rules.Clear();
                _genFRS.GenerateFRSMaxLength(_psoparam.MaxRuleLength);  //Sinh hệ luật độ dài k
                _frsMaxK = _genFRS.FRSMaxLengthK;   
                _frsMaxK.SortOnClassAndPreScreen();
                //_frsMaxK.ComputingWeightOnClass();
                //_frsMaxK.WriteToFile(_psoparam.FilePath + "\\Rules\\MaxKRulesOfFolder" + i.ToString() + ".rul");
                _frsMrules = _frsMaxK.GetBestRulesAdvance(_psoparam.NoRecievedRules); //Chọn ra m luật tốt nhất
                //_frsMrules = _frsMaxK.GetBestRulesAdvanceForGLASS(_psoparam.NoRecievedRules); //Chọn ra m luật tốt nhất
                //_frsMrules = _frsMaxK.GetBestRulesAdvanceForYEAST(_psoparam.NoRecievedRules);
                //_frsMrules = _frsMaxK.GetBestRulesAdvanceForHABERMAN(_psoparam.NoRecievedRules);
                //_frsMrules.WriteToFile(_psoparam.FilePath + "\\BestRules\\BestRulesOfFolder" + i.ToString() + ".rul");
                //Thực hiện phân lớp trên tập dữ liệu kiểm tra

                count =0;
                if (isOnTestingData)
                {
                    //Dùng mẫu huấn luyện để sinh luật và dùng mẫu kiểm tra để thử phân lớp
                    count = ClassificationOnTestingData(); //Số phân lớp đúng
                    noPattern = _testingTable.RowsCount;
                }
                else
                {
                    //Dùng mẫu huấn luyện để sinh luật và dùng luôn mẫu huấn luyện để thử phân lớp
                    count = ClassificationOnTrainingData();//Số phân lớp đúng
                    noPattern = _trainingTable.RowsCount;
                }

                per = Convert.ToSingle(count); //Số phân lớp đúng
                sumOF[0] += per / noPattern * 100.0f;
                sumOF[1] += Convert.ToSingle(_frsMrules.Rules.Count);   //Số luật
                sumOF[2] += _frsMrules.AverageLengthOfRules;            //Chiều dài trung bình của luật
                writer.WriteLine("Mau kiem tra so: "+i.ToString());
                writer.WriteLine("So mau kiem tra: " + noPattern.ToString());
                writer.WriteLine("Hieu qua phan lop: " + (per / noPattern * 100.0f).ToString());
                
                i++;
            }
            
            writer.Close();

            //Tính tỷ lệ phân lớp, tỷ lệ số luật và tỷ lệ chiều dài luật trung bình
            for (i = 0; i < 3; i++)
                sumOF[i] /= Convert.ToSingle(_table.FolderCount);

            return sumOF;
                //count*1.0f/_table.RowsCount; // 1.0f / (count / (1.0f * _table.RowsCount));//_w1 * (1 - _frsMrules.AverageLengthOfRules) / _frsMrules.MaxLengthOfRules + _w2 * count/(1.0f*_table.RowsCount);
        }

        public float ObjectiveFunction(List<float> x)
        {
            //Xây dựng các hệ khoảng tính mờ cho các thuộc tính
            DeterminHAParam(x, _psoparam.NoAttribute);
            _listhaSFI.Clear();

            for (byte i = 0; i < _psoparam.NoAttribute; i++)
            {
                HedgeAlgebras ha = new HedgeAlgebras(_fmcMinus[i], _muyL[i]);
                _listhaSFI.Add(new HASFISystem(ha, _k[i]));
                _listhaSFI[i].CreateSFISystem();
                // _listhaSFI[i].WriteHASFISystem(FilePathExperiment.FilePath+"HAparam.txt");
            }
            _table = new FRSDatatable(_psoparam.FilePath + "\\" + _psoparam.FileName, _psoparam.MethodTest, _psoparam.NoAttribute, _psoparam.NoConsequenClass, _psoparam.minValueOfConseqClass, 2);
            _table.LoadData(Path.GetFileNameWithoutExtension(_psoparam.FileName));
            _psoparam.ListOfClassName = _table.ListOfClassName;
            //_table.WritetoFile(FilePathExperiment.FilePath + "iris01.txt");
            _genFRS = new GenerateFRS(_table, _listhaSFI, _psoparam);
            //Xây dựng hệ luật mờ
            _genFRS.GenerateFRSMaxLength(_psoparam.MaxRuleLength);
            _frsMaxK = _genFRS.FRSMaxLengthK;          //Hệ luật_frs = _genFRS.FRSMaxLengthK;         
            //frs.WriteToFile(FilePathExperiment.FilePath + "Rules.rul");
            _frsMaxK.SortOnClassAndPreScreen();
            //frs.WriteToFile(FilePathExperiment.FilePath+"SortedRules.rul");
            _frsMrules = _frsMaxK.GetBestRulesAdvance(_psoparam.NoRecievedRules); //Chọn ra m luật tốt nhất
            //_frsMrules.WriteToFile(_psoparam.FilePath + "\\BestRules.rul");
            //Thực hiện phân lớp
            int count = Classification(); //Số phân lớp đúng

            return count*1.0f/_table.RowsCount; // 1.0f / (count / (1.0f * _table.RowsCount));//_w1 * (1 - _frsMrules.AverageLengthOfRules) / _frsMrules.MaxLengthOfRules + _w2 * count/(1.0f*_table.RowsCount);
        }

        #endregion    

        private void DeterminHAParam(List<float> x, int NoAttribute)
        {
            for (byte i = 0; i < NoAttribute; i++)
            {
                _fmcMinus[i] = x[3 * i];
                _muyL[i] = x[3 * i + 1];
                _k[i] =Convert.ToByte(Math.Ceiling(x[3 * i + 2]));
            }
        }
        /// <summary>
        /// Thực hiện phân lớp trên tập dữ liệu huấn luyện
        /// </summary>
        /// <returns></returns>
        private int Classification()
        {
            int count = 0;
            for (int i = 0; i < _table.RowsCount; i++)
            {
                if (_frsMrules.Resioning(i, _table) != _table.Rows(i).ConseqClass) //phan lop sai
                    count++;
            }

            return count;
        }

        private int ClassificationOnTestingData()
        {
            int count = 0;
            for (int i = 0; i < _testingTable.RowsCount; i++)
            {
                if (_frsMrules.Resioning(i, _testingTable) == _testingTable.Rows(i).ConseqClass)
                    count++;
            }
            return count;
        }

        private int ClassificationOnTrainingData()
        {
            int count = 0;
            for (int i = 0; i < _trainingTable.RowsCount; i++)
            {
                if (_frsMrules.Resioning(i, _trainingTable) == _trainingTable.Rows(i).ConseqClass)
                    count++;
            }
            return count;
        }
        

    }
}
