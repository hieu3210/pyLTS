﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PhD.BuildingFuzzyRulesSystem;

namespace PhD.Common
{
    public interface IObjectFunction
    {          
        float ObjectiveFunction(List<float> x);                           //Hàm mục tiêu
        float[] ObjectiveFunction(List<float> x, int numFun);             //Hàm mục tiêu
        float[] ObjectiveFunction(List<float> x, int numFun, out FuzzyRulesSystem bRule);
        float[] ObjectiveFunction(List<float> x, int numFun, out FuzzyRulesSystem bRule, out float[] bCom);             //Hàm mục tiêu 
    }
}
