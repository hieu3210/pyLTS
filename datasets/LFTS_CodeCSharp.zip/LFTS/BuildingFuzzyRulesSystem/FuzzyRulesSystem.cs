﻿using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using System.Linq;
using System.Text;
using System.IO;
using PhD.FRSData;
using PhD.Common;
using PhD.HA;
namespace PhD.BuildingFuzzyRulesSystem
{
    public class FuzzyRulesSystem
    {
        private List<FuzzyRule> _listRules;
        private PSOExpParameters _params;      
        
        /// <summary>
        /// Danh sách các luật trong hệ luật
        /// </summary>
        public List<FuzzyRule> Rules
        {
            get { return _listRules; }
        }
        /// <summary>
        /// Giá trị lớn nhất chiều dài luật
        /// </summary>
        public int MaxLengthOfRules
        {
            get
            {
                int max = _listRules[0].Length;
                for (int i = 1; i < _listRules.Count; i++)
                    if (max < _listRules[i].Length)
                        max = _listRules[i].Length;
                return max;
            }  
        }
        /// <summary>
        /// Trả lại giá trị trung bình chiều dài của hệ luật
        /// </summary>
        public float AverageLengthOfRules
        {
            get
            {
                float sum = 0.0f;
                for (int i = 0; i < _listRules.Count; i++)
                    sum += Convert.ToSingle(_listRules[i].Length);
                return sum / Convert.ToSingle(_listRules.Count);
            }
        }
        /// <summary>
        /// Hàm tạo
        /// </summary>
        /// <param name="noClass"> Số lớp kết luận của dữ liệu</param>
        public FuzzyRulesSystem(PSOExpParameters param)
        {
            _params = param;
            _listRules = new List<FuzzyRule>();
        }

        /// <summary>
        /// Hàm kiểm tra luật r có trong hệ luật hay không
        /// </summary>
        /// <param name="r">luật cần kiểm tra</param>
        /// <returns></returns>
        public bool Contains(FuzzyRule r)
        {
            for (int i=0;i<_listRules.Count;i++)
                if (r.Equals(_listRules[i]))
                    return true;
            return false;
        }

        public bool ContainLeft(FuzzyRule r)
        {
            for (int i = 0; i < _listRules.Count; i++)
                if (r.EqualLeft(_listRules[i]))
                    return true;
            return false;
        }

        public void CompactRuleset()
        {
            int numrule = _listRules.Count;

            for (int k = 0; k < numrule - 1; k++)
            {
                //int k = l;
                if (!_listRules[k].Selected)
                {
                    for (int i = k + 1; i < numrule; i++)
                    {
                        if (!_listRules[i].Selected)
                        {
                            if (_listRules[k].EqualLeft(_listRules[i]))// && _listRules[k].ConseqClass != _listRules[i].ConseqClass)
                            {
                                if (_listRules[k].Confident < _listRules[i].Confident)
                                {
                                    _listRules[k].Selected = true;
                                    break;
                                }
                                else if (_listRules[k].Confident > _listRules[i].Confident)
                                {
                                    _listRules[i].Selected = true;
                                }
                                else
                                {
                                    if (MyRandom.Flip(0.5f) == 0)
                                    {
                                        _listRules[k].Selected = true;
                                        break;
                                    }
                                    else
                                        _listRules[i].Selected = true;
                                }
                            }
                        }
                    }
                }
            }

            int _k = 0;
            while (_k < numrule)
            {
                if (_listRules[_k].Selected)
                {
                    _listRules.RemoveAt(_k);
                    numrule--;
                }
                else _k++;
            }
        }

        public void ComputePrescreenAndWeight(FRSDatatable table)
        {
            int numrule = _listRules.Count, numpattern = table.RowsCount, numClass = table.ConseqClassCount;

            for (int i = 0; i < _listRules.Count; i++)
            {
                int _i = i;
                byte kmax = 0;
                float tg = 0.0f;
                float[] rCF = new float[numClass];
                float[] rAQ = new float[numClass];
                //Tính tổng mức đốt cháy
                for (byte k = 0; k < numClass; k++)
                {
                    rAQ[k] = 0.0f;
                }
                for (int k = 0; k < numpattern; k++)
                {
                    byte c = table.Rows(k).ConseqClass;
                    //Tính mức đốt cháy của luật i đối với mẫu dữ liệu
                    rAQ[c] += _listRules[_i].MuyAq(table.Rows(k));
                }

                for (byte k = 0; k < numClass; k++) tg += rAQ[k];
                for (byte k = 0; k < numClass; k++)
                {
                    //Tỷ lệ mức đốt cháy của lớp k trên tổng mức đốt cháy
                    if (tg > 0.0f) rCF[k] = rAQ[k] / tg;
                    else rCF[k] = 0.0f;
                    //Mức đốt cháy lớn nhất
                    if (rCF[k] > rCF[kmax]) kmax = k;
                }

                _listRules[_i].ConseqClass = kmax;
                _listRules[_i].Confident = rCF[kmax];
                _listRules[_i].Support = rAQ[kmax] / numpattern;

                //Tính tiêu chuẩn sàng
                if (_params.PreScreenType == PreScreeningType.Conf)
                    _listRules[_i].PreScreen = _listRules[_i].Confident;                    //c
                else
                    if (_params.PreScreenType == PreScreeningType.Supp)
                        _listRules[_i].PreScreen = _listRules[_i].Support;
                    else
                        _listRules[_i].PreScreen = _listRules[_i].Confident * _listRules[_i].Support;     //c*s

                //Tính trọng số của luật
                if (_params.WeightType == RuleWeightType.CFI_CONFIDENT)
                {
                    _listRules[_i].Weight = _listRules[_i].Confident;
                }
                else if (_params.WeightType == RuleWeightType.CFII_CONFIDENT_CAVE)
                {
                    //Tính mức đốt cháy của các lớp khác lớp Cq
                    float tg1 = 0.0f;
                    byte conSeq = _listRules[_i].ConseqClass;
                    for (byte k = 0; k < numClass; k++)
                        if (k != conSeq) tg1 += rCF[k];

                    _listRules[_i].Weight = _listRules[_i].Confident - tg1 / (numClass - 1);
                }
                else if (_params.WeightType == RuleWeightType.CFIII_CONFIDENT_C2ND)
                {
                    //Tìm mức đốt cháy lớn nhất của các lớp khác lớp Cq
                    float sm = -1.0f;
                    byte conSeq = _listRules[_i].ConseqClass;
                    for (byte k = 0; k < numClass; k++)
                    {
                        if (k != conSeq && sm < rCF[k]) sm = rCF[k];
                    }
                    _listRules[_i].Weight = _listRules[_i].Confident - sm;
                }
                else if (_params.WeightType == RuleWeightType.CFIV_CONFIDENT_CSUM)
                {
                    //Tính mức đốt cháy của các lớp khác lớp Cq
                    float tg1 = 0.0f;
                    byte conSeq = _listRules[_i].ConseqClass;
                    for (byte k = 0; k < numClass; k++)
                        if (k != conSeq) tg1 += rCF[k];
                    _listRules[_i].Weight = _listRules[_i].Confident - (tg1 / tg);
                }
                else
                    _listRules[_i].Weight = 1.0f;
            }
        }

        public void ComputePrescreenAndWeight()
        {
            ComputePreScreen();
            ComputeWeight();
        }

        /// <summary>
        /// Tính tiêu chuẩn sàng luật
        /// </summary>
        public void ComputePreScreen()
        {
            for (int i = 0; i < _listRules.Count; i++)
            {
                if (_params.PreScreenType == PreScreeningType.Conf)
                    _listRules[i].PreScreen =_listRules[i].Confident;                    //c
                else
                    if (_params.PreScreenType == PreScreeningType.Supp)
                        _listRules[i].PreScreen = _listRules[i].Support;
                    else
                        _listRules[i].PreScreen = _listRules[i].Confident * _listRules[i].Support ;     //cs
            }
        }

        //Hàm tính trong số của một luật
        public float getRuleWait(FuzzyRule fRule, FuzzyRulesSystem frsSystem)
        {
            float ruleWait = 1.0f;

            if (_params.WeightType == RuleWeightType.CFI_CONFIDENT) 
            {
                ruleWait = fRule.Confident;
            }
            else if (_params.WeightType == RuleWeightType.CFII_CONFIDENT_CAVE) 
            {
                float sum = 0.0f;
                int m = 0;

                for (int j = 0; j < frsSystem.Rules.Count; j++)
                    if (fRule.EqualLeft(frsSystem.Rules[j]) && fRule.ConseqClass != frsSystem.Rules[j].ConseqClass)
                    {
                        sum += frsSystem.Rules[j].Confident;
                        m++;
                    }
                ruleWait = fRule.Confident - sum / (m - 1);
            }
            else if (_params.WeightType == RuleWeightType.CFIII_CONFIDENT_C2ND)
            {
                float max = 0.0f;

                for (int j = 0; j < frsSystem.Rules.Count; j++)
                    if (fRule.EqualLeft(frsSystem.Rules[j]) && fRule.ConseqClass != frsSystem.Rules[j].ConseqClass)
                        if (max < frsSystem.Rules[j].Confident)
                            max = frsSystem.Rules[j].Confident;
                ruleWait = fRule.Confident - max;
            }
            else if (_params.WeightType == RuleWeightType.CFIV_CONFIDENT_CSUM)
            {
                float sum = 0.0f;

                for (int j = 0; j < frsSystem.Rules.Count; j++)
                    if (fRule.EqualLeft(frsSystem.Rules[j]) && fRule.ConseqClass != frsSystem.Rules[j].ConseqClass)
                    {
                        sum += frsSystem.Rules[j].Confident;
                    }
                ruleWait = Convert.ToSingle(Math.Abs(fRule.Confident - sum));
            }

            return ruleWait;
        }

        /// <summary>
        /// Tính trọng số của luật 
        /// </summary>
        private void ComputeWeight()
        {
            if (_params.WeightType == RuleWeightType.CFI_CONFIDENT)
                ComputeWeightCFI();
            else
                if (_params.WeightType == RuleWeightType.CFII_CONFIDENT_CAVE)
                {
                    ComputeWeightCFII();
                }
                else
                    if (_params.WeightType == RuleWeightType.CFIII_CONFIDENT_C2ND)
                        ComputeWeightCFIII();
                    else
                        if (_params.WeightType == RuleWeightType.CFIV_CONFIDENT_CSUM)
                            ComputeWeightCFIV();
                        else
                            for (int i = 0; i < _listRules.Count; i++)
                            {
                                _listRules[i].Weight = 1;
                            }             
        }

        /// <summary>
        /// Tính trọng số của luật 
        /// Với điều kiện là các luật đã được sắp xếp theo lớp kết luận
        /// </summary>
        public void ComputingWeightOnClass()
        {
            if (_params.WeightType == RuleWeightType.CFI_CONFIDENT)
                ComputeWeightCFI();
            else
                if (_params.WeightType == RuleWeightType.CFII_CONFIDENT_CAVE)
                {
                    ComputeWeightOnClassCFII();
                }
                else
                    if (_params.WeightType == RuleWeightType.CFIII_CONFIDENT_C2ND)
                        ComputeWeightOnClassCFIII();
                    else
                        if (_params.WeightType == RuleWeightType.CFIV_CONFIDENT_CSUM)
                            ComputeWeightOnClassCFIV();
                        else
                            for (int i = 0; i < _listRules.Count; i++)
                            {
                                _listRules[i].Weight = 1;
                            }
        }

        private void ComputeWeightCFI()
        {
            for (int i = 0; i < _listRules.Count; i++)
            {
                _listRules[i].Weight = _listRules[i].Confident;
            }
        }

        private void ComputeWeightOnClassCFII()
        {
            int idxmin, idxmax, i, j;
            float sum;
            int m;
            
            for (int conseqClass = 0; conseqClass < _params.NoConsequenClass; conseqClass++)
            {
                DetermineIndexOfClass(conseqClass, out idxmin, out idxmax);
                for (i = idxmin; i <= idxmax; i++)
                {
                    sum = 0.0f; m = 0;
                    for (j = 0; j < idxmin; j++)
                    {
                        if (_listRules[i].EqualLeft(_listRules[j]))
                        {
                            sum += _listRules[j].Confident;
                            m++;
                        }
                    }
                    for (j = idxmax + 1; j < _listRules.Count; j++)
                    {
                        if (_listRules[i].EqualLeft(_listRules[j]))
                        {
                            sum += _listRules[j].Confident;
                            m++;
                        }
                    }
                    _listRules[i].Weight = _listRules[i].Confident - sum / (m - 1);
                }
            }

        }

        private void ComputeWeightCFII()
        {
            float sum;
            int m;
            for (int i = 0; i < _listRules.Count; i++)
            {
                sum = 0.0f; m = 0;
                for(int j=0;j<_listRules.Count;j++)
                    if (_listRules[i].EqualLeft(_listRules[j]) && _listRules[i].ConseqClass != _listRules[j].ConseqClass)
                    {
                        sum += _listRules[j].Confident;
                        m++;
                    }
                _listRules[i].Weight = _listRules[i].Confident - sum / (m - 1);
            }
        }

        private void ComputeWeightOnClassCFIII()
        {
            float max=0.0f;
            int idxmin, idxmax, i, j;

            for (int conseqClass = 0; conseqClass < _params.NoConsequenClass; conseqClass++)
            {
                DetermineIndexOfClass(conseqClass, out idxmin, out idxmax);
                for (i = idxmin; i <= idxmax; i++)
                {
                    max = 0.0f;
                    for (j = 0; j < idxmin; j++)
                    {
                        if (_listRules[i].EqualLeft(_listRules[j]))
                            if (max < _listRules[j].Confident)
                                max = _listRules[j].Confident;
                    }
                    for (j = idxmax + 1; j < _listRules.Count; j++)
                    {
                        if (_listRules[i].EqualLeft(_listRules[j]))
                            if (max < _listRules[j].Confident)
                                max = _listRules[j].Confident;
                    }
                    _listRules[i].Weight = _listRules[i].Confident - max;
                }
            }
        }

        private void ComputeWeightCFIII()
        {
            float max = 0.0f;

            for (int i = 0; i < _listRules.Count; i++)
            {
                max=0.0f;
                for (int j = 0; j < _listRules.Count; j++)
                    if (_listRules[i].EqualLeft(_listRules[j]) && _listRules[i].ConseqClass != _listRules[j].ConseqClass)
                        if (max < _listRules[j].Confident)
                            max = _listRules[j].Confident;
                _listRules[i].Weight = _listRules[i].Confident - max;
            }
        }

        private void ComputeWeightOnClassCFIV()
        {
            float sum;
            int idxmin, idxmax, i, j;

            for (int conseqClass = 0; conseqClass < _params.NoConsequenClass; conseqClass++)
            {
                DetermineIndexOfClass(conseqClass, out idxmin, out idxmax);
                for (i = idxmin; i <= idxmax; i++)
                {
                    sum = 0.0f;
                    for (j = 0; j < idxmin; j++)
                    {
                        if (_listRules[i].EqualLeft(_listRules[j]))
                        {
                            sum += _listRules[j].Confident;
                        }
                    }
                    for (j = idxmax + 1; j < _listRules.Count; j++)
                    {
                        if (_listRules[i].EqualLeft(_listRules[j]))
                        {
                            sum += _listRules[j].Confident;
                        }
                    }
                    _listRules[i].Weight = Convert.ToSingle(_listRules[i].Confident - sum);
                }

            }
        }

        private void ComputeWeightCFIV()
        {
            float sum;
            for (int i = 0; i < _listRules.Count; i++)
            {
                sum = 0.0f;
                for (int j = 0; j < _listRules.Count; j++)
                    if (_listRules[i].EqualLeft(_listRules[j]) && _listRules[i].ConseqClass != _listRules[j].ConseqClass)
                    {
                        sum += _listRules[j].Confident;
                    }
                _listRules[i].Weight = Convert.ToSingle(_listRules[i].Confident - sum);
            }
        }
        /// <summary>
        /// Hàm lấy ra hệ luật gồm m luật tốt nhất
        /// Mỗi lớp lấy ra một số luật tốt nhất
        /// </summary>
        /// <param name="m">Số luật tốt nhất cần lấy</param>
        /// <returns></returns>
        public FuzzyRulesSystem GetBestRules(int m)
        {
            FuzzyRulesSystem frs = new FuzzyRulesSystem(_params);
            int k = m / _params.NoConsequenClass;   //Số luật cần lấy trên mỗi lớp
            int odd = m % _params.NoConsequenClass; //Số luật lẻ
            int t =0;                               //Số luật chưa lấy hết trên các lớp, vì chúng ta muốn lấy
                                                    //ra k luật nhưng trong hệ luật chỉ có số luật < k
            int i, j, d;
            int idxmin, idxmax;
            for (int conseqClass = 0; conseqClass < _params.NoConsequenClass; conseqClass++)
            {
                DetermineIndexOfClass(conseqClass, out idxmin, out idxmax);                
                if (idxmax < idxmin)
                    d = k;
                else
                {
                    i = idxmin;
                    j = 0;
                    while (j < k && i <= idxmax)
                    {
                        frs.Rules.Add(_listRules[i]);
                        _listRules[i].Selected = true;
                        j++;
                        i++;
                    }
                    if (i <= idxmax && odd > 0)
                    {
                        frs.Rules.Add(_listRules[i]);
                        _listRules[i].Selected = true;
                        odd--;
                    }
                    d = k - j;
                }
                t += d; 
            }
            odd += t;  //phần lẻ cộng thêm số luật mà các lớp thiếu
            
            i = _listRules.Count-1;
            while (i > 0) //Loại bỏ các luật đã chọn
            {
                if(_listRules[i].Selected)
                    _listRules.RemoveAt(i);
                i--;
            }          
            i = 0;
            while (i < _listRules.Count && i < odd) //Lây thêm các luật lẻ
            {
                frs.Rules.Add(_listRules[i]);
                _listRules[i].Selected = true;
                i++;
            }
            
            i = _listRules.Count - 1;
            while (i > 0)//bỏ các luật đã chọn
            {
                if (_listRules[i].Selected)
                    _listRules.RemoveAt(i);
                i--;
            }     
            return frs;//trả lại hệ luật được chọn
        }

        //Lấy các luật tốt nhất nhưng không xóa các luật đã chọn trong danh sách luật
        public FuzzyRulesSystem GetBestRulesAdvance(int m)
        {
            FuzzyRulesSystem frs = new FuzzyRulesSystem(_params);
            int k = m / _params.NoConsequenClass;   //Số luật cần lấy trên mỗi lớp
            int odd = m % _params.NoConsequenClass; //Số luật lẻ
            int t = 0;                               //Số luật chưa lấy hết trên các lớp, vì chúng ta muốn lấy
            //ra k luật nhưng trong hệ luật chỉ có số luật < k
            int i, j, d;
            int idxmin, idxmax;
            for (int conseqClass = 0; conseqClass < _params.NoConsequenClass; conseqClass++)
            {
                DetermineIndexOfClass(conseqClass, out idxmin, out idxmax);
                if (idxmax < idxmin)
                    d = k; //Chưa lấy được k luật
                else
                {
                    i = idxmin; //chỉ số nhỏ nhất của lớp hiện tại
                    j = 0;
                    while (j < k && i <= idxmax)
                    {
                        frs.Rules.Add(_listRules[i]);
                        _listRules[i].Selected = true;
                        j++;
                        i++;
                    }
                    if (i <= idxmax && odd > 0)
                    {
                        frs.Rules.Add(_listRules[i]);
                        _listRules[i].Selected = true;
                        odd--;
                    }
                    d = k - j;
                }
                t += d;
            }
            odd += t;  //phần lẻ cộng thêm số luật mà các lớp thiếu

            i = 0; k = 0;
            while (i < _listRules.Count && k < odd) //Lấy thêm các luật lẻ
            {
                if (!_listRules[i].Selected)
                {
                    frs.Rules.Add(_listRules[i]);
                    k++;
                }
                i++;
            }

            for (i = 0; i < _listRules.Count; i++)
                _listRules[i].Selected = false;

            return frs;//trả lại hệ luật được chọn
        }

        //Lấy các luật tốt nhất nhưng không xóa các luật đã chọn trong danh sách luật
        //cho bài toán phân loại kính (GLASS) vì việc sàng luật đối với bài toán này
        //là không đối xứng
        public FuzzyRulesSystem GetBestRulesAdvanceForGLASS(int m)
        {
            FuzzyRulesSystem frs = new FuzzyRulesSystem(_params);
            int k = m / _params.NoConsequenClass;   //Số luật cần lấy trên mỗi lớp
            int odd = m % _params.NoConsequenClass; //Số luật lẻ
            int t = 0;                              //Số luật chưa lấy hết trên các lớp, vì chúng ta muốn lấy
            //ra k luật nhưng trong hệ luật chỉ có số luật < k
            int i, j, d;
            int idxmin, idxmax;
            int[] kr = new int[6];
            switch (m)
            {
                case 6:
                    for (i = 0; i < m; i++)
                        kr[i] = 1;
                    break;
                case 12:
                    kr[0] = 3;
                    kr[1] = 3;
                    kr[2] = 2;
                    kr[3] = 1;
                    kr[4] = 1;
                    kr[5] = 2;
                    break;
                case 18:
                    kr[0] = 5;
                    kr[1] = 5;
                    kr[2] = 3;
                    kr[3] = 1;
                    kr[4] = 1;
                    kr[5] = 3;
                    break;
                case 24:
                    kr[0] = 7;
                    kr[1] = 7;
                    kr[2] = 3;
                    kr[3] = 2;
                    kr[4] = 2;
                    kr[5] = 3;
                    break;
                case 30:
                    kr[0] = 10;
                    kr[1] = 10;
                    kr[2] = 3;
                    kr[3] = 2;
                    kr[4] = 2;
                    kr[5] = 3;
                    break;
                default:
                    for (i = 0; i < m; i++)
                        kr[i] = k;
                    break;
            }

            for (int conseqClass = 0; conseqClass < _params.NoConsequenClass; conseqClass++)
            {
                DetermineIndexOfClass(conseqClass, out idxmin, out idxmax);
                if (idxmax < idxmin)
                    d = k; //Chưa lấy được k luật
                else
                {
                    i = idxmin; //chỉ số nhỏ nhất của lớp hiện tại
                    j = 0;
                    while (j < kr[conseqClass] && i <= idxmax)
                    {
                        frs.Rules.Add(_listRules[i]);
                        _listRules[i].Selected = true;
                        j++;
                        i++;
                    }
                    if (i <= idxmax && odd > 0)
                    {
                        frs.Rules.Add(_listRules[i]);
                        _listRules[i].Selected = true;
                        odd--;
                    }
                    d = k - j;
                }
                t += d;
            }
            odd += t;  //phần lẻ cộng thêm số luật mà các lớp thiếu

            i = 0; k = 0;
            while (i < _listRules.Count && k < odd) //Lấy thêm các luật lẻ
            {
                if (!_listRules[i].Selected)
                {
                    frs.Rules.Add(_listRules[i]);
                    k++;
                }
                i++;
            }

            for (i = 0; i < _listRules.Count; i++)
                _listRules[i].Selected = false;

            return frs;//trả lại hệ luật được chọn
        }

        //Lấy các luật tốt nhất nhưng không xóa các luật đã chọn trong danh sách luật
        //cho bài toán phân loại men sinh hoc (YEAST) vì việc sàng luật đối với bài toán này
        //là không đối xứng
        public FuzzyRulesSystem GetBestRulesAdvanceForYEAST(int m)
        {
            FuzzyRulesSystem frs = new FuzzyRulesSystem(_params);
            int k = m / _params.NoConsequenClass;   //Số luật cần lấy trên mỗi lớp
            int odd = m % _params.NoConsequenClass; //Số luật lẻ
            int t = 0;                              //Số luật chưa lấy hết trên các lớp, vì chúng ta muốn lấy
            //ra k luật nhưng trong hệ luật chỉ có số luật < k
            int i, j, d;
            int idxmin, idxmax;
            int[] kr = new int[10];
            switch (m)
            {
                case 10:
                    for (i = 0; i < m; i++)
                        kr[i] = 1;
                    break;
                case 20:
                    kr[0] = 5;
                    kr[1] = 1;
                    kr[2] = 1;
                    kr[3] = 1;
                    kr[4] = 1;
                    kr[5] = 2;
                    kr[6] = 3;
                    kr[7] = 4;
                    kr[8] = 1;
                    kr[9] = 1;
                    break;
                default:
                    for (i = 0; i < m; i++)
                        kr[i] = k;
                    break;
            }

            for (int conseqClass = 0; conseqClass < _params.NoConsequenClass; conseqClass++)
            {
                DetermineIndexOfClass(conseqClass, out idxmin, out idxmax);
                if (idxmax < idxmin)
                    d = k; //Chưa lấy được k luật
                else
                {
                    i = idxmin; //chỉ số nhỏ nhất của lớp hiện tại
                    j = 0;
                    while (j < kr[conseqClass] && i <= idxmax)
                    {
                        frs.Rules.Add(_listRules[i]);
                        _listRules[i].Selected = true;
                        j++;
                        i++;
                    }
                    if (i <= idxmax && odd > 0)
                    {
                        frs.Rules.Add(_listRules[i]);
                        _listRules[i].Selected = true;
                        odd--;
                    }
                    d = k - j;
                }
                t += d;
            }
            odd += t;  //phần lẻ cộng thêm số luật mà các lớp thiếu

            i = 0; k = 0;
            while (i < _listRules.Count && k < odd) //Lấy thêm các luật lẻ
            {
                if (!_listRules[i].Selected)
                {
                    frs.Rules.Add(_listRules[i]);
                    k++;
                }
                i++;
            }

            for (i = 0; i < _listRules.Count; i++)
                _listRules[i].Selected = false;

            return frs;//trả lại hệ luật được chọn
        }

        //Lấy các luật tốt nhất nhưng không xóa các luật đã chọn trong danh sách luật
        //cho bài toán phân loại HABERMAN vì việc sàng luật đối với bài toán này
        //là không đối xứng
        public FuzzyRulesSystem GetBestRulesAdvanceForHABERMAN(int m)
        {
            FuzzyRulesSystem frs = new FuzzyRulesSystem(_params);
            int k = m / _params.NoConsequenClass;   //Số luật cần lấy trên mỗi lớp
            int odd = m % _params.NoConsequenClass; //Số luật lẻ
            int t = 0;                              //Số luật chưa lấy hết trên các lớp, vì chúng ta muốn lấy
            //ra k luật nhưng trong hệ luật chỉ có số luật < k
            int i, j, d;
            int idxmin, idxmax;
            int[] kr = new int[3];

            switch (m)
            {
                case 3:
                    kr[0] = 2;
                    kr[1] = 1;
                    break;
                case 6:
                    kr[0] = 4;
                    kr[1] = 2;
                    break;
                case 9:
                    kr[0] = 7;
                    kr[1] = 2;
                    break;
                case 12:
                    kr[0] = 9;
                    kr[1] = 3;
                    break;
                case 15:
                    kr[0] = 4;
                    kr[1] = 11;
                    break;
                default:
                    for (i = 0; i < m; i++)
                        kr[i] = k;
                    break;
            }

            for (int conseqClass = 0; conseqClass < _params.NoConsequenClass; conseqClass++)
            {
                DetermineIndexOfClass(conseqClass, out idxmin, out idxmax);
                if (idxmax < idxmin)
                    d = k; //Chưa lấy được k luật
                else
                {
                    i = idxmin; //chỉ số nhỏ nhất của lớp hiện tại
                    j = 0;
                    while (j < kr[conseqClass] && i <= idxmax)
                    {
                        frs.Rules.Add(_listRules[i]);
                        _listRules[i].Selected = true;
                        j++;
                        i++;
                    }
                    if (i <= idxmax && odd > 0)
                    {
                        frs.Rules.Add(_listRules[i]);
                        _listRules[i].Selected = true;
                        odd--;
                    }
                    d = k - j;
                }
                t += d;
            }
            odd += t;  //phần lẻ cộng thêm số luật mà các lớp thiếu

            i = 0; k = 0;
            while (i < _listRules.Count && k < odd) //Lấy thêm các luật lẻ
            {
                if (!_listRules[i].Selected)
                {
                    frs.Rules.Add(_listRules[i]);
                    k++;
                }
                i++;
            }

            for (i = 0; i < _listRules.Count; i++)
                _listRules[i].Selected = false;

            return frs;//trả lại hệ luật được chọn
        }

        //Lấy các luật tốt nhất nhưng không xóa các luật đã chọn trong danh sách luật
        //cho bài toán phân loại WISCONSON vì việc sàng luật đối với bài toán này
        //là không đối xứng
        public FuzzyRulesSystem GetBestRulesAdvanceForWISCONSON_PIMA(int m, string dsname)
        {
            FuzzyRulesSystem frs = new FuzzyRulesSystem(_params);
            int k = m / _params.NoConsequenClass;   //Số luật cần lấy trên mỗi lớp
            int odd = m % _params.NoConsequenClass; //Số luật lẻ
            int t = 0;                              //Số luật chưa lấy hết trên các lớp, vì chúng ta muốn lấy
            //ra k luật nhưng trong hệ luật chỉ có số luật < k
            int i, j, d;
            int idxmin, idxmax;
            int[] kr = new int[3];

            if(dsname.Equals("pima")) {
                kr[0] = m;
                kr[1] = m * 2;
            } else {
                kr[0] = m * 2;
                kr[1] = m;
            }

            for (int conseqClass = 0; conseqClass < _params.NoConsequenClass; conseqClass++)
            {
                DetermineIndexOfClass(conseqClass, out idxmin, out idxmax);
                if (idxmax < idxmin)
                    d = k; //Chưa lấy được k luật
                else
                {
                    i = idxmin; //chỉ số nhỏ nhất của lớp hiện tại
                    j = 0;
                    while (j < kr[conseqClass] && i <= idxmax)
                    {
                        frs.Rules.Add(_listRules[i]);
                        _listRules[i].Selected = true;
                        j++;
                        i++;
                    }
                    if (i <= idxmax && odd > 0)
                    {
                        frs.Rules.Add(_listRules[i]);
                        _listRules[i].Selected = true;
                        odd--;
                    }
                    d = k - j;
                }
                t += d;
            }
            odd += t;  //phần lẻ cộng thêm số luật mà các lớp thiếu

            i = 0; k = 0;
            while (i < _listRules.Count && k < odd) //Lấy thêm các luật lẻ
            {
                if (!_listRules[i].Selected)
                {
                    frs.Rules.Add(_listRules[i]);
                    k++;
                }
                i++;
            }

            for (i = 0; i < _listRules.Count; i++)
                _listRules[i].Selected = false;

            return frs;//trả lại hệ luật được chọn
        }

        //Lấy danh sách các luật theo các chỉ số luật
        public FuzzyRulesSystem GetRulesFromIndices(List<float> ruleIndices)
        {
            /*FuzzyRulesSystem frs = new FuzzyRulesSystem(_params);
            List<int> rExist = new List<int>();

            for (int i = 0; i < ruleIndices.Count; i++)
            {
                //Đổi ra chỉ số của luật trong danh sách luật
                int ruleInd = (int)Math.Round(ruleIndices[i]);
                if (ruleInd >= _listRules.Count) ruleInd = _listRules.Count - 1;
                //if (ruleInd < 0) ruleInd = 0;
                bool isEx = false;
                for (int j = 0; j < rExist.Count; j++ )
                {
                   if (ruleInd == rExist[j])
                    {
                         isEx = true;
                         break;
                    }
                }
                if (!isEx)
                {
                    frs.Rules.Add(_listRules[ruleInd]);
                    rExist.Add(ruleInd);
                }
            }*/

            int ruleIndex;
            FuzzyRulesSystem frs = new FuzzyRulesSystem(_params);

            for (int i = 0; i < ruleIndices.Count; i++)
            {
                //Đổi ra chỉ số của luật trong danh sách luật
                ruleIndex = (int)Math.Round(ruleIndices[i]);
                if (ruleIndex >= _listRules.Count) ruleIndex = _listRules.Count - 1;
                int j;
                for (j = 0; j < frs.Rules.Count; j++)
                {
                    if (_listRules[ruleIndex].Equals(frs.Rules[j]))
                        break;
                }
                if (j >= frs.Rules.Count)
                    frs.Rules.Add(_listRules[ruleIndex]);
            }

            return frs;
        }

        public void SortOnClassAndPreScreen()
        {
            SortOnConsequenceClass();
            SortOnPrescreentInConsequenceClass();

        }
        /// <summary>
        /// Hàm sắp xếp các luật theo thứ tự giảm dần của tiêu chuẩn sàng
        /// trong các lớp
        /// </summary>      
        private void SortOnPrescreentInConsequenceClass()
        {
            int idxmin, idxmax;
            int i = 0, L, R, swap;
            FuzzyRule piv;
            int[] beg = new int[1000];
            int[] end = new int[1000];

            for (int k = 0; k < _params.NoConsequenClass; k++)
            {
                DetermineIndexOfClass(k, out idxmin, out  idxmax);
                i = 0;
                beg[0] = idxmin; end[0] = idxmax + 1;
                while (i >= 0)
                {
                    L = beg[i]; R = end[i] - 1;
                    if (L < R)
                    {
                        piv = _listRules[L];
                        while (L < R)
                        {
                            while (_listRules[R].PreScreen <= piv.PreScreen && L < R) R--;
                            if (L < R) _listRules[L++] = _listRules[R];
                            while (_listRules[L].PreScreen >= piv.PreScreen && L < R) L++;
                            if (L < R) _listRules[R--] = _listRules[L];
                        }
                        _listRules[L] = piv;
                        beg[i + 1] = L + 1;
                        end[i + 1] = end[i];
                        end[i++] = L;
                        if (end[i] - beg[i] > end[i - 1] - beg[i - 1])
                        {
                            swap = beg[i]; beg[i] = beg[i - 1]; beg[i - 1] = swap;
                            swap = end[i]; end[i] = end[i - 1]; end[i - 1] = swap;
                        }
                    }
                    else
                    {
                        i--;
                    }
                }
            }            
        }

        public void SortOnPrescreentInConsequenceClassDesc()
        {
            int idxmin, idxmax;
            int i = 0, L, R, swap;
            FuzzyRule piv;
            int[] beg = new int[1000];
            int[] end = new int[1000];

            for (int k = 0; k < _params.NoConsequenClass; k++)
            {
                DetermineIndexOfClass(k, out idxmin, out  idxmax);
                i = 0;
                beg[0] = idxmin; end[0] = idxmax + 1;
                while (i >= 0)
                {
                    L = beg[i]; R = end[i] - 1;
                    if (L < R)
                    {
                        piv = _listRules[L];
                        while (L < R)
                        {
                            while (_listRules[R].PreScreen >= piv.PreScreen && L < R) R--;
                            if (L < R) _listRules[L++] = _listRules[R];
                            while (_listRules[L].PreScreen <= piv.PreScreen && L < R) L++;
                            if (L < R) _listRules[R--] = _listRules[L];
                        }
                        _listRules[L] = piv;
                        beg[i + 1] = L + 1;
                        end[i + 1] = end[i];
                        end[i++] = L;
                        if (end[i] - beg[i] > end[i - 1] - beg[i - 1])
                        {
                            swap = beg[i]; beg[i] = beg[i - 1]; beg[i - 1] = swap;
                            swap = end[i]; end[i] = end[i - 1]; end[i - 1] = swap;
                        }
                    }
                    else
                    {
                        i--;
                    }
                }
            }
        }

        /*private void SortOnPrescreentInConsequenceClass()
        {
            FuzzyRule r;
            int idxmin, idxmax;
            for (int k = 0; k < _params.NoConsequenClass; k++)
            {
                DetermineIndexOfClass(k, out idxmin, out  idxmax);
                for (int i = idxmin; i < idxmax; i++)
                    for (int j = i + 1; j <= idxmax; j++)
                        if (_listRules[i].PreScreen < _listRules[j].PreScreen)
                        {
                            r = _listRules[i];
                            _listRules[i] = _listRules[j];
                            _listRules[j] = r;
                        }
            }

        }*/

        public void SortOnClassAndWeight()
        {
            SortOnConsequenceClass();
            SortOnWeightInConsequenceClass();

        }
        /// <summary>
        /// Hàm sắp xếp các luật theo thứ tự của lớp kết luận
        /// </summary>
        /// 

        private void SortOnConsequenceClass() {
            int i=0, L, R, swap;
            FuzzyRule piv;
            int[] beg = new int[1000];
            int[] end = new int[1000];

            beg[0] = 0; end[0] = _listRules.Count;
            while (i>=0) {
                L=beg[i]; R=end[i]-1;
                if (L<R) {
                    piv = _listRules[L];
                    while (L<R) {
                        while (_listRules[R].ConseqClass >= piv.ConseqClass && L < R) R--; 
                        if (L < R) _listRules[L++] = _listRules[R];
                        while (_listRules[L].ConseqClass <= piv.ConseqClass && L < R) L++;
                        if (L < R) _listRules[R--] = _listRules[L]; 
                    }
                    _listRules[L] = piv; 
                    beg[i + 1] = L + 1; 
                    end[i + 1] = end[i]; 
                    end[i++] = L;
                    if (end[i]-beg[i]>end[i-1]-beg[i-1]) {
                        swap=beg[i]; beg[i]=beg[i-1]; beg[i-1]=swap;
                        swap=end[i]; end[i]=end[i-1]; end[i-1]=swap; 
                    }
                } else {
                    i--; 
                }
            }
        }

        /*private void SortOnConsequenceClass()
        {
            FuzzyRule r;
            for (int i = 0; i < _listRules.Count - 1; i++)
                for (int j = i+1; j < _listRules.Count; j++)
                    if (_listRules[i].ConseqClass > _listRules[j].ConseqClass)
                    {
                        r = _listRules[i];
                        _listRules[i] = _listRules[j];
                        _listRules[j] = r;
                    }           
        }*/
        /// <summary>
        /// Hàm sắp xếp các luật theo trọng số giảm dần trong từng lớp
        /// </summary>
        /// 

        private void SortOnWeightInConsequenceClass()
        {
            int idxmin, idxmax;
            int i = 0, L, R, swap;
            FuzzyRule piv;
            int[] beg = new int[1000];
            int[] end = new int[1000];

            for (int k = 0; k < _params.NoConsequenClass; k++)
            {
                DetermineIndexOfClass(k, out idxmin, out  idxmax);
                i = 0;
                beg[0] = idxmin; end[0] = idxmax + 1;
                while (i >= 0)
                {
                    L = beg[i]; R = end[i] - 1;
                    if (L < R)
                    {
                        piv = _listRules[L];
                        while (L < R)
                        {
                            while (_listRules[R].Weight <= piv.Weight && L < R) R--;
                            if (L < R) _listRules[L++] = _listRules[R];
                            while (_listRules[L].Weight >= piv.Weight && L < R) L++;
                            if (L < R) _listRules[R--] = _listRules[L];
                        }
                        _listRules[L] = piv;
                        beg[i + 1] = L + 1;
                        end[i + 1] = end[i];
                        end[i++] = L;
                        if (end[i] - beg[i] > end[i - 1] - beg[i - 1])
                        {
                            swap = beg[i]; beg[i] = beg[i - 1]; beg[i - 1] = swap;
                            swap = end[i]; end[i] = end[i - 1]; end[i - 1] = swap;
                        }
                    }
                    else
                    {
                        i--;
                    }
                }
            }
        }

        /*private void SortOnWeightInConsequenceClass()
        {
            FuzzyRule r;
            int idxmin, idxmax;
            for (int k = 0; k < _params.NoConsequenClass; k++)
            {
                DetermineIndexOfClass(k, out idxmin, out  idxmax);
                for (int i = idxmin; i < idxmax; i++)
                    for (int j = i + 1; j <= idxmax; j++)
                        if (_listRules[i].Weight < _listRules[j].Weight)
                        {
                            r = _listRules[i];
                            _listRules[i] = _listRules[j];
                            _listRules[j] = r;
                        }
            }
            
        }*/


        /// <summary>
        /// Hàm sắp xếp các luật theo thứ tự của tiêu chuẩn sàng
        /// </summary>
        /// 

        public void SortOnPrescreen()
        {
            int i = 0, L, R, swap;
            FuzzyRule piv;
            int[] beg = new int[1000];
            int[] end = new int[1000];

            beg[0] = 0; end[0] = _listRules.Count;
            while (i >= 0)
            {
                L = beg[i]; R = end[i] - 1;
                if (L < R)
                {
                    piv = _listRules[L];
                    while (L < R)
                    {
                        while (_listRules[R].PreScreen <= piv.PreScreen && L < R) R--;
                        if (L < R) _listRules[L++] = _listRules[R];
                        while (_listRules[L].PreScreen >= piv.PreScreen && L < R) L++;
                        if (L < R) _listRules[R--] = _listRules[L];
                    }
                    _listRules[L] = piv;
                    beg[i + 1] = L + 1;
                    end[i + 1] = end[i];
                    end[i++] = L;
                    if (end[i] - beg[i] > end[i - 1] - beg[i - 1])
                    {
                        swap = beg[i]; beg[i] = beg[i - 1]; beg[i - 1] = swap;
                        swap = end[i]; end[i] = end[i - 1]; end[i - 1] = swap;
                    }
                }
                else
                {
                    i--;
                }
            }
        }

        public void SortOnWeight()
        {
            int i = 0, L, R, swap;
            FuzzyRule piv;
            int[] beg = new int[1000];
            int[] end = new int[1000];

            beg[0] = 0; end[0] = _listRules.Count;
            while (i >= 0)
            {
                L = beg[i]; R = end[i] - 1;
                if (L < R)
                {
                    piv = _listRules[L];
                    while (L < R)
                    {
                        while (_listRules[R].Weight <= piv.Weight && L < R) R--;
                        if (L < R) _listRules[L++] = _listRules[R];
                        while (_listRules[L].Weight >= piv.Weight && L < R) L++;
                        if (L < R) _listRules[R--] = _listRules[L];
                    }
                    _listRules[L] = piv;
                    beg[i + 1] = L + 1;
                    end[i + 1] = end[i];
                    end[i++] = L;
                    if (end[i] - beg[i] > end[i - 1] - beg[i - 1])
                    {
                        swap = beg[i]; beg[i] = beg[i - 1]; beg[i - 1] = swap;
                        swap = end[i]; end[i] = end[i - 1]; end[i - 1] = swap;
                    }
                }
                else
                {
                    i--;
                }
            }
        }

        /// <summary>
        /// Hàm xác định chỉ số đầu và chỉ số cuối của tập các luật có cùng kết luận là conseqClass trong hệ luật
        /// </summary>
        /// <param name="conseqClass"> Lớp kết luận</param>
        /// <param name="idxmin"></param>
        /// <param name="idxmax"></param>
        private void DetermineIndexOfClass(int conseqClass, out int idxmin, out int idxmax)
        {
            if (conseqClass >= _params.NoConsequenClass)
            {
                idxmin = -1;
                idxmax = -2;
                return; 
            }

            int low = 0, high = _listRules.Count - 1, middle = 0, i = 0;
            while (low <= high)
            {
                middle = low + (high - low) / 2;
                if (conseqClass > _listRules[middle].ConseqClass)
                    low = middle + 1;
                else if (conseqClass < _listRules[middle].ConseqClass)
                    high = middle - 1;
                else
                {
                    i = middle;
                    break;
                }
            }

            while((i >= 0) && (_listRules[i].ConseqClass == conseqClass))
                i--;
            idxmin = i + 1;
            i = middle + 1;
            while((i<_listRules.Count) && (_listRules[i].ConseqClass==conseqClass))
                i++;
            if (i >= _listRules.Count)
                idxmax = _listRules.Count - 1;
            else
                idxmax = i - 1;
        }

        public void GetIndexOfClasses(out int[] idxmin, out int[] idxmax)
        {
            idxmin = new int[_params.NoConsequenClass];
            idxmax = new int[_params.NoConsequenClass];
            int conseqClass = 0, i = 0;

            for (conseqClass = 0; conseqClass < _params.NoConsequenClass; conseqClass++)
            {
                idxmin[conseqClass] = i;
                while ((i < _listRules.Count) && (_listRules[i].ConseqClass == conseqClass))
                    i++;
                if (i >= _listRules.Count)
                    idxmax[conseqClass] = _listRules.Count - 1;
                else
                    idxmax[conseqClass] = i - 1;
            }
        }

        /// <summary>
        /// Lập luận trên mẫu dữ liệu, hàm trả lại lớp kết luận
        /// </summary>
        /// <param name="method">Phương pháp lập luận Single winner hoặc Vote </param>
        /// Trọng số luật phải được tính trước với Single winner
        /// <param name="row">Dòng mẫu dữ liệu</param>
        /// <param name="noConseq">Số lớp</param>
        /// <returns></returns>

        public byte Resioning(FRSRow row, int noConseq)
        {
            float muy, maxmuy;
            int i;
            byte conseqClass;
            if (_params.ResionMethod == ResionMethodType.SingleWiner) //single winner rule
            {
                maxmuy = 0.0f; conseqClass = byte.MaxValue;
                for (i = 0; i < _listRules.Count; i++)
                {
                    muy = _listRules[i].MuyAq(row);
                    muy *= _listRules[i].Weight; //Weight phai duoc tinh san roi
                    if (muy > maxmuy)
                    {
                        maxmuy = muy;
                        conseqClass = _listRules[i].ConseqClass;
                    }
                }
                return conseqClass;
            }
            else //Ver==2 : weighted vote method
            {
                float[] smuy = new float[noConseq];
                for (i = 0; i < noConseq; i++)
                    smuy[i] = 0;
                for (i = 0; i < _listRules.Count; i++)
                {
                    muy = _listRules[i].MuyAq(row);
                    smuy[_listRules[i].ConseqClass] += muy * _listRules[i].Weight;
                }
                byte j;
                for (conseqClass = 0, j = 1; j < noConseq; j++)
                    if (smuy[conseqClass] < smuy[j])
                        conseqClass = j;
                return conseqClass;
            }
        }

        /// <summary>
        /// Lập luận trên mẫu dữ liệu, hàm trả lại lớp kết luận 
        /// </summary>
        /// <param name="method">Phương pháp lập luận Single winner hoặc Vote </param>
        /// Trọng số luật phải được tính trước với Single winner
        /// <param name="rowIndex"> Chỉ số của mẫu dữ liệu trong bảng</param>
        /// <param name="row">Bảng mẫu dữ liệu</param>
        /// <returns></returns>
       
        public byte Resioning(int rowIndex, FRSDatatable table)
        {
            float muy, maxmuy;
            int i; 
            byte conseqClass;
            if (_params.ResionMethod == ResionMethodType.SingleWiner) //single winner rule
            {
                maxmuy = 0.0f; conseqClass = byte.MaxValue;
                for (i = 0; i < _listRules.Count; i++)
                {
                    muy = _listRules[i].MuyAq(table.Rows(rowIndex));
                    muy *= _listRules[i].Weight; //Weight phai duoc tinh san roi
                    if (muy > maxmuy)
                    {
                        maxmuy = muy;
                        conseqClass = _listRules[i].ConseqClass;
                    }
                }
                return conseqClass;
            }
            else //Ver==2 : weighted vote method
            {
                float[] smuy = new float[table.ConseqClassCount];
                for (i = 0; i < table.ConseqClassCount; i++)
                    smuy[i] = 0;
                for (i = 0; i < _listRules.Count; i++)
                {
                    muy = _listRules[i].MuyAq(table.Rows(rowIndex));
                    smuy[_listRules[i].ConseqClass] += muy * _listRules[i].Weight;
                }
                byte j ;
                for (conseqClass = 0, j = 1; j < table.ConseqClassCount; j++)
                    if (smuy[conseqClass] < smuy[j])
                        conseqClass = j;
                return conseqClass;
            }
        }

        public int WriteRuleToFile(StreamWriter writer, List<HASFISystem> _listHASFISystem)
        {
            int HAIndex = 0, noC = 0;
            bool fc = true;
            string strTerm, strT;

            for (int f = 0; f < _listRules.Count; f++)
            {
                fc = true;
                writer.Write("Rule[" + (f + 1).ToString() + "]: IF");
                for (int j = 0; j < _listRules[f].AttibuteCount; j++)
                {
                    HAIndex = _listRules[f][j];
                    if (HAIndex != DontCare.Value)
                    {
                       if(!fc) writer.Write(" AND");
                       strTerm = Revert(_listHASFISystem[j][_listRules[f].GetAttributeKLevel((byte)j) - 1][HAIndex].Term.WordX);
                       strT = strTerm.Substring(strTerm.Length - 1, 1);
                       if (strT.Equals('-')) strTerm = strT + "c-";
                       if (strT.Equals('+')) strTerm = strT + "c+";
                       writer.Write(" F[" + (j + 1).ToString() + "] is (" + strTerm + " <" + _listHASFISystem[j][_listRules[f].GetAttributeKLevel((byte)j) - 1][HAIndex].VxLeft.ToString() + "," + _listHASFISystem[j][_listRules[f].GetAttributeKLevel((byte)j) - 1][HAIndex].Term.Vx.ToString() + "," + _listHASFISystem[j][_listRules[f].GetAttributeKLevel((byte)j) - 1][HAIndex].VxRight.ToString() + ">)");
                       fc = false;
                       noC++;
                    }
                }
                writer.WriteLine(" THEN " + _params.ListOfClassName[_listRules[f].ConseqClass] + " (Class Name)/" + _listRules[f].ConseqClass.ToString() + " (Class Index) [conf = " + _listRules[f].Confident.ToString() + ", supp = " + _listRules[f].Support.ToString() + ", weighted = " + _listRules[f].Weight.ToString() + "]");
            }

            return noC;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="fname"></param>
        public void WriteToFile(string fname)
        {
            StreamWriter writer = new StreamWriter(fname);
            string title = "CD\t";
            for (int j = 0; j < _params.NoAttribute; j++)
            {
                title += "TT-" + j.ToString() + "\t";
            }
            title += "Conseq\tConf\tSupp\tPreScreen\tWeight";
            writer.WriteLine(title);
            for (int i = 0; i < _listRules.Count; i++)
            {
                writer.Write(_listRules[i].Length + "\t"); 
                for (int j = 0; j < _listRules[i].AttibuteCount; j++)
                {
                    writer.Write(_listRules[i][j].ToString() + "\t");
                }
                writer.Write(_listRules[i].ConseqClass.ToString() + "\t");
                writer.Write(_listRules[i].Confident.ToString() + "\t");
                writer.Write(_listRules[i].Support.ToString() + "\t");
                writer.Write(_listRules[i].PreScreen.ToString() + "\t");
                writer.WriteLine(_listRules[i].Weight.ToString());
            }
            writer.Close();
        }

        private string Revert(string s)
        {
            string w = "";
            for (int i = s.Length - 1; i >= 0; i--)
                w = w + s[i];
            w = w.Replace("-", "c-");
            w = w.Replace("+", "c+");
            return w;
        }

    }
}
