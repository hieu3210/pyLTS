﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using PhD.FRSData;
using PhD.HA;
using PhD.Common;
namespace PhD.BuildingFuzzyRulesSystem
{
    public class FuzzyRule
    {
        private List<LEFTRULE> _left;   //Giá trị _left[i]= BFRConstant.Dontcare có nghĩa là don'tcare
        //Giá trị _left[i] != -1 có nghĩa là chỉ số của hạng từ trong hệ khoảng tính mờ ứng với thuộc tính thứ i
        private byte _conseqClass;   //Lớp kết luận được đánh số từ 0 cho đến hết
        private float _weight;      //Trọng số       
        private float _prescreen;   //Giá trị sàng luật       
        private float _support;     //Độ hỗ trợ của luật
        private float _confident;   //Độ tin cậy
        private bool _selected;     //= true luật này được chọn, = false  không được chọn
        private int _length;        //Chiều dài luật
        private int _noAttribute;  //So thuoc tinh
        private float _fitness;      //Giá trị thích nghi của luật cho thuật toán SGERD
        private List<HASFISystem> _listHASFIS;
       /// <summary>
       /// Giá trị lớp kết luận
       /// </summary>
        public byte ConseqClass
        {
            get { return _conseqClass; }
            set { _conseqClass = value; }
        }
        /// <summary>
        /// Trọng số của luật 
        /// </summary>
        public float Weight
        {
            get { return _weight; }
            set { _weight = value; }
        }
        /// <summary>
        /// Giá trị chọn luật (sàng luật)
        /// </summary>
        public float PreScreen
        {
            get { return _prescreen; }
            set { _prescreen = value; }
        }
        /// <summary>
        /// Độ hỗ trợ của luật
        /// </summary>
        public float Support
        {
            get { return _support; }
            set { _support = value; }
        }
        /// <summary>
        /// Độ tin cậy của luật
        /// </summary>
        public float Confident
        {
            get { return _confident; }
            set { _confident = value; }
        }
        /// <summary>
        /// Lấy chỉ số của hạng từ trong hệ khoảng tính mờ của thuộc tính có thứ index
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public byte this[int index]
        {
            get { return _left[index].HA_Interval_Index; }
            //set { _left[index] = value; }
        }
        public bool Selected
        {
            get { return _selected; }
            set { _selected = value; }
        }
        public int Length
        {
            get
            {
                return _length;
            }
            set
            {
                _length = value;
            }
        }
        public int AttibuteCount
        {
            get
            {
                return _noAttribute;
            }
            set
            {
                _noAttribute = value;
            }
        }
        public float Fitness
        {
            get { return _fitness; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="noAttribute"></param>
        public FuzzyRule(int noAttribute, List<HASFISystem> listHASFIS)
        {
            _left = new List<LEFTRULE>();
            for (int i = 0; i < noAttribute; i++)
                _left.Add(new LEFTRULE(DontCare.Value, 0, 0));
            _selected = false;
            _length = 0;
            _noAttribute = noAttribute;
            _listHASFIS = listHASFIS;
        }
        public void SetLeftValue(int attr, byte HA_idx, byte k, byte max_k)
        {
            _left[attr].HA_Interval_Index = HA_idx;
            _left[attr].K_Level = k;
            _left[attr].Max_K_Level = max_k;
        }

        public void SetLeftValue(int attr, byte HA_idx, byte k)
        {
            _left[attr].HA_Interval_Index = HA_idx;
            _left[attr].K_Level = k;
        }

        public void SetLeftKLevel(int attr, byte k)
        {
            _left[attr].K_Level = k;
        }

        public void SetLeftMaxKLevel(int attr, byte max_k)
        {
            _left[attr].Max_K_Level = max_k;
        }

        public byte GetAttributeKLevel(int attr)
        {
            return _left[attr].K_Level;
        }

        public byte GetAttributeMaxKLevel(int attr)
        {
            return _left[attr].Max_K_Level;
        }

        public string GetTerm(int attr)
        {
            if (_left[attr].K_Level == DontCare.Value || _left[attr].HA_Interval_Index == DontCare.Value)
                return "THROWN";

            return _listHASFIS[attr][_left[attr].K_Level - 1][_left[attr].HA_Interval_Index].Term.WordX;
        }

        public bool EqualLeft(FuzzyRule rule)
        {
            if (_length != rule.Length)
                return false;
            for (int i = 0; i < _left.Count; i++)
                if (_left[i].HA_Interval_Index != rule[i] || _left[i].K_Level != rule.GetAttributeKLevel((byte)i))
                    return false;
            return true;
        }
        public bool Equals(FuzzyRule rule)
        {
            if (rule != null)
            {
                if (_length != rule.Length)
                    return false;
                if (_conseqClass != rule.ConseqClass)
                    return false;
                for (int i = 0; i < _left.Count; i++)
                    if (_left[i].HA_Interval_Index != rule[i] || _left[i].K_Level != rule.GetAttributeKLevel((byte)i))
                        return false;
            }

            return true;
        }
        /// <summary>
        /// Hàm xác định độ phù hợp của luật với mẫu dữ liệu 
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        public float MuyAq(FRSRow row)
        {
            float muy = 1.0f;
            for (int i = 0; i < _left.Count; i++)
                if (_left[i].HA_Interval_Index != DontCare.Value)
                    muy *= _listHASFIS[i][_left[i].K_Level - 1][_left[i].HA_Interval_Index].Membership(row[i]);
            return muy;
        }
        
        /// <summary>
        /// Hàm xác định lớp kết luận của luật
        /// </summary>
        /// <param name="table"></param>
        public void DetermineConseqClass(FRSDatatable table)
        {
            int idx = -1;
            float maxMuyAq = float.MinValue;
            float muy;
            for (int i = 0; i < table.RowsCount; i++)
            {
                muy = MuyAq(table.Rows(i));
                if (maxMuyAq < muy)
                {
                    maxMuyAq = muy;
                    idx = i;
                }
            }
            if (idx >= 0 && idx < table.RowsCount)
                _conseqClass = table.Rows(idx).ConseqClass;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="table"></param>
        /// <returns></returns>
        public void ComputingConfAndSupp(FRSDatatable table, PSOExpParameters param)
        {
            float tg = 0.0f;
            int numClass = table.ConseqClassCount, numpattern = table.RowsCount;
            float[] rAQ = new float[numClass];
            float[] rCF = new float[numClass];
            int c, kmax = 0;

            for (int k = 0; k < numClass; k++)
            {
                rAQ[k] = 0.0f;
            }
            for (int k = 0; k < numpattern; k++)
            {
                c = table.Rows(k).ConseqClass;
                //Tính mức đốt cháy của luật i đối với mẫu dữ liệu
                rAQ[c] += MuyAq(table.Rows(k));
            }

            for (int k = 0; k < numClass; k++) tg += rAQ[k];
            for (int k = 0; k < numClass; k++)
            {
                //Tỷ lệ mức đốt cháy của lớp k trên tổng mức đốt cháy
                if (tg > 0.0f) rCF[k] = rAQ[k] / tg;
                else rCF[k] = 0.0f;
                //Mức đốt cháy lớn nhất
                if (rCF[k] > rCF[kmax]) kmax = k;
            }

            //_conseqClass = (byte)kmax;
            _confident = rCF[_conseqClass]; //Độ tin cậy
            _support = rAQ[_conseqClass] / numpattern; //Độ hộ trợ

            //Tính tiêu chuẩn sàng
            if (param.PreScreenType == PreScreeningType.Conf)
                _prescreen = _confident;                    //c
            else
                if (param.PreScreenType == PreScreeningType.Supp)
                    _prescreen = _support;
                else
                    _prescreen = _confident * _support;     //c*s
        }

        #region Computing Fitness function SSGERD
        public void ComputingFitness(SGERDFitnessFuntion fitnessType,FRSDatatable table)
        {
            if (fitnessType == SGERDFitnessFuntion.FF8)
                Fitness8(table);
            if (fitnessType == SGERDFitnessFuntion.FF10)
                Fitness10(table);
            if (fitnessType == SGERDFitnessFuntion.FF13)
                Fitness13(table);
            if (fitnessType == SGERDFitnessFuntion.FF17)
                Fitness17(table);
        }
        private void Fitness8(FRSDatatable table)
        {
            //ComputingConfAndSupp(table);
            _fitness = _confident * _support;
        }
        private void Fitness10(FRSDatatable table)
        {
            float sumpos = 0.0f, sumneg = 0.0f;
            float t;                       
            for (int j = 0; j < _left.Count; j++)              
                for (int i = 0; i < table.RowsCount; i++)
                {
                    t = MuyAq(table.Rows(i));                  
                    if (table.Rows(i).ConseqClass == _conseqClass)
                        sumpos = sumpos + t;
                    else
                        sumneg = sumneg + t;
                }
            _fitness = sumpos - sumneg;
        }
        private void Fitness13(FRSDatatable table)
        {
            float Toj = Convert.ToSingle(Math.Pow(0.5f,_length));
            float sumpos = 0.0f, sumneg = 0.0f;
            float t;
            int gama = 0;
            for (int j = 0; j < _left.Count; j++)
                for (int i = 0; i < table.RowsCount; i++)
                {
                    t = MuyAq(table.Rows(i));
                    if (table.Rows(i).ConseqClass == _conseqClass)
                        sumpos = sumpos + t;
                    else
                        sumneg = sumneg + t;
                    if (t > Toj)
                        gama++;
                }
            _fitness = sumpos - sumneg - gama*(1.0f-Toj);
        }
        private void Fitness17(FRSDatatable table)
        {

        }
        #endregion

    }
}
