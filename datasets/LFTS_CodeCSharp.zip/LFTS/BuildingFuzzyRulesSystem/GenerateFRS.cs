﻿//Lớp thực hiện sinh hệ luật theo thuật toán
using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using System.Linq;
using System.Text;
using System.IO;
using PhD.FRSData;
using PhD.HA;
using PhD.Common;
namespace PhD.BuildingFuzzyRulesSystem
{
    public class GenerateFRS
    {
        private FuzzyRulesSystem _rawFRS;
        private FuzzyRulesSystem _FRSMaxLengthK;    //Hệ luật có độ dài tối đa k
        private FRSDatatable _table;           
        private List<List<int>> _combination;      
        private List<HASFISystem> _listHASFIS;// danh sách các hệ khoảng mờ tương tự ứng với các thuộc tính
        //private ExpParameters _params; 
        private PSOExpParameters _params;


        public GenerateFRS(FRSDatatable table, List<HASFISystem> listHASFIS, PSOExpParameters param)
        {
            _table = table;
            _params = param;
            _rawFRS = new FuzzyRulesSystem(_params);
            _FRSMaxLengthK = new FuzzyRulesSystem(_params);
            _combination = new List<List<int>>();
            _listHASFIS = listHASFIS;
            
        }
        public FuzzyRulesSystem FRSMaxLengthK
        {
            get { return _FRSMaxLengthK; }
        }

        void CopyRule(FuzzyRule rd, FuzzyRule rs)
        {
            for (byte k = 0; k < rs.AttibuteCount; k++)
            {
                rd.SetLeftValue(k, rs[k], rs.GetAttributeKLevel(k), rs.GetAttributeMaxKLevel(k));
                //rd[k] = rs[k];
            }
            rd.AttibuteCount = rs.AttibuteCount;
            rd.Confident = rs.Confident;
            rd.ConseqClass = rs.ConseqClass;
            rd.Length = rs.Length;
            rd.PreScreen = rs.PreScreen;
            rd.Support = rs.Support;
            rd.Weight = rs.Weight;
            rd.Selected = rs.Selected;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="value"></param>
        /// <param name="idxAttibute"></param>
        /// <returns></returns>
        private byte GetIdxSFI(float value, int idxAttibute, out byte k, out byte max_k)
        {
            int K_level = _listHASFIS[idxAttibute].K_Level;

            max_k = (byte)K_level;

            for (byte kk = 0; kk < K_level; kk++)
            {
                k = (byte)(kk + 1);
                for (byte j = 0; j < _listHASFIS[idxAttibute][kk].Count; j++)
                {
                    float mLeft = _listHASFIS[idxAttibute][kk][j].Left;
                    float mRight = _listHASFIS[idxAttibute][kk][j].Right;

                    if (mLeft == mRight && value == mLeft) return j;
                    if (mLeft == 0.0f && mLeft <= value && value <= mRight) return j;
                    if ((mLeft <= value && value < mRight) || (value == mRight)) return j;
                }
            }

            k = byte.MaxValue;
            return byte.MaxValue; //Không tồn tại
        }

        /// <summary>
        /// Sinh hệ luật thô cố độ dài đúng bằng số thuộc tính của tập dữ liệu
        /// </summary>
        private void GenerateRawFRS()
        {
            _rawFRS.Rules.Clear();
            for (int i = 0; i < _table.RowsCount; i++)
            {
                FuzzyRule r = new FuzzyRule(_params.NoAttribute, _listHASFIS);
                r.Length = _params.NoAttribute;
                r.ConseqClass = _table.Rows(i).ConseqClass;
                for (byte j = 0; j < r.Length; j++)
                {
                    byte k = 0, max_k = 0;
                    byte HAIdx = GetIdxSFI(_table.Rows(i)[j], j, out k, out max_k); //Chỉ số của hạng từ trong hệ khoảng tính mờ mức k                     
                    r.SetLeftValue(j, HAIdx, k, max_k);
                }
                _rawFRS.Rules.Add(r);

                /*for (byte j = 0; j < r.Length; j++)
                {
                    string w = r.GetTerm(j);

                    w = w.Substring(w.Length - 1, 1);
                    if (w.Equals(TermConstans.ZERO) || w.Equals(TermConstans.UNIT)) //Term bang "0" hoac bang "1"
                    {
                        byte max_k_level = r.GetAttributeMaxKLevel(j);
                        byte k_level = r.GetAttributeKLevel(j);

                        for (byte k = 0; k < max_k_level; k++)
                        {
                            if (k + 1 != k_level)
                            {
                                FuzzyRule r1 = new FuzzyRule(_params.NoAttribute, _listHASFIS);
                                CopyRule(r1, r);
                                if (w.Equals(TermConstans.UNIT))
                                    r1.SetLeftValue(j, (byte)(_listHASFIS[j][k].Count - 1), (byte)(k + 1), max_k_level); //Vi tri cua "1"
                                else
                                    r1.SetLeftValue(j, r[j], (byte)(k + 1), max_k_level);
                                _rawFRS.Rules.Add(r1);
                            }
                        }
                    }
                }*/
            }
        }

        /// <summary>
        /// Sinh hệ luật có độ dài tối đa maxLength từ hệ luật thô
        /// </summary>
        /// <param name="maxLength">Chiều dài tối đa của luật</param>
        /// <param name="preScreenType">Kiểu sàng luật</param>
        public void GenerateFRSMaxLength(byte maxLength)
        {
            int ruleLength = maxLength;
            byte len;
            _FRSMaxLengthK.Rules.Clear();
             FuzzyRulesSystem temp = new FuzzyRulesSystem(_params);
             long dwOldTime = DateTime.Now.Ticks;
             GenerateRawFRS();
            //_rawFRS.WriteToFile(_params.FilePath +"\\rawrul.txt");
            if (ruleLength >= _params.NoAttribute) ruleLength = _params.NoAttribute;
            for (len = 1; len <= ruleLength; len++)
            {
                Combining(len, _params.NoAttribute);
                //Tạo luật thô
                temp.Rules.Clear();
                for (int i = 0; i < _rawFRS.Rules.Count; i++)
                {
                    int _i = i;
                    byte conSeq = _rawFRS.Rules[_i].ConseqClass;
                    byte len1 = len;

                    for (int j = 0; j < _combination.Count; j++) //Sinh luat co chieu dai len 
                    {
                        FuzzyRule r = new FuzzyRule(_params.NoAttribute, _listHASFIS);
                        r.Length = len1;
                        //Xac dinh cac tien dieu kien cua luat
                        for (int k = 0; k < len1; k++)
                        {
                            byte attr = (byte)_combination[j][k];
                            r.SetLeftValue(attr, _rawFRS.Rules[_i][attr], _rawFRS.Rules[_i].GetAttributeKLevel(attr), _rawFRS.Rules[_i].GetAttributeMaxKLevel(attr));
                        }
                        r.ConseqClass = conSeq;
                        //r.DetermineConseqClass(_table);
                        //Kiem tra luat vua tao co ve trai trung voi cac luat da co trong danh sach
                        //luat hay chua neu chua co thi khong them no vao
                        if (!temp.Contains(r))
                        {
                            //r.ComputingConfAndSupp(_table, _params);
                            temp.Rules.Add(r);
                        }
                    }                    
                }
                temp.ComputePrescreenAndWeight(_table);
                for (int k = 0; k < temp.Rules.Count; k++)
                {
                    if (temp.Rules[k] != null)
                        //if (!_FRSMaxLengthK.Contains(temp.Rules[k]))
                        _FRSMaxLengthK.Rules.Add(temp.Rules[k]);
                }
                //Chọn các luật có trọng số cao nhất trong số các luật có cùng vế trái
                //Kết nhập các luật
            }
            StreamWriter writer;
            string fname = _params.FilePath + "\\Chay_sinh_luat.txt";
            if (File.Exists(fname))
                writer = new StreamWriter(fname);
            else
                writer = File.CreateText(fname);

            long dwTimeElapsed = (DateTime.Now.Ticks - dwOldTime) / TimeSpan.TicksPerSecond;

            writer.WriteLine("Chay sinh luat het: " + dwTimeElapsed.ToString() + " giay");
            writer.Flush();
            _rawFRS.Rules.Clear();
            _FRSMaxLengthK.CompactRuleset();

            dwTimeElapsed = (DateTime.Now.Ticks - dwOldTime) / TimeSpan.TicksPerSecond;
            writer.WriteLine("Chay sinh luat va loai cac luat nhap nhang het: " + dwTimeElapsed.ToString() + " giay");
            writer.Close();
            //MessageBox.Show("Chay het: " + dwTimeElapsed.ToString() + " giay");
            //_FRSMaxLengthK.ComputePrescreenAndWeight(_table);
        }
        
        /// <summary>
        /// Tính tổ hợp các số từ 0 đến n-1 có chiều dài k
        /// </summary>
        /// <param name="k"></param>
        /// <param name="n"></param>
        private void Combining(byte k, int n)
        {
            _combination.Clear();
            List<int>a = new List<int>();
            
            int j;
            for (j = 0; j < k; j++)
                a.Add(j);

            if (k == n)
            {
                List<int> b = new List<int>();
                for (j = 0; j < k; j++)
                    b.Add(a[j]);
                _combination.Add(b);
            }
            else
            {
                int i, p = k;
                while (p >= 0)
                {
                    List<int> b = new List<int>();
                    b.Clear();
                    for (i = 0; i < k; i++)
                        b.Add(a[i]);
                    _combination.Add(b);
                    if (a[k - 1] == n - 1)
                        p = p - 1;
                    else
                        p = k - 1;
                    if (p >= 0)
                        for (i = k - 1; i >= p; i--)
                            a[i] = a[p] + i - p + 1;
                }
            }
            //int w = Combin.size();
 
        }
    }
}
