﻿using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using System.Linq;
using System.Text;
using System.IO;
using PhD.FRSData;
using PhD.HA;
using PhD.Common;

namespace PhD.BuildingFuzzyRulesSystem
{
    public class OptimalRBO : IObjectFunction
    {
        private FRSDatatable _table;
        private FuzzyRulesSystem _frsMaxK;      //Hệ luật độ dài K
        private FuzzyRulesSystem _frsMrules;    //Hệ luật gồm m luật
        private GenerateFRS _genFRS;            //Đối tượng sinh hệ luật     
        private float[] _fmcMinus;
        private float[] _muyL;
        private byte[] _k; //Muc k
        private List<HASFISystem> _listhaSFI;
        private PSOExpParameters _psoparam;
        int _noTrPattern, _noTePattern;

        public FuzzyRulesSystem BestRules
        {
            get { return _frsMrules; }
        }

        public List<HASFISystem> ListOfHASFISystem
        {
            get { return _listhaSFI; }
        }

        public FuzzyRulesSystem MaxKRules
        {
            get { return _frsMaxK; }
        }

        public FRSDatatable DataTable
        {
            get { return _table; }
        }

        public OptimalRBO(PSOExpParameters psoparam)
        {
            _psoparam = psoparam;
            _fmcMinus = new float[_psoparam.NoAttribute];
            _muyL = new float[_psoparam.NoAttribute];
            _k = new byte[_psoparam.NoAttribute];
            _listhaSFI = new List<HASFISystem>();
            _noTrPattern = 0; _noTePattern = 0;
        }

        public void CreateFuzzyRuleSystem(List<float> HAParam)
        {
            //Xây dựng các hệ khoảng tính mờ cho các thuộc tính
            DeterminHAParam(HAParam, _psoparam.NoAttribute);
            _listhaSFI.Clear();

            for (byte i = 0; i < _psoparam.NoAttribute; i++)
            {
                HedgeAlgebras ha = new HedgeAlgebras(_fmcMinus[i], _muyL[i]);
                _listhaSFI.Add(new HASFISystem(ha, _k[i]));
                _listhaSFI[i].CreateSFISystem();
                //_listhaSFI[i].WriteTermstoFile(_psoparam.FilePath + "\\HATerm.txt");
                //_listhaSFI[i].WriteHASFISystem(_psoparam.FilePath +"\\HAparam.txt");
            }
            _table = new FRSDatatable(_psoparam.FilePath + "\\" + _psoparam.FileName, _psoparam.MethodTest, _psoparam.NoAttribute, _psoparam.NoConsequenClass, _psoparam.minValueOfConseqClass, 2);
            _table.LoadData(_psoparam.FilePath + "\\" + _psoparam.FileName);
            //_table.LoadFolder(_psoparam.FilePath + "\\" + "pima-k10-1.rbo");
            _table.CreateFolder(); //Tạo các folder
            _table.SaveFolder(_psoparam.FilePath + "\\folder.txt");
        }

        public void SetExecutionFolder(int i)
        {
            //_table = null;
            //_table = new FRSDatatable(_psoparam.FilePath + "\\" + _psoparam.FileName, _psoparam.MethodTest, _psoparam.NoAttribute, _psoparam.NoConsequenClass, _psoparam.minValueOfConseqClass, 2);
            //_table.LoadKEEL10Data(i, _psoparam.FilePath, Path.GetFileNameWithoutExtension(_psoparam.FileName));
            _psoparam.ListOfClassName = _table.ListOfClassName;
            _table.SetFolderTest(i - 1);
            _noTePattern = _table.NoTestingRows;
            _noTrPattern = _table.NoTrainingRows;
            //GenerateFRS _genFRSMK = new GenerateFRS(_trainingTable, _listhaSFI, _psoparam);
            _genFRS = new GenerateFRS(_table.GetTrainingPattern(), _listhaSFI, _psoparam);
            //Xây dựng hệ luật mờ trên dữ liệu huấn luyện
            _genFRS.FRSMaxLengthK.Rules.Clear();
            _genFRS.GenerateFRSMaxLength(_psoparam.MaxRuleLength);  //Sinh hệ luật độ dài k
            _frsMaxK = _genFRS.FRSMaxLengthK;
            _frsMaxK.SortOnClassAndPreScreen();
            //_frsMaxK.ComputingWeightOnClass();
            _frsMaxK = _frsMaxK.GetBestRulesAdvance(_psoparam.NoConsequenClass * 500);
             _frsMaxK.WriteToFile(_psoparam.FilePath + "\\allrules" + i.ToString() + ".txt");
        }

        #region IObjectFunction Members

        public float[] ObjectiveFunction(List<float> x, int numFun, out FuzzyRulesSystem bRule)
        {
            float[] of;

            of = new float[3];

            of[0] = 0.0f;
            of[1] = 0.0f;
            of[2] = 0.0f;

            bRule = null;

            return of;
        }

        /// <summary>
        /// Thực hiện tối ưu hệ luật
        /// </summary>
        /// <param name="x">Các chỉ số luật được chọn</param>
        /// <param name="numFun">Số hàm mục tiêu</param>
        /// <returns></returns>
        /// out FuzzyRulesSystem bRule

        public float[] ObjectiveFunction(List<float> x, int numFun, out FuzzyRulesSystem bRule, out float[] bCom)
        {
            //Lấy ra hệ luật với số luật cho trước

            _frsMrules = _frsMaxK.GetRulesFromIndices(x); //Chọn ra m luật theo chỉ số luật
            //_frsMrules.WriteToFile(_psoparam.FilePath + "\\BestRules.rul");
            //Thực hiện phân lớp

            float[] tf = new float[numFun];
            int countTe = 0, countTr = 0;
 
            bCom = new float[4];
            //Dùng mẫu huấn luyện để sinh luật và dùng luôn mẫu huấn luyện để thử phân lớp
            countTr = GetErrorOnTraining(_table);//Số phân lớp sai
            //Dùng mẫu kiểm tra để thử phân lớp
            countTe = GetErrorOnTesting(_table); //Số phân lớp sai
 
            bCom[0] = 1.0f - (countTe * 1.0f / _noTePattern); //Số phân lớp đúng tren tap kiem tra
            bCom[1] = 1.0f - (countTr * 1.0f / _noTrPattern); //Số phân lớp đúng tren tap huan luyen
            bCom[2] = _frsMrules.AverageLengthOfRules;            //Chiều dài trung bình của luật
            bCom[3] = Convert.ToSingle(_frsMrules.Rules.Count);   //Số luật
            bRule = _frsMrules;
            tf[0] = bCom[1];// *0.99f + (1.0f - bCom[3] * 1.0f / _psoparam.NoRecievedRules) * 0.009f + (1.0f - bCom[2] / _psoparam.MaxRuleLength) * 0.001f;

            return tf;
        }

        public float[] ObjectiveFunction(List<float> x, int numFun)
        {
            float[] of = new float[numFun];

            of[0] = 100.0f;
            of[1] = 6.0f;
            of[2] = 1.0f;

            return of;
        }

        public float ObjectiveFunction(List<float> x)
        {
            return 1.0f;
        }

        #endregion    

        private void DeterminHAParam(List<float> x, int NoAttribute)
        {
            for (byte i = 0; i < NoAttribute; i++)
            {
                _fmcMinus[i] = x[3 * i];
                _muyL[i] = x[3 * i + 1];
                _k[i] = Convert.ToByte(Math.Ceiling(x[3 * i + 2]));
            }
        }

        public int GetErrorOnTraining(FRSDatatable table)
        {
            int err = 0;
            for (int i = 0; i < table.RowsCount; i++)
            {
                int _i = i;
                FRSRow row = table.Rows(_i);
                byte conClass = row.ConseqClass;
                if (row.IsTesting == false)
                    if (_frsMrules.Resioning(row, table.ConseqClassCount) != conClass)
                        err++;
            }

            return err;
        }

        public int GetErrorOnTesting(FRSDatatable table)
        {
            int err = 0;
            for (int i = 0; i < table.RowsCount; i++)
            {
                int _i = i;
                FRSRow row = table.Rows(_i);
                byte conClass = row.ConseqClass;
                if (row.IsTesting == true)
                    if (_frsMrules.Resioning(row, table.ConseqClassCount) != conClass)
                        err++;
            }

            return err;
        }

    }
}
