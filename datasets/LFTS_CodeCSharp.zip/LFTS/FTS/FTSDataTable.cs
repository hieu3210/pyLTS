﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Text.RegularExpressions;

namespace FTS
{
    public class FTSDataTable
    {
        private List<DataRow> _rows;
        private int _noRow;                 //Số mẫu dữ liệu
        private int _noTestingRows;         //Số mẫu lấy ra để test
        private int _noTraingRows;          //Số mẫu huấn luyện
        private string _fname;
        private int _noAttribute;          //Số thuộc tính
        private float _minValue;
        private float _maxValue;

        public DataRow Rows(int index)
        {
            try
            {
                return _rows[index];
            }
            catch (RankException ex)
            {
                throw ex;
            }

        }
        /// <summary>
        /// Số mẫu dữ liệu
        /// </summary>
        public int RowsCount
        {
            get { return _rows.Count; }
        }

        //Số mẫu test
        public int NoTestingRows
        {
            get { return _noTestingRows; }
        }

        //Số mẫu huấn luyện
        public int NoTrainingRows
        {
            get { return _noTraingRows; }
        }

        public float MinValue
        {
            get { return _minValue; }
        }

        public float MaxValue
        {
            get { return _maxValue; }
        }

        public FTSDataTable(string fname)
        {
            _fname = fname;
            _noRow = 0;
            _noTestingRows = 0;
            _noTraingRows = 0;
            _minValue = -1;
            _maxValue = -1;
            _rows = new List<DataRow>();
        }

        public void Add(DataRow row)
        {
            _rows.Add(row);
        }

        public int LoadData()
        {
            try
            {
                _rows.Clear();
                StreamReader Reader = new StreamReader(_fname);
                string Line = Reader.ReadLine(); //Doc so dong du lieu va so thuoc tinh
                string[] GN1 = Line.Split(new char[] {','});
                _noRow = Int16.Parse(GN1[0].Trim()); //So dong du lieu
                _noAttribute = Int16.Parse(GN1[0].Trim()); //So dong thuoc tinh
                Line = Reader.ReadLine(); //Doc dong min & max
                GN1 = Line.Split(new char[] { ',' });
                _minValue = float.Parse(GN1[0].Trim());
                _maxValue = float.Parse(GN1[1].Trim());
                //Doc cac dong du lieu Timeseries
                for (int i = 0; i < _noRow; i++)
                {
                    Line = Reader.ReadLine();
                    string[] GN = Line.Split(new char[] { ',' });
                    DataRow newrow = new DataRow();
                    for (int j = 0; j < GN.Length; j++)
                    {
                        if(IsNumber(GN[j]))
                            newrow.Add(Convert.ToSingle(GN[j]));
                        else
                            newrow.Add(j + 1);
                    }
                    _rows.Add(newrow);
                }

            }
            catch (IOException ex)
            {
                throw ex;
            }

            return _noRow;
        }

        public bool IsNumber(string pText)
        {
            Regex regex = new Regex(@"^[-+]?[0-9]*\.?[0-9]+$");
            return regex.IsMatch(pText);
        }

    }

}
