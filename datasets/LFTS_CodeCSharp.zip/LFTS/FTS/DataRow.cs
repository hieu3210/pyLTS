﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FTS
{
    public class DataRow
    {
        private List<float> _listElem;
        private List<float> _listClusterIndex;
        private int _dataGroupIndex;
        private int _termIndex;

        public DataRow()
        {
            _listElem = new List<float>();
            _listClusterIndex = new List<float>();
            _dataGroupIndex = -1;
        }

        public float this[int index]
        {
            get { return _listElem[index]; }
            set { _listElem[index] = value; }
        }

        public void Add(float elem)
        {
            _listElem.Add(elem);
            _listClusterIndex.Add(-1.0f);
        }

        public void Add(float elem, float clusIndex)
        {
            _listElem.Add(elem);
            _listClusterIndex.Add(clusIndex);
        }

        public void Remove(int indx)
        {
            _listElem.RemoveAt(indx);
            _listClusterIndex.RemoveAt(indx);
        }

        public int GetColumnCount()
        {
            return _listElem.Count;
        }

        public float GetClusterIndex(int Attr)
        {
            return _listClusterIndex[Attr];
        }

        public void SetClusterIndex(int Attr, float indexValue)
        {
            _listClusterIndex[Attr] = indexValue;
        }

        public int TermIndex
        {
            get
            {
                return _termIndex;
            }
            set
            {
                _termIndex = value;
            }
        }

        public int DataGroupIndex
        {
            get
            {
                return _dataGroupIndex;
            }
            set
            {
                _dataGroupIndex = value;
            }
        }

    }
}
