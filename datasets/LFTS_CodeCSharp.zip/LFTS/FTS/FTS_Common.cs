﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FTS
{
    public enum DefuzzificationMethod
    {
        TVFLRG_Weighted = 1,
        TVFLRG_NoWeight = 2,
        TVFLRG_H_Sub_mkj = 3,
        TVFLRG_Sub_And_mkj = 4,
        TVFLRG_Sub_And_mkj_Weighted = 5,
        TVFLRG_FuzzyWeighted = 6,
        TVFLRG_Sub_mkj = 7,
        TVFLRG_Sub_mkj_Weighted = 8,
        TVFLRG_Proportion = 9
    }

    public enum EvaluationMethod
    {
        MSE = 1,
        RMSE = 2,
        ME = 3
    }

    public enum OrderLevel
    {
        FirstOrder = 1,
        SecondOrder = 2,
        ThirdOrder = 3,
        FourthOrder = 4,
        FifthOrder = 5,
        SixthOrder = 6,
        SeventhOrder = 7,
        EighthOrder = 8,
        NinthOrder = 9
    }

    public class FTS_Parameters
    {
        public string FilePath;
        public string FileName;
        public EvaluationMethod evaluationMethod;
        public DefuzzificationMethod defuzzificationMethod;
        public OrderLevel orderlevel;
        public int NoPartition;
        public float MinValue;
        public float MaxValue;
        public int NumberOfForecastedValue;
        public bool TimeVariant;
        public bool isEliminated;
        public byte kmax;
        public float MuyL;
        public float FmC_minus;
        public bool isChenModel;
    }
}
