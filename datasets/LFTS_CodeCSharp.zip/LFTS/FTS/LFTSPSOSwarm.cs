﻿using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using System.Linq;
using System.Text;
using PhD.PSO;
using PhD.Common;
using System.Windows.Forms;
using System.IO;
using PhD.HA;

namespace FTS
{
    public class LFTSPSOSwarm
    {
        /// <summary>
        //  Khai báo các biến giới hạn các số liệu
        /// </summary>
        private int NumberOfParticle; // Số particle mỗi lần lặp
        private int NumberOfCycle; //Số lần lặp qua các thế hệ
        private int NumberOfDimention; //Số biến tham gia vào bài toán (=3) fm(c-), u(L), kj
        private int NumberOfFunction; //Số hàm mục tiêu
        private int SizeOfRepository; // Kích thước của biến lưu trữ
        /// <summary>
        /// Các danh sách chứa các objects và số liệu tính toán
        /// </summary>
        private List<PSOParticle> _pop; //Quần thể gồm các particle
        private List<ParticleData> _noDomParValues;
        private FTSDataTable _actualData;
        // Các tham số
        private float _C1;
        private float _C2;
        private float _r1;
        private float _r2;
        private float _weight; //Hệ số Inertia
        private float _ssh;
        private float _succ_rate;
        private float _max_weight;
        private float _min_weight;

        //Qua định mục tiêu là cực đại hay cực tiểu
        private int _opt; //min = 0, max =1
        //Các danh sách
        private List<float> _fShar; //hàm chứa fitness sharing.
        private List<float> _nCounts;
        private List<int> _leadC; //chứa leader 
        private List<int> _leaders; //chứa các leader
        private int _lastPart;
        private int NumberOfBadStep;
        // các biến _fShar và _leadC có kích thước bằng số particles trong repository,
        // vì chúng sẽ chứa giá trị với fitness sharing.
        // _leaders có kích thước bằng số particle trong swarm,
        // vì nó là leader mà mỗi particle phải theo.
        // _distance là danh sách sẽ chứa khoảng cách từ particle tới các particle còn lại trong repository.

        private List<List<float>> _distance;
        //Các tham số
        private PSOParameters _params;
        private FTS_Parameters _exparams;
        HASingleSFISystem haSFISys;
        private float pMut;
        private float _MuyL;
        private float _MuyFmCMinus;

        public float MuyL
        {
            get { return _MuyL; }
            set { _MuyL = value; }
        }

        public float MuyFmCMinus
        {
            get { return _MuyFmCMinus; }
            set { _MuyFmCMinus = value; }
        }

        public FTS_Parameters Params
        {
            get { return _exparams; }
        }

        public PSOParameters PSOParams
        {
            get { return _params; }
        }

        public List<ParticleData> DomParValues
        {
            get { return _noDomParValues; }
        }

        public LFTSPSOSwarm(PSOParameters param, FTS_Parameters exparam, FTSDataTable actuData, HASingleSFISystem haSFI)
        {
            int i = 0, j = 0;

            _params = param;
            _exparams = exparam;
            haSFISys = haSFI;
            NumberOfParticle = _params.SizeOfPopulation;
            NumberOfCycle = _params.NoGenerations;
            NumberOfDimention = _params.NumberOfDimension;
            NumberOfFunction = _params.NumberOfFunction;
            SizeOfRepository = _params.SizeOfRepository;
            _opt = _params.Optimization;
            _actualData = actuData;

            //Khởi tạo các khoảng cách đều bằng 0
            _distance = new List<List<float>>();
            for (j = 0; j < SizeOfRepository; j++) //Độ dài bằng kích thước repository
            {
                List<float> a = new List<float>();
                a.Clear();
                for (i = 0; i < SizeOfRepository; i++)
                {
                    a.Add(0);
                }
                _distance.Add(a);
            }
            
            _leadC = new List<int>();
            for (i = 0; i < SizeOfRepository; i++)
                _leadC.Add(0);

            _leaders = new List<int>();
            for (i = 0; i < NumberOfParticle; i++)
                _leaders.Add(0);

            _noDomParValues = new List<ParticleData>();
            _fShar = new List<float>();
            _nCounts = new List<float>();

            //Các hằng số có velocity
            _weight = _params.IntertiaWeight;
            _C1 = _params.C1;
            _C2 = _params.C2;
            _r1 = _params.R1;
            _r2 = _params.R2;
            _succ_rate = 0.0f;
            pMut = 0.1f; //Xác suất đột biến
            _max_weight = 0.8f;
            _min_weight = 0.2f;
            //----------------
            _lastPart = 0;
            NumberOfBadStep = 0;
        }

        public void start_fly(Object obj)
        {
            /// <summary>
            // h -> biến phụ.
            // i, j -> các biến đếm.
            // t -> biến đếm thế hệ.
            // lastPart -> lưu số particle trong repository.
            /// <summary>
            int h, t;
            float ssh_line = 0.0f;
            frmMyProgress frm = obj as PhD.PSO.frmMyProgress;
            StreamWriter writer;
            string fname;
            //float _max_weight = 0.8f, _min_weight = 0.4f;

            //try
            //{
                t = 0;
                frm.SetMax(NumberOfCycle);
                frm.SetCaption("Đang khởi tạo ...");

                fname = _exparams.FilePath + "\\Partition.txt";
                if (File.Exists(fname))
                    writer = new StreamWriter(fname);
                else
                    writer = File.CreateText(fname);

                // Particles are generated randomly
                initpop();
                keepin();

                frm.SetCaption("Khởi tạo xong, đang tính fitness khởi tạo...");

                // Particles are evaluated
                evaluation();
                frm.SetCaption("Tính fitness khởi tạo xong!");

                // Their values are copied to memory
                for (int k = 0; k < NumberOfParticle; k++)
                {
                    PSOLib.copy_array(_pop[k]._fitness, _pop[k]._fbests, NumberOfFunction);
                    PSOLib.copy_array(_pop[k]._pos, _pop[k]._pbests, NumberOfDimention);
                }

                // All particles non-dominated are inserted into the repository.
                search_insert();

                // sigma share is manually set or calculated.
                if (ssh_line > 0.0f)
                    _ssh = ssh_line;
                else
                    _ssh = get_ssh();

                //writer.WriteLine(_ssh.ToString());

                // Calculates fitness sharing for each particle inside the repository
                // generates distances and nCounts
                fitShar();

                frm.SetCaption("Bắt đầu vào vòng lặp!");
                //object _lock = new object();
                do
                {
                    // /////////////////////////////
                    // Calculate 'fitness sharing'//
                    // /////////////////////////////
                    // Assigns the number of times a leader from the repository will be followed
                    // (leaders with better fitness sharing will have a greater
                    // number of chance to be selected,
                    // according to stochastic universal sampling)

                    System.Threading.Thread.Sleep(5);
                    frm.SetCaption("Đang thực hiện đến thế hệ thứ: " + (t + 1).ToString() + "/" + NumberOfCycle.ToString());
                    frm.IncreasePercent();

                    leadAsg();
                    //Each of the particles are assigned a leader from the repository
                    // 'leaders' is the list holding each of the positions
                    leadSel();

                    //_weight = _max_weight - ((_max_weight - _min_weight) * t/ NumberOfCycle);
                    for (int i = 0; i < NumberOfParticle; i++)
                    {
                        // gbest
                        h = _leaders[i];
                        // lbest
                        //h = search_best_neighbor(i);

                        // Selects randomly a leader
                        //h = leadAsg_Random(_lastPart);

                        for (int j = 0; j < NumberOfDimention; j++)
                        {
                            //Tính velocity của particle
                            _pop[i]._vel[j] = _pop[i].velocity(_weight, _pop[i]._vel[j], _C1, _C2, _r1, _r2,
                                                    _pop[i]._pbests[j], _noDomParValues[h].nonDominatedParticle[j], _pop[i]._pos[j]);
                            //if (_pop[i]._vel[j] < -100) _pop[i]._vel[j] = -100;
                            //else if (_pop[i]._vel[j] > 100) _pop[i]._vel[j] = 100;
                        }
                    }

                    for (int i = 0; i < NumberOfParticle; i++)
                    {
                        for (int j = 0; j < NumberOfDimention; j++)
                            //Tính lại vị trí của particle
                            _pop[i]._pos[j] = _pop[i]._pos[j] + _pop[i]._vel[j];
                    }
                    //Xác định lại giá trị để không vượt quá giới hạn quy định
                    keepin();

                    //TÍnh lại giá trị hàm mục tiêu
                    evaluation();

                    search_insert_FS();
                    _succ_rate = ifbest_interchange_moo();

                    if (ssh_line > 0.0f)
                        _ssh = ssh_line;
                    else
                        _ssh = get_ssh();

                    //Ghi ra tep de debug _noDomP
                    writer.WriteLine("The he thu: " + (t + 1).ToString());
                    for (int i = 0; i < _lastPart; i++)
                    {
                        for (int j = 0; j < NumberOfDimention; j++)
                            writer.Write(Math.Ceiling(_noDomParValues[i].nonDominatedParticle[j]).ToString() + " ");
                        for (int j = 0; j < NumberOfFunction; j++)
                            writer.Write("---" + _noDomParValues[i].nonDominatedFitness[j].ToString() + "---");
                        writer.WriteLine("MSE value: " + _noDomParValues[i]._evaluationValue + ", RMSE value: " + (float)Math.Sqrt(_noDomParValues[i]._evaluationValue));
                        writer.Write("Forecasted Data: ");
                        for (int j = 0; j < _noDomParValues[i].NumberOfForcastedValue; j++)
                            writer.Write(_noDomParValues[i].forcastedvalue[j].ToString() + " ");
                        writer.WriteLine();
                    }
                    writer.Flush();

                    // Update the generation counter
                    t++;
                } while (NumberOfCycle > t);
                // End of flight

                writer.Close();

            //} catch (System.Exception ex)
            //{
            //    MessageBox.Show(ex.Message, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //}
            //finally
            //{                
                frm.CloseForm();
            //}
            
        }

        public void start_fly()
        {
            /// <summary>
            // h -> biến phụ.
            // i, j -> các biến đếm.
            // t -> biến đếm thế hệ.
            // lastPart -> lưu số particle trong repository.
            /// <summary>
            int h, t;
            float ssh_line = 0.0f;
            StreamWriter writer;
            string fname;
            //float _max_weight = 0.8f, _min_weight = 0.4f;

            //try
            //{
            t = 0;

            fname = _exparams.FilePath + "\\Partition.txt";
            if (File.Exists(fname))
                writer = new StreamWriter(fname);
            else
                writer = File.CreateText(fname);

            // Particles are generated randomly
            initpop();
            keepin();

            // Particles are evaluated
            evaluation();

            // Their values are copied to memory
            for (int k = 0; k < NumberOfParticle; k++)
            {
                PSOLib.copy_array(_pop[k]._fitness, _pop[k]._fbests, NumberOfFunction);
                PSOLib.copy_array(_pop[k]._pos, _pop[k]._pbests, NumberOfDimention);
            }

            // All particles non-dominated are inserted into the repository.
            search_insert();

            // sigma share is manually set or calculated.
            if (ssh_line > 0.0f)
                _ssh = ssh_line;
            else
                _ssh = get_ssh();

            //writer.WriteLine(_ssh.ToString());

            // Calculates fitness sharing for each particle inside the repository
            // generates distances and nCounts
            fitShar();

            do
            {
                // /////////////////////////////
                // Calculate 'fitness sharing'//
                // /////////////////////////////
                // Assigns the number of times a leader from the repository will be followed
                // (leaders with better fitness sharing will have a greater
                // number of chance to be selected,
                // according to stochastic universal sampling)

                System.Threading.Thread.Sleep(5);

                leadAsg();
                //Each of the particles are assigned a leader from the repository
                // 'leaders' is the list holding each of the positions
                leadSel();

                //_weight = _max_weight - ((_max_weight - _min_weight) * t/ NumberOfCycle);
                for (int i = 0; i < NumberOfParticle; i++)
                {
                    // gbest
                    h = _leaders[i];
                    // lbest
                    //h = search_best_neighbor(i);

                    // Selects randomly a leader
                    //h = leadAsg_Random(_lastPart);

                    for (int j = 0; j < NumberOfDimention; j++)
                    {
                        //Tính velocity của particle
                        _pop[i]._vel[j] = _pop[i].velocity(_weight, _pop[i]._vel[j], _C1, _C2, _r1, _r2,
                                                _pop[i]._pbests[j], _noDomParValues[h].nonDominatedParticle[j], _pop[i]._pos[j]);
                        //if (_pop[i]._vel[j] < -100) _pop[i]._vel[j] = -100;
                        //else if (_pop[i]._vel[j] > 100) _pop[i]._vel[j] = 100;
                    }
                }

                for (int i = 0; i < NumberOfParticle; i++)
                {
                    for (int j = 0; j < NumberOfDimention; j++)
                        //Tính lại vị trí của particle
                        _pop[i]._pos[j] = _pop[i]._pos[j] + _pop[i]._vel[j];
                }
                //Xác định lại giá trị để không vượt quá giới hạn quy định
                keepin();

                //TÍnh lại giá trị hàm mục tiêu
                evaluation();

                search_insert_FS();
                _succ_rate = ifbest_interchange_moo();

                if (ssh_line > 0.0f)
                    _ssh = ssh_line;
                else
                    _ssh = get_ssh();

                //Ghi ra tep de debug _noDomP
                writer.WriteLine("The he thu: " + (t + 1).ToString());
                int k = 0;
                for (int i = 0; i < _lastPart; i++)
                {
                    for (int j = 0; j < NumberOfDimention; j++)
                    {
                        k = (int)Math.Round(_noDomParValues[i].nonDominatedParticle[j], 0);
                        if (j < NumberOfDimention - 1)
                            writer.Write(k.ToString() + " (" + _noDomParValues[i].HASystem.Revert(_noDomParValues[i].HASystem[k].Term.WordX) + "), ");
                        else
                            writer.Write(k.ToString() + " (" + _noDomParValues[i].HASystem.Revert(_noDomParValues[i].HASystem[k].Term.WordX) + ")");
                    }
                    for (int j = 0; j < NumberOfFunction; j++)
                        writer.Write("---" + _noDomParValues[i].nonDominatedFitness[j].ToString() + "---");
                    writer.WriteLine();
                    writer.WriteLine("MSE value: " + _noDomParValues[i]._evaluMSE + ", RMSE value: " + (float)Math.Sqrt(_noDomParValues[i]._evaluMSE) + ", ME value: " + _noDomParValues[i]._evaluME + ", MAPE value: " + _noDomParValues[i]._evaluMAPE);
                    writer.Write("Forecasted Data: ");
                    for (int j = 0; j < _noDomParValues[i].NumberOfForcastedValue; j++)
                        writer.Write(_noDomParValues[i].forcastedvalue[j].ToString() + " ");
                    writer.WriteLine();
                }
                writer.Flush();

                // Update the generation counter
                t++;
            } while (NumberOfCycle > t);
            // End of flight

            writer.Close();

            //} catch (System.Exception ex)
            //{
            //    MessageBox.Show(ex.Message, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //}
            //finally
            //{                
            //}

        }

        /// <summary>
        //Bắt đầu các hàm thư viện của PSO
        /// <summary>

        //Hàm khởi tạo ban đầu

        void initpop()
        {
            int i, j;
            float x;
            _pop = new List<PSOParticle>();

            for (i = 0; i < NumberOfParticle; i++)
            {
                PSOParticle a = new PSOParticle(_params);
                for (j = 0; j < NumberOfDimention; j++)
                {
                    //Ngẫu nhiên từ LowerBound đến UpperBound
                    x = MyRandom.RandomFloatMtoN(_params.LowBound[j], _params.UpBound[j]);
                    a._pos.Add(x);
                }
                //Thêm vào danh sách các Particle
                _pop.Add(a);
            }
        }

        void reinitpop(int i)
        {
            int j;
            float x;

            for (j = 0; j < NumberOfDimention; j++)
            {
                //Ngẫu nhiên từ LowerBound đến UpperBound
                x = MyRandom.RandomFloatMtoN(_params.LowBound[0], _params.UpBound[j]);
                _pop[i]._pos[j] = x;
                //_pop[i]._vel[j] = 0.0f;
            }
        }

        //Hàm tính giá trị hàm mục tiêu của particle
        //private void evaluation(List<PSOParticle> pop, float[] fitness, int M, int D, int NF)
        private void evaluation()
        {
            int i, j, n;
            float[] of = new float[NumberOfFunction];
            List<float> fcv = new List<float>();
            float ev;

            for (i = 0; i < NumberOfParticle; i++)
            {
                List<float> partiList = new List<float>();
                LinguisticFuzzyTimeSeries _fts = new LinguisticFuzzyTimeSeries(_exparams, _actualData);
                for (j = 0; j < _pop[i]._pos.Count; j++)
                    partiList.Add(_pop[i]._pos[j]);

                _fts.SetupNewPartition(partiList);
                _fts.SetNewMetaParameter(_MuyFmCMinus, _MuyL);
                _fts.StartForecasting(false, haSFISys);
                _pop[i]._fitness.Clear();
                ev = _fts.GetEvaluationValue();
                _pop[i]._fitness.Add(ev);
                _pop[i]._evaluationValue = ev;
                _pop[i]._evaluMAPE = _fts.GetMAPEValue();
                _pop[i]._evaluMSE = _fts.GetMSEValue();
                _pop[i]._evaluME = _fts.GetMEValue();
                fcv = _fts.GetForecastedValue();
                n = _pop[i]._noDomFCV.Count;
                for (j = 0; j < fcv.Count; j++)
                {
                    if (j < n)
                        _pop[i]._noDomFCV[j] = fcv[j];
                    else
                        _pop[i]._noDomFCV.Add(fcv[j]);
                }
                _pop[i].HASystem = _fts.HASystem;                    
            }
        }

        //Hàm giới hạn giá trị các biến
        void keepin(int i)
        {
            int j;

            for (j = 0; j < NumberOfDimention; j++)
            {
                if (_pop[i]._pos[j] < _params.LowBound[j])
                {
                    //if (MyRandom.Flip(0.5f) != 0)
                    _pop[i]._pos[j] = MyRandom.RandomFloatMtoN(_params.LowBound[j], _params.LowBound[j] + (_params.UpBound[j] - _params.LowBound[j]) * 0.25f);
                    //else 
                    //_pop[i]._pos[j] = _params.LowBound[j];
                    _pop[i]._vel[j] = -_pop[i]._vel[j];
                }
                if (_pop[i]._pos[j] > _params.UpBound[j])
                {
                    //if (MyRandom.Flip(0.5f) != 0)
                    _pop[i]._pos[j] = MyRandom.RandomFloatMtoN(_params.LowBound[j] + (_params.UpBound[j] - _params.LowBound[j]) * 0.25f, _params.UpBound[j]);
                    //else
                    //_pop[i]._pos[j] = _params.UpBound[j];
                    _pop[i]._vel[j] = -_pop[i]._vel[j];
                }
            }
            _pop[i]._pos.Sort();
        }

        void keepin()
        {
            int i, j;

            for (i = 0; i < NumberOfParticle; i++)
            {
                for (j = 0; j < NumberOfDimention; j++)
                {
                    if (_pop[i]._pos[j] < _params.LowBound[j])
                    {
                        //if (MyRandom.Flip(0.5f) != 0)
                        _pop[i]._pos[j] = MyRandom.RandomFloatMtoN(_params.LowBound[j], _params.LowBound[j] + (_params.UpBound[j] - _params.LowBound[j]) * 0.25f);
                        //else 
                        //_pop[i]._pos[j] = _params.LowBound[j];
                        //_pop[i]._vel[j] = -_pop[i]._vel[j];
                    }
                    if (_pop[i]._pos[j] > _params.UpBound[j])
                    {
                        //if (MyRandom.Flip(0.5f) != 0)
                        _pop[i]._pos[j] = MyRandom.RandomFloatMtoN(_params.UpBound[j] - (_params.UpBound[j] - _params.LowBound[j]) * 0.25f, _params.UpBound[j]);
                        //else
                        //_pop[i]._pos[j] = _params.UpBound[j];
                        //_pop[i]._vel[j] = -_pop[i]._vel[j];
                    }

                    if (_exparams.isEliminated)
                    {
                        int curval = (int)Math.Round(_pop[i]._pos[j], 0);
                        int k = NumberOfDimention - 1;
                        float b = 0, c = _pop[i]._pos[j];
                        while (k >= 0)
                        {
                            int val = (int)Math.Round(_pop[i]._pos[k], 0);
                            if (curval == val && k != j)
                            {
                                bool iswb = true;
                                int a;
                                while (iswb)
                                {
                                    b = MyRandom.RandomFloatMtoN(_params.LowBound[j], _params.UpBound[j]);
                                    a = (int)Math.Round(b, 0);
                                    int l = 0;
                                    while (l < NumberOfDimention)
                                    {
                                        if (a == (int)Math.Round(_pop[i]._pos[l], 0) || a == curval) break;
                                        l++;
                                    }
                                    if (l >= NumberOfDimention)
                                    {
                                        curval = a;
                                        c = b;
                                        iswb = false;
                                    }
                                }
                            }
                            k--;
                        }
                        if (_pop[i]._pos[j] != c) _pop[i]._pos[j] = c;
                    }
                }
                
                _pop[i]._pos.Sort();
                
            }   
        }

        private int search_max(float[] f, int M)
        {
            int i, fmax = 0;

            for (i = 1; i < M; i++)
                if (f[fmax] < f[i])
                    fmax = i;
            return fmax;
        }

        private int search_max(int[] f, int M)
        {
            int i, fmax = 0;

            for (i = 1; i < M; i++)
                if (f[fmax] < f[i])
                    fmax = i;
            return fmax;
        }

        private int search_max(List<float> f, int M)
        {
            int i, fmax = 0;

            for (i = 1; i < M; i++)
                if (f[fmax] < f[i])
                    fmax = i;
            return fmax;
        }

        private int search_min(float[] f, int M)
        {
            int i, fmin = 0;

            for (i = 1; i < M; i++)
                if (f[fmin] > f[i])
                    fmin = i;
            return fmin;
        }

        private int search_min(int[] f, int M)
        {
            int i, fmin = 0;

            for (i = 1; i < M; i++)
                if (f[fmin] > f[i])
                    fmin = i;
            return fmin;
        }

        private int search_min(List<float> f, int M)
        {
            int i, fmin = 0;

            for (i = 1; i < M; i++)
                if (f[fmin] > f[i])
                    fmin = i;
            return fmin;
        }

// /////////////////////////////////////////////////////
//MULTI-OBJETIVE
// /////////////////////////////////////////////////////
        int best_moo(int k) 
        {
            int best, deflt = 0;
            int i;

            //Adapted from PAES code :
            for(i = 0; i < NumberOfFunction; i++) {
                if (((_pop[k]._fitness[i] < _pop[k]._fbests[i]) && (_opt == 0)) || ((_pop[k]._fitness[i] > _pop[k]._fbests[i]) && (_opt == 1)))
	                best = 1;
                else if (((_pop[k]._fitness[i] > _pop[k]._fbests[i]) && (_opt == 0)) || ((_pop[k]._fitness[i] < _pop[k]._fbests[i]) && (_opt == 1)))
	                best = -1;
                else
	                best = 0;
                if ((best != 0) && (best == -deflt))
                    return MyRandom.Flip(0.5f);
                if(best!= 0)
	                deflt = best;
            }

            switch(deflt) {
            case 1 : i = 1 ;
                break ;
            case -1: i = 0 ;
                break ;
            case 0: i = MyRandom.Flip(0.5f);
                break ;
            }

            return i ;
        }

        //Returns the number of particles that swaped their old positions for the
        //new ones + swaps the positions in their memories
        int ifbest_interchange_moo()
        {
	        int i, cont = 0;

	        for(i = 0; i < NumberOfParticle; i++) {
                if (best_moo(i)!=0)
                {
                    PSOLib.copy_array(_pop[i]._fitness, _pop[i]._fbests, NumberOfFunction);
                    PSOLib.copy_array(_pop[i]._pos, _pop[i]._pbests, NumberOfDimention);
                    _pop[i]._isBestMove = true;
                    cont++;
                }
                else _pop[i]._isBestMove = false;
	        }
	        return cont;
        }

        // compares two vectors of objective values
        // returns :
        // 1 if first dominates second,
        // 2 if second dominates first ,
        // 3 otherwise
        int compVec(int h, int i)
        {
	        int best, deflt = 0;
	        int j ;

            //Adapted from PAES code :
            for (j = 0; j < NumberOfFunction; j++)
            {
                if (((_noDomParValues[h].nonDominatedFitness[j] < _noDomParValues[i].nonDominatedFitness[j]) && (_opt == 0))
                    || ((_noDomParValues[h].nonDominatedFitness[j] > _noDomParValues[i].nonDominatedFitness[j]) && (_opt == 1)))
			        best = 1;
                else if (((_noDomParValues[h].nonDominatedFitness[j] > _noDomParValues[i].nonDominatedFitness[j]) && (_opt == 0))
                    || ((_noDomParValues[h].nonDominatedFitness[j] < _noDomParValues[i].nonDominatedFitness[j]) && (_opt == 1)))
			        best = -1;
		        else
			        best = 0 ;
		        if((best !=0) && (best == -deflt))
			        return 3 ;
                if (best != 0)
                    deflt = best;
	        }

	        switch (deflt) {
	        case 1: j = 1;
		        break;
	        case -1: j = 2;
		        break;
	        case 0: j = 3;
		        break ;
	        }

	        return j ;
        }

        void delPartDom() {
	        int h, i;

	        h = 0;
	        i = h + 1;
	        do {
		        do {
			        if(_lastPart > 1) {
                        switch (compVec(h, i))
                        {
				            /* In case 1 and 2 the particles are eliminated, 
				            because they have been dominated by the h (case 1) or i (case 2)*/
                            case 1:
                                _noDomParValues.RemoveAt(i);
                                _lastPart--;
                                break;
                            case 2:
                                _noDomParValues.RemoveAt(h);
                                _lastPart--;
                                i = h + 1;
                                break;
                            case 3:
                                i++;
                                break;
                        }
			        }
		        } while((i < _lastPart) && (_lastPart > 1));
		        h++;
		        i = h + 1;
	        } while ((h<_lastPart - 1) && (_lastPart > 1));
        }

        void search_insert() {
	        int k, j;
            ParticleData pa = new ParticleData(NumberOfDimention, NumberOfFunction, _exparams.NumberOfForecastedValue);

	        //Copy all the particles into the repository
            for (k = 0; k < NumberOfParticle; k++)
            {
                for (j = 0; j < NumberOfDimention; j++)
                {
                    pa.nonDominatedParticle[j] = _pop[k]._pos[j];
                }
                for (j = 0; j < NumberOfFunction; j++)
                {
                    pa.nonDominatedFitness[j] = _pop[k]._fitness[j];
                }
                for (j = 0; j < _pop[k]._noDomFCV.Count; j++)
                {
                    pa.forcastedvalue[j] = _pop[k]._noDomFCV[j];
                }
                pa._evaluationValue = _pop[k]._evaluationValue;
                pa._evaluMAPE = _pop[k]._evaluMAPE;
                pa._evaluME = _pop[k]._evaluME;
                pa._evaluMSE = _pop[k]._evaluMSE;
                pa.HASystem = _pop[k].HASystem;
                _noDomParValues.Add(pa);
                _lastPart++;
            }
	        // deletes dominated particles
	        delPartDom();
        }

        // compares two vectors of objective values
        // returns:
        // 1 if first dominates second,
        // 2 if second dominates first,
        // 3 other wise

        int compVec2 (int h, int i) {
	        int best , deflt = 0;
	        int j ;

            // Adapted from PAES code :
	        for(j = 0; j < NumberOfFunction; j++) {
                if (((_noDomParValues[h].nonDominatedFitness[j] < _pop[i]._fitness[j]) && (_opt == 0)) ||
                    (((_noDomParValues[h].nonDominatedFitness[j] > _pop[i]._fitness[j])) && (_opt == 1)))
                    best = 1;
                else if (((_noDomParValues[h].nonDominatedFitness[j] > _pop[i]._fitness[j]) && (_opt == 0)) ||
                    ((_noDomParValues[h].nonDominatedFitness[j] < _pop[i]._fitness[j]) && (_opt == 1)))
			        best = -1;
		        else
			        best = 0;
		        if((best!=0) && (best == -deflt))
			        return 3;
		        if(best != 0)
			        deflt = best;
	        }

	        switch (deflt) {
	        case 1: j = 1;
		        break;
	        case -1: j = 2;
		        break;
	        case 0: j = 3;
		        break ;
	        }

	        return j;
        }

        //Search for the boundaries of every dimension in the objective space
        void search_limits(ref int[] lsup, ref int[] linf)
        { //Xem lại sau
            float[] aux = new float[SizeOfRepository];
	        int i, j;

            for (j = 0; j < NumberOfFunction; j++)
	        {
		        for (i = 0; i < _lastPart; i++)
                    aux[i] = _noDomParValues[i].nonDominatedFitness[j];
                linf[j] = (NumberOfFunction * search_min(aux, i)) + j;//Trả về phần từ nhỏ nhất
                lsup[j] = (NumberOfFunction * search_max(aux, i)) + j;//Trả về phần tử lớn nhất
	        }
        }

        // Euclidean distance between particle ’i’ and particle ’j’
        // Note: In N dimensions, the Euclidean distance between two points p and q is:
        // sqrt (sum(p_i - q_i)ˆ2) where p_i (or q_i) is the coordinate of p (or q) in dimension i.
        
        float dCount(int i, int j)
        {
	        int d;
	        float sum = 0.0f;

            for (d = 0; d < NumberOfFunction; d++)
                sum += Convert.ToSingle(Math.Pow((_noDomParValues[i].nonDominatedFitness[d] - _noDomParValues[j].nonDominatedFitness[d]), 2));

            return Convert.ToSingle(Math.Sqrt(sum));
        }

        // As signs a fitness sharing to a particle according to the distance between it and the others.
        float sharing(int i, int j)
        {
	        float d, r = 0.0f;
	        int alp = 2;

            d = dCount(i, j);
            _distance[i][j] = d;
	        if(d < _ssh)
                r = 1.0f - Convert.ToSingle(Math.Pow(d / _ssh, alp));
	        return r;
        }

        // Adds fitness sharing to a single particle ’i’ in accordance to the closeness to the rest
        // Basically calculates the distance for each particle ’j’ and if too close
        //adds fitness sharing to the particle ’i’

        float nCount(int i, int lastPart)
        {
	        float sum = 0.0f;
	        int j;

	        for(j = 0; j < lastPart; j++)
		        sum += sharing(i, j);

	        return sum;
        }

        // Assings a fitness sharing to every particle in the repository
        // The fitness sharing values for particles lying in 'crowded' areas will be lower,
        // than particles lying in ’lonely’ areas where fitness sharing values will be higher

        void fitShar()
        {
	        int i;
	        float ffix = 10.0f;

            _nCounts.Clear();
            _fShar.Clear();
	        for(i = 0; i < _lastPart; i++) {
                _nCounts.Add(nCount(i, _lastPart));
		        _fShar.Add(ffix/_nCounts[i]);
	        }
        }

        // Selection of a leader acording to the best FS
        int leadAsg_BestOfRep (int lastPart)
        {
	        return search_max(_fShar, lastPart);
        }

        //Selection of a random leader
        int leadAsg_Random(int lastPart)
        {
            return MyRandom.RandomMtoN(0,lastPart); //Ngẫu nhiên từ 0 đến lastPart
        }

        // Choose the particle leaders, according to a SUS ( stochastic universal sampling )
        // The number of times each leader will be used is stored in the array leadC,
        // which corresponds to the positions of the particles in the repository

        void leadAsg() {
	        int i, j;
            float fSharS = 0.0f, U, sum = 0.0f;
            float[] Pr;

	        Pr = new float [_lastPart];
	        for(i = 0; i < _lastPart; i++)
		        fSharS += _fShar[i];
 	        for (i = 0; i < _lastPart; i++)
		        Pr[i] = _fShar[i]/fSharS;
            U = MyRandom.RandomFloatMtoN(0.0f, 1.0f / Convert.ToSingle(NumberOfParticle));
            i = 0;
            while(i<_lastPart)
	        {
		        _leadC[i] = 0;
		        sum += Pr[i];
		        while (U < sum)
		        {
			        _leadC[i]++;
                    U += 1.0f / Convert.ToSingle(NumberOfParticle);
		        }
                i++;
	        }

            for (j = i; j < SizeOfRepository; j++)
		        _leadC[j] = 0;
        }

        //Reduces the number of times a particle can be choosen as a leader
        void leadSel()
        {
	        int i = 0, j = 0;

            for (i = 0; i < NumberOfParticle; i++)
                _leaders[i] = 0;

	        do {
		        while((_leadC[j] > 0) && ( i < NumberOfParticle))
		        {
                    if(j<_lastPart)
			            _leaders[i] = j;
                    else
                        _leaders[i] = 0;
			        _leadC[j]--;
			        i++;
		        }
		        j++;
            } while ((i < NumberOfParticle) && (j < SizeOfRepository));
        }

        void update_dist(int lastPart, int h) {
	        int i = 0, j;
            // Update the distances swaping the last in the array with the h distance position
            // when the position h is found then the distances have to be shift

	        while (i < h)
	        {
		        _distance[h][i] = _distance[lastPart - 1][i];
		        i++;
	        }
	        // A distance of 0 is set for the position h
	        _distance[h][i] = 0.0f;
	        // Shifts, and the swapping carries on
	        for (j = i + 1; j < lastPart; j++)
		        _distance[h][j] = _distance[lastPart - 1][j];

	        // Once the swapping is finished, is necesary to change the distance values for the particle
	        // swapped in the other arrays.
	        // Also the values for the distance which is being swapped is deleted (to 0)
	        for(i = 0; i < lastPart; i++) {
		        _distance[i][h] = _distance[h][i];
		        // The distances just swapped are deleted
                _distance[i][lastPart - 1] = 0.0f;
                _distance[lastPart - 1][i] = 0.0f;
	        }
        }

        void update_fs(int lastPart, int h) {
	        int alp = 2;
	        int i;
	        float ffix = 10.0f;

	        for(i = 0; i < lastPart; i++)
		        if((_distance[i][h] < _ssh) && (i!= h)) {
		        // Updates if distance of particle h to be deleted affects particle i, when their distance is smaller than ssh
			        _nCounts[i] = _nCounts[i] - (1.0f - Convert.ToSingle(Math.Pow(_distance[i][h]/_ssh, alp)));
			        _fShar[i] = ffix/_nCounts[i];
	        }
        }

        int verDom2(int i) 
        {
	        int h = 0;
	        do {
		        switch(compVec2(h, i)) {
		        // If noDomF dominates fitness, case 1.
		        case 1: return 0;
		        // If noDomF is dominated by fitness, case 2.
                case 2:
                    // Particle noDom dominated is deleted from the repository
                    _noDomParValues.RemoveAt(h);
                    // Distances and fitness sharing for each updated for each particle
                    update_fs(_lastPart, h);
                    update_dist(_lastPart, h);
                    _nCounts.RemoveAt(h);
                    _fShar.RemoveAt(h);
                    // Number of particles in the repository is decresead by one
                    _lastPart--;
                    break;
                case 3: h++;
			        break ;
		        }
	        } while(h < _lastPart);

	        return 1;
        }

        void distance_fShar_update(int lastPart) 
        {
	        int alp = 2 ;
	        int i, last = lastPart - 1;
	        float ffix = 10.0f;

	        // Update distances between the new particle and the rest
	        for (i = 0; i < last; i++)
		        _distance [i][last] = _distance [last][i];

	        // Update fitShar if necessary
	        for(i = 0; i < last; i++)
		        if (_distance[i][last] < _ssh) {
		        // Update
		        _nCounts [i] = _nCounts[i] + (1.0f - Convert.ToSingle(Math.Pow(_distance[i][last]/_ssh, alp)));
		        _fShar[i] = ffix/_nCounts[i] ;
	        }
        }

        float dCount2(int j, PSOParticle par)
        {
        	int d;
            float sum = 0.0f;

	        for (d = 0; d < NumberOfFunction; d++)
                sum += Convert.ToSingle(Math.Pow((par._fitness[d] - _noDomParValues[j].nonDominatedFitness[d]), 2));

	        return Convert.ToSingle(Math.Sqrt(sum));
        }

        //Assigns a fitness sharing to a particle according to the distance between it and the others.
        float sharing2(int j, PSOParticle par)
        {
	        float d, r = 0.0f; // , ssh = 4.5;
	        int alp = 2;

	        d = dCount2(j, par);
	        // cout << d << endl;
	        if (d < _ssh )
		        r = 1.0f - Convert.ToSingle(Math.Pow(d/_ssh, alp));
	        // cout << r << endl ;
	        return r ;
        }

        //Adds fitness sharing to a single particle 'l' in accordance to the closeness to the rest
        //Basicaly calculates the distance for each particle 'i' and if too close adds fitness sharing to the particle 'l'

        float nCount2(PSOParticle par, int lastPart)
        {
	        float sum = 0.0f;
	        int j;

	        for(j = 0; j < lastPart; j++)
		        sum += sharing2(j, par);
 	        //+ 1.0 to add the sharing not counted for that particle.
	         return sum + 1.0f;
        }

        //Assings a fitness sharing to a given particle according to the particles in the repository
        //The fitness sharing value for a particle lying in a 'crowded' area will be lower,
        //than a particles lying in 'lonely' areas where fitness sharing values will be higher
        float calFS(PSOParticle par, int lastPart)
        {

	        float res, ffix = 10.0f;
	        //search_limits (noDomF, lsup, linf, lastPart);
	        res = ffix/nCount2(par, lastPart);
	        //for (l = 0; l < lastPart; l++)
	        return res;
        }

        //Kiem tra xem phuong an da ton tai trong non-dominated space hay chua
        bool isExistInNonDom(PSOParticle par)
        {
            int i, j;
            bool isCompletelyEqu;

            for (i = 0; i < _lastPart; i++)
            {
                isCompletelyEqu = true;
                for (j = 0; j < NumberOfDimention; j++)
                {
                    if (Convert.ToInt32(Math.Round(par._pos[j])) != Convert.ToInt32(Math.Round(_noDomParValues[i].nonDominatedParticle[j])))
                    {
                        isCompletelyEqu = false;
                        break;
                    }
                }
                if (isCompletelyEqu) return true;
            }

            return false;
        }

        void search_insert_FS()
        {
	        int i, k, l, j;
	        float aux_1 , aux_2, ffix = 10.0f;
            bool isBetter = false;

	        for(k = 0; k < NumberOfParticle; k++) {
		        // Verify if the particle aiming for the repository is NOT dominated by the ones inside,
		        // and it does deletes the ones it manages to dominate.
		        if (verDom2(k) == 1) {
                    isBetter = true;
			        // If the repository is not full, it does insert the particle, updating fitness sharing
			        if(_lastPart < SizeOfRepository) {
                        if (!isExistInNonDom(_pop[k]))
                        {
                            i = _lastPart;
                            ParticleData pa = new ParticleData(NumberOfDimention, NumberOfFunction, _exparams.NumberOfForecastedValue);
                            for (j = 0; j < NumberOfDimention; j++)
                            {
                                pa.nonDominatedParticle[j] = _pop[k]._pos[j];
                            }
                            for (j = 0; j < NumberOfFunction; j++)
                            {
                                pa.nonDominatedFitness[j] = _pop[k]._fitness[j];
                            }
                            for (j = 0; j < _pop[k]._noDomFCV.Count; j++)
                            {
                                pa.forcastedvalue[j] = _pop[k]._noDomFCV[j];
                            }
                            pa._evaluationValue = _pop[k]._evaluationValue;
                            pa._evaluMAPE = _pop[k]._evaluMAPE;
                            pa._evaluME = _pop[k]._evaluME;
                            pa._evaluMSE = _pop[k]._evaluMSE;
                            pa.HASystem = _pop[k].HASystem;
                            _noDomParValues.Add(pa);
                            // Update the counter of particles in the repository
                            _lastPart++;
                            // Update fitness sharing for each particle
                            // First we calculate distances (along with fShar and nCounts ) to see if it’s closer to the particles
                            _nCounts.Add(nCount(i, _lastPart));
                            _fShar.Add(ffix / _nCounts[i]);
                            // With the distances we can now see if we need to recalculate the distances and
                            //fShar of each particle or not 
                            distance_fShar_update(_lastPart);
                        }
			        }
			        // When the particle is not dominated, and the repository is full
			        // to insert it into the repository, the particle needs a better FS than one of them
			        else {
				        // calculate fitness sharing of particles
                        aux_1 = calFS(_pop[k], _lastPart);
                        l = search_min(_fShar, _fShar.Count);
				        aux_2 = _fShar[l];
				        // If particle k->(aux_1) has better FS than particle l->(aux_2), the latter is deleted
                        if (aux_1 > aux_2 && !isExistInNonDom(_pop[k]))
                        {
                            // We eliminate the particle with the smaller FS
                            _noDomParValues.RemoveAt(l);
                            // We update distances for each particle, along their fitness sharing values
                            update_fs(_lastPart, l);
                            update_dist(_lastPart, l);
                            _nCounts.RemoveAt(l);
                            _fShar.RemoveAt(l);
                            // The number of particles in the repository is decremented by one 
                            _lastPart--;
                            // The particle with better FS is inserted
					        i = _lastPart;
                            ParticleData pa = new ParticleData(NumberOfDimention, NumberOfFunction, _exparams.NumberOfForecastedValue);
                            for (j = 0; j < NumberOfDimention; j++)
                            {
                                pa.nonDominatedParticle[j] = _pop[k]._pos[j];
                            }
                            for (j = 0; j < NumberOfFunction; j++)
                            {
                                pa.nonDominatedFitness[j] = _pop[k]._fitness[j];
                            }
                            for (j = 0; j < _pop[k]._noDomFCV.Count; j++)
                            {
                                pa.forcastedvalue[j] = _pop[k]._noDomFCV[j];
                            }
                            pa._evaluationValue = _pop[k]._evaluationValue;
                            pa._evaluMAPE = _pop[k]._evaluMAPE;
                            pa._evaluME = _pop[k]._evaluME;
                            pa._evaluMSE = _pop[k]._evaluMSE;
                            pa.HASystem = _pop[k].HASystem;
                            _noDomParValues.Add(pa);
                            // Update the counter of particles in the repository
					        _lastPart++;
					        // Update FS for each particle 
					        // First we calculate distances (along with fShar and nCounts) 
					        //to see if it’s closer to the particles
					        _nCounts.Add(nCount(i, _lastPart));
					        _fShar.Add(ffix/_nCounts[i]);
					        // With the distances we can now see if we need to recalculate the
					        //fShar of each particle or not
					        distance_fShar_update(_lastPart);
				        }
			        }
		        }
	        }
            if (isBetter) NumberOfBadStep = 0;
            else NumberOfBadStep++;
        }

        // Mutation of particles adapted from MOPSO
        void mutate(int t)
        {
            int i, dimension = 0;
            float minvaluetemp, maxvaluetemp, range;

            for (i = 0; i < NumberOfParticle; i++)
            {
                //if (MyRandom.Flip(pMut) != 0)
                if (MyRandom.Flip(Convert.ToSingle(Math.Pow(1.0f - Convert.ToSingle(t) / (NumberOfCycle * pMut), 1.5f))) != 0)
                //if(!_pop[i]._isBestMove)
                {
                    dimension = MyRandom.RandomMtoN(0, NumberOfDimention - 1);

                    range = Convert.ToSingle((_params.UpBound[dimension] - _params.LowBound[dimension]) * Math.Pow(1.0f - Convert.ToSingle(t) / NumberOfCycle, 1.5f) / 2.0f);

                    if (_pop[i]._pos[dimension] - range < _params.LowBound[dimension])
                        minvaluetemp = _params.LowBound[dimension];
                    else
                        minvaluetemp = _pop[i]._pos[dimension] - range;

                    if (_pop[i]._pos[dimension] + range > _params.UpBound[dimension])
                        maxvaluetemp = _params.UpBound[dimension];
                    else
                        maxvaluetemp = _pop[i]._pos[dimension] + range;

                    _pop[i]._pos[dimension] = MyRandom.RandomFloatMtoN(minvaluetemp, maxvaluetemp);
                }
            }
        }

        int search_best_neighbor(int i) {
	        int x, y;

	        if (i > 0)
		        x = i - 1;
	        else
		        x = NumberOfParticle - 1;

            if (i >= NumberOfParticle - 1)
		        y = 0;
	        else
		        y = i + 1;

            if (_pop[i]._fitness[_leaders[x]] > _pop[i]._fitness[_leaders[y]])
            {
                if (_pop[i]._fitness[_leaders[x]] > _pop[i]._fitness[_leaders[i]])
			        return x ;
		        else
			        return i ;
	        } else {
                if (_pop[i]._fitness[_leaders[i]] > _pop[i]._fitness[_leaders[y]])
			        return i;
		        else
			        return y;
	        }
        }

        float get_MD()
        {
            float[] max = new float[NumberOfFunction];
            float[] min = new float[NumberOfFunction];
            int i, j;
            float value, MD, sum = 0.0f;

            for (i = 0; i < NumberOfFunction; i++)
            {
                max[i] = -999999999.0f;
                min[i] = 999999999.0f;
            }

            for (i = 0; i < _lastPart; i++)
            {
                for (j = 0; j < NumberOfFunction; j++)
                {
                    value = _noDomParValues[i].nonDominatedFitness[j];
                    max[j] = max[j] < value ? value : max[j];
                    min[j] = min[j] > value ? value : min[j];
                }
            }
            for (i = 0; i < NumberOfFunction; i++)
            {
                sum += Convert.ToSingle(Math.Pow(max[i] - min[i], 2));
            }

            MD = Convert.ToSingle(Math.Sqrt(sum));

            return MD;
        }

        //Tính toán sigma share
        public float get_ssh()
        {
            float MD, ssh;

            MD = get_MD();
            ssh = MD / _lastPart;

            return ssh;
        }

    }
}
