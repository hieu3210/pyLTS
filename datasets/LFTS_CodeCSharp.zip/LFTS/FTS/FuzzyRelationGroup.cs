﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FTS
{
    public class FuzzyRelationGroup
    {
        private List<int> _leftHandSide;
        private List<int> _rightHandSide;
        private List<int> _rightHandSideData;

        public FuzzyRelationGroup()
        {
            _leftHandSide = new List<int>();
            _rightHandSide = new List<int>();
            _rightHandSideData = new List<int>();
        }

        public void AddLeftHandSide(int v_Value)
        {
            _leftHandSide.Add(v_Value);
        }

        public void AddRightHandSide(int v_Value, int v_data)
        {
            _rightHandSide.Add(v_Value);
            _rightHandSideData.Add(v_data);
        }

        public int LeftHandSide(int v_Index)
        {
            return _leftHandSide[v_Index];
        }

        public int RightHandSide(int v_Index)
        {
            return _rightHandSide[v_Index];
        }

        public int RightHandSideData(int v_Index)
        {
            return _rightHandSideData[v_Index];
        }

        public int LeftHandCount()
        {
            return _leftHandSide.Count;
        }

        public int RightHandCount()
        {
            return _rightHandSide.Count;
        }

        public bool IsLeftHandEqual(FuzzyRelationGroup v_FRG)
        {
            bool isEqual = true;

            for (int i = 0; i < _leftHandSide.Count; i++)
            {
                if (v_FRG.LeftHandSide(i) != _leftHandSide[i])
                {
                    isEqual = false;
                    break;
                }
            }

            return isEqual;
        }

    }
}
