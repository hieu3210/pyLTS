﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FTS
{
    public class TriangleFuzzySet
    {
        private float _left;
        private float _right;
        private float _middle;
        private string _Term;

        public void SetLeft(float v_left)
        {
            _left = v_left;
        }

        public float GetLeft()
        {
            return _left;
        }

        public void SetRight(float v_right)
        {
            _right = v_right;
        }

        public float GetRight()
        {
            return _right;
        }

        public void SetMiddle(float v_middle)
        {
            _middle = v_middle;
        }

        public float GetMiddle()
        {
            return _middle;
        }

        public void SetTerm(string v_term)
        {
            _Term = v_term;
        }

        public string GetTerm()
        {
            return _Term;
        }

        public TriangleFuzzySet(float v_left, float v_middle, float v_right)
        {
            _left = v_left;
            _middle = v_middle;
            _right = v_right;
        }

        public TriangleFuzzySet(string v_term, float v_left, float v_middle, float v_right)
        {
            _left = v_left;
            _middle = v_middle;
            _right = v_right;
            _Term = v_term;
        }

        public float Membership(float x)
        {
            if (x < _left || _right < x)
                return 0.0f;

            if (x <= _middle)
            {
                if (_middle == _left) return 1.0f;
                else return (x - _left) / (_middle - _left);
            }
            else
            {
                if (_middle == _right) return 1.0f;
                else return (_right - x) / (_right - _middle);
            }
        }


    }
}
