﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FTS
{
    public class DataInterval
    {
        private float _leftPoint;
        private float _rightPoint;
        private int _termIndex;
        List<float> _realDataMember;

        public float Right
        {
            get
            {
                return _rightPoint;
            }
            set
            {
                if (value < _leftPoint)
                    _rightPoint = _leftPoint;
                else
                    _rightPoint = value;
            }
        }

        public float Left
        {
            get
            {
                return _leftPoint;
            }
            set
            {
                if (value < _rightPoint)
                    _leftPoint = value;
                else
                    _leftPoint = _rightPoint;
            }
        }

        public int TermIndex
        {
            get
            {
                return _termIndex;
            }
            set
            {
                _termIndex = value;
            }
        }

        public float RealDataMember(int index)
        {
            try
            {
                return _realDataMember[index];
            }
            catch (RankException ex)
            {
                throw ex;
            }

        }

        public DataInterval(float v_left, float v_right)
        {
            _leftPoint = v_left;
            _rightPoint = v_right;
            _termIndex = 255;
            _realDataMember = new List<float>();
        }

        public void AddRealDataMember(float dataValue)
        {
            _realDataMember.Add(dataValue);
        }

        public int GetNumberOfRealDataMember()
        {
            return _realDataMember.Count;
        }

        public bool isContain(float dataValue)
        {
            bool isTrue = false;

            if (dataValue >= _leftPoint && dataValue <= _rightPoint) isTrue = true;

            return isTrue;
        }

    }
}
