﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace FTS
{
    public class FuzzyTimeSeries
    {
        private FTSDataTable _actualData;
        private DataPartition _dataPartition;
        private string _FileName;
        private float _minValue;
        private float _maxValue;
        private int _numberOfInterval;
        private List<FuzzyRelationGroup> fuzzyRG;
        private List<float> _forecastedValue = new List<float>();
        FTS_Parameters _FTS_Parameter;
        private float _evaluationValue;
        private bool _isTimeVariant;

        public FuzzyTimeSeries(FTS_Parameters FTS_Parameter)
        {
            _FTS_Parameter = FTS_Parameter;
            _FileName = _FTS_Parameter.FilePath + "\\" + _FTS_Parameter.FileName;
            _actualData = new FTSDataTable(_FileName);
            _FTS_Parameter.NumberOfForecastedValue = _actualData.LoadData();
            _isTimeVariant = FTS_Parameter.TimeVariant;
            _minValue = FTS_Parameter.MinValue;
            _maxValue = FTS_Parameter.MaxValue;
            _numberOfInterval = _FTS_Parameter.NoPartition;
            _dataPartition = new DataPartition(_minValue, _maxValue);
            fuzzyRG = new List<FuzzyRelationGroup>();
            _forecastedValue = new List<float>();
            _evaluationValue = -1.0f;
        }

        public void SetupNewPartition(List<float> pointList)
        {
            _dataPartition.DetermineDataPartition(pointList);

        }

        public void StartForecasting(bool isEqualSize)
        {
            // isEqualSize = true --> Intervals have the same size
            int orLevel = 1;

            if (isEqualSize) _dataPartition.DetermineDataPartition(_numberOfInterval);
            FuzzifyData();
            //FuzzifyData_Advance();
            if (isEqualSize) WriteFuzzyRelation();
            //--------------------------------------------------------
            if (_FTS_Parameter.orderlevel == OrderLevel.SecondOrder)
                orLevel = 2;
            else if (_FTS_Parameter.orderlevel == OrderLevel.ThirdOrder)
                orLevel = 3;
            else if (_FTS_Parameter.orderlevel == OrderLevel.FourthOrder)
                orLevel = 4;
            else if (_FTS_Parameter.orderlevel == OrderLevel.FifthOrder)
                orLevel = 5;
            else if (_FTS_Parameter.orderlevel == OrderLevel.SixthOrder)
                orLevel = 6;
            else if (_FTS_Parameter.orderlevel == OrderLevel.SeventhOrder)
                orLevel = 7;
            else if (_FTS_Parameter.orderlevel == OrderLevel.EighthOrder)
                orLevel = 8;
            else if (_FTS_Parameter.orderlevel == OrderLevel.NinthOrder)
                orLevel = 9;
            //---------------------------------------------------------------
            if (_FTS_Parameter.orderlevel == OrderLevel.FirstOrder)
                CreateFirstOrderTVFLRG();
            else
            {
                Create_M_OrderTVFLRG(orLevel);
            }
            WriteFuzzyRelationGroup(orLevel);
            //-----------------------------------------------------------------------------------
            if (_FTS_Parameter.defuzzificationMethod == DefuzzificationMethod.TVFLRG_Weighted)
                _forecastedValue = Defuzzify_TVFLRG_Weight(orLevel);
            else if (_FTS_Parameter.defuzzificationMethod == DefuzzificationMethod.TVFLRG_NoWeight)
                _forecastedValue = Defuzzify_TVFLRG_NoWeight(orLevel);
            else if (_FTS_Parameter.defuzzificationMethod == DefuzzificationMethod.TVFLRG_H_Sub_mkj)
                _forecastedValue = Defuzzify_TVFLRG_H_Sub_mkj(orLevel, 4);
            else if (_FTS_Parameter.defuzzificationMethod == DefuzzificationMethod.TVFLRG_Sub_And_mkj)
                _forecastedValue = Defuzzify_TVFLRG_Sub_A_mkj(orLevel, 4);
            else if (_FTS_Parameter.defuzzificationMethod == DefuzzificationMethod.TVFLRG_Sub_And_mkj_Weighted)
                _forecastedValue = Defuzzify_TVFLRG_Sub_A_mkj_Weight(orLevel, 4);
            else if (_FTS_Parameter.defuzzificationMethod == DefuzzificationMethod.TVFLRG_Sub_mkj)
                _forecastedValue = Defuzzify_TVFLRG_Sub_mkj(orLevel, 4);
            else if (_FTS_Parameter.defuzzificationMethod == DefuzzificationMethod.TVFLRG_Sub_mkj_Weighted)
                _forecastedValue = Defuzzify_TVFLRG_Sub_mkj_Weighted(orLevel, 4);
            else if(_FTS_Parameter.defuzzificationMethod == DefuzzificationMethod.TVFLRG_Proportion)
                _forecastedValue = Defuzzify_TVFLRG_Proportion(orLevel);
            else
                _forecastedValue = Defuzzify_TVFLRG_FuzzyWeight(orLevel, 4);
            //-----------------------------------------------------------------------------------
            if (_FTS_Parameter.evaluationMethod == EvaluationMethod.MSE)
                _evaluationValue = Compute_MSE(_forecastedValue, orLevel);
            else if (_FTS_Parameter.evaluationMethod == EvaluationMethod.RMSE)
                _evaluationValue = Compute_RMSE(_forecastedValue, orLevel);
            else if (_FTS_Parameter.evaluationMethod == EvaluationMethod.ME)
                _evaluationValue = Compute_ME(_forecastedValue, orLevel);
            //-----------------------------------------------------------------------------------
            if (isEqualSize) WriteForecastValue(_forecastedValue, orLevel, _evaluationValue);
            //WriteForecastValue(_forecastedValue, orLevel, _evaluationValue);
        }

        public void FuzzifyData()
        {
            int numRow = _actualData.RowsCount;

            for (int row = 0; row < numRow; row++)
            {
                int termIndex = 0;

                for (int j = 0; j < _numberOfInterval; j++)
                {
                    if (_dataPartition.Interval(j).isContain(_actualData.Rows(row)[1]))
                    {
                        termIndex = j;
                        break;
                    }
                }
                _actualData.Rows(row).TermIndex = termIndex;
                _dataPartition.Interval(termIndex).AddRealDataMember(_actualData.Rows(row)[1]);
            }

        }

        public void FuzzifyData_Advance()
        {
            int numRow = _actualData.RowsCount;

            for (int row = 0; row < numRow; row++)
            {
                int termIndex = 0;
                float maxMSDegree = _dataPartition.Fuzzyset(0).Membership(_actualData.Rows(row)[1]);

                for (int j = 1; j < _numberOfInterval; j++)
                {
                    float msD = _dataPartition.Fuzzyset(j).Membership(_actualData.Rows(row)[1]);
                    if (msD > maxMSDegree)
                    {
                        maxMSDegree = msD;
                        termIndex = j;
                    }
                }
                _actualData.Rows(row).TermIndex = termIndex;
            }

        }

        public void CreateFirstOrderTVFLRG()
        {
            int numRow = _actualData.RowsCount;
            List<int> leftHand = new List<int>();
            List<int> rightHand = new List<int>();
            List<int> rightHand_data = new List<int>();

            int i = 1, k, l;
            while (i < numRow)
            {
                leftHand.Add(_actualData.Rows(i - 1).TermIndex);
                rightHand.Add(_actualData.Rows(i).TermIndex);
                rightHand_data.Add(i);
                i++;
            }

            i = 0;
            FuzzyRelationGroup frg = new FuzzyRelationGroup();
            frg.AddLeftHandSide(leftHand[i]);
            frg.AddRightHandSide(rightHand[i], rightHand_data[i]);
            fuzzyRG.Add(frg);
            l = i + 1;
            _actualData.Rows(l).DataGroupIndex = 0;
            i++; l++;
            while (i < leftHand.Count)
            {
                k = fuzzyRG.Count - 1;
                if (_isTimeVariant)
                {
                    FuzzyRelationGroup new_frg = new FuzzyRelationGroup();
                    while (k >= 0)
                    {
                        if (fuzzyRG[k].LeftHandSide(0) == leftHand[i]) //Neu cung ve trai thi add them ve phai
                        {
                            for (int j = 0; j < fuzzyRG[k].RightHandCount(); j++)
                            {
                                new_frg.AddRightHandSide(fuzzyRG[k].RightHandSide(j), fuzzyRG[k].RightHandSideData(j));
                            }
                            break;
                        }
                        k--;
                    }
                    new_frg.AddLeftHandSide(leftHand[i]);
                    new_frg.AddRightHandSide(rightHand[i], rightHand_data[i]);
                    _actualData.Rows(l).DataGroupIndex = fuzzyRG.Count;
                    fuzzyRG.Add(new_frg); //Tao FRG moi
                }
                else
                {
                    bool isNotAdded = true;
                    while (k >= 0)
                    {
                        if (fuzzyRG[k].LeftHandSide(0) == leftHand[i]) //Neu cung ve trai thi add them ve phai
                        {
                            fuzzyRG[k].AddRightHandSide(rightHand[i], rightHand_data[i]);
                            _actualData.Rows(l).DataGroupIndex = k;
                            isNotAdded = false;
                            break;
                        }
                        k--;
                    }
                    if (isNotAdded)
                    {
                        FuzzyRelationGroup new_frg = new FuzzyRelationGroup();
                        new_frg.AddLeftHandSide(leftHand[i]);
                        new_frg.AddRightHandSide(rightHand[i], rightHand_data[i]);
                        _actualData.Rows(l).DataGroupIndex = fuzzyRG.Count;
                        fuzzyRG.Add(new_frg); //Tao FRG moi
                    }
                }
                i++; l++;
            }

        }

        public void Create_M_OrderTVFLRG(int orderLevel)
        {
            int numRow = _actualData.RowsCount;
            List<List<int>> leftHand = new List<List<int>>();
            List<int> rightHand = new List<int>();
            List<int> rightHand_data = new List<int>();

            int i = orderLevel, k, l;
            while (i < numRow)
            {
                k = i;
                List<int> ld = new List<int>();
                while (k > i - orderLevel)
                {
                    ld.Add(_actualData.Rows(k - 1).TermIndex);
                    k--;
                }
                leftHand.Add(ld);
                rightHand.Add(_actualData.Rows(i).TermIndex);
                rightHand_data.Add(i);
                i++;
            }

            i = 0;
            FuzzyRelationGroup frg = new FuzzyRelationGroup();
            for (int j = 0; j < leftHand[i].Count; j++)
            {
                frg.AddLeftHandSide(leftHand[i][j]);
            }
            frg.AddRightHandSide(rightHand[i], rightHand_data[i]);
            fuzzyRG.Add(frg);
            l = i + orderLevel;
            _actualData.Rows(l).DataGroupIndex = 0;
            i++; l++;
            while (i < leftHand.Count)
            {
                FuzzyRelationGroup new_frg = new FuzzyRelationGroup();
                for (int j = 0; j < leftHand[i].Count; j++)
                {
                    new_frg.AddLeftHandSide(leftHand[i][j]);
                }
                k = fuzzyRG.Count - 1;
                bool isNotAdded = true;
                while (k >= 0)
                {
                    if (new_frg.IsLeftHandEqual(fuzzyRG[k])) //Neu cung ve trai thi add them ve phai
                    {
                        if (_isTimeVariant)
                        {
                            for (int j = 0; j < fuzzyRG[k].RightHandCount(); j++)
                            {
                                new_frg.AddRightHandSide(fuzzyRG[k].RightHandSide(j), fuzzyRG[k].RightHandSideData(j));
                            }
                            _actualData.Rows(l).DataGroupIndex = i - orderLevel;
                        }
                        else
                        {
                            fuzzyRG[k].AddRightHandSide(rightHand[i], rightHand_data[i]);
                            _actualData.Rows(l).DataGroupIndex = k;
                            isNotAdded = false;
                        }
                        break;
                    }
                    k--;
                }
                if (_isTimeVariant || isNotAdded)
                {
                    new_frg.AddRightHandSide(rightHand[i], rightHand_data[i]);
                    _actualData.Rows(l).DataGroupIndex = fuzzyRG.Count;
                    fuzzyRG.Add(new_frg); //Tao FRG moi
                }
                i++; l++;
            }
        }

        public List<float> Defuzzify_TVFLRG_FuzzyWeight(int order_level, int p_subinterval)
        {
            //lấy điểm giữa của các khoảng  ui1 , ui2,...uip  tương ứng
            int numRow = _actualData.RowsCount;
            List<float> forcastValue = new List<float>();

            for (int l = order_level; l < numRow; l++) //Bỏ qua dòng dữ liệu đầu
            {
                float forcast_value = 0.0f;
                int i = _actualData.Rows(l).DataGroupIndex;

                if (fuzzyRG[i].RightHandCount() < 1)
                {
                    forcast_value = (_dataPartition.Interval(fuzzyRG[i].LeftHandSide(0)).Left + _dataPartition.Interval(fuzzyRG[i].LeftHandSide(0)).Right) / 2.0f;
                }
                else
                {
                    float sum_weight = 0, sub_weight;
                    for (int k = 0; k < fuzzyRG[i].RightHandCount(); k++)
                    {
                        float mi_value = (_dataPartition.Interval(fuzzyRG[i].RightHandSide(k)).Left + _dataPartition.Interval(fuzzyRG[i].RightHandSide(k)).Right) / 2.0f;
                        sub_weight = (k + 1) * _dataPartition.Fuzzyset(fuzzyRG[i].RightHandSide(k)).Membership(mi_value);
                        forcast_value += sub_weight * mi_value;
                        sum_weight += sub_weight;
                    }
                    forcast_value /= sum_weight;
                }
                forcastValue.Add(forcast_value);
            }

            return forcastValue;
        }

        public List<float> Defuzzify_TVFLRG_Weight(int order_level)
        {
            //lấy điểm giữa của các khoảng  ui1 , ui2,...uip  tương ứng
            int numRow = _actualData.RowsCount;
            List<float> forcastValue = new List<float>();

            for (int l = order_level; l < numRow; l++) //Bỏ qua dòng dữ liệu đầu
            {
                float forcast_value = 0.0f;
                int i = _actualData.Rows(l).DataGroupIndex;//l - order_level;

                if (fuzzyRG[i].RightHandCount() < 1)
                {
                    forcast_value = (_dataPartition.Interval(fuzzyRG[i].LeftHandSide(0)).Left + _dataPartition.Interval(fuzzyRG[i].LeftHandSide(0)).Right) / 2.0f;
                }
                else
                {
                    int sum_weight = 0;
                    for (int k = 0; k < fuzzyRG[i].RightHandCount(); k++)
                    {
                        float mi_value = (_dataPartition.Interval(fuzzyRG[i].RightHandSide(k)).Left + _dataPartition.Interval(fuzzyRG[i].RightHandSide(k)).Right) / 2.0f;
                        forcast_value += (k + 1) * mi_value;
                        sum_weight += k + 1;
                    }
                    forcast_value /= sum_weight;
                }
                forcastValue.Add(forcast_value);
            }

            return forcastValue;
        }

        public List<float> Defuzzify_TVFLRG_Proportion(int order_level)
        {
            //lấy điểm giữa của các khoảng  ui1 , ui2,...uip  tương ứng
            int numRow = _actualData.RowsCount;
            List<float> forcastValue = new List<float>();

            for (int l = order_level; l < numRow; l++) //Bỏ qua dòng dữ liệu đầu
            {
                float forcast_value = 0.0f;
                int i = _actualData.Rows(l).DataGroupIndex;//l - order_level;

                if (fuzzyRG[i].RightHandCount() < 1)
                {
                    forcast_value = (_dataPartition.Interval(fuzzyRG[i].LeftHandSide(0)).Left + _dataPartition.Interval(fuzzyRG[i].LeftHandSide(0)).Right) / 2.0f;
                }
                else
                {
                    int sum_weight = 0;
                    float x = 0.0f;
                    for (int k = 0; k < fuzzyRG[i].RightHandCount(); k++)
                    {
                        x = _actualData.Rows(fuzzyRG[i].RightHandSideData(k))[1];
                        float pk = (x - _dataPartition.Interval(fuzzyRG[i].RightHandSide(k)).Left) / (_dataPartition.Interval(fuzzyRG[i].RightHandSide(k)).Right - _dataPartition.Interval(fuzzyRG[i].RightHandSide(k)).Left);
                        forcast_value += (pk * (_dataPartition.Interval(fuzzyRG[i].RightHandSide(k)).Right - _dataPartition.Interval(fuzzyRG[i].RightHandSide(k)).Left) + _dataPartition.Interval(fuzzyRG[i].RightHandSide(k)).Left);
                        sum_weight++;
                    }
                    forcast_value /= sum_weight;
                }
                forcastValue.Add(forcast_value);
            }

            return forcastValue;
        }

        public List<float> Defuzzify_TVFLRG_NoWeight(int order_level)
        {
            //lấy điểm giữa của các khoảng  ui1 , ui2,...uip  tương ứng
            int numRow = _actualData.RowsCount;
            List<float> forcastValue = new List<float>();

            for (int l = order_level; l < numRow; l++) //Bỏ qua dòng dữ liệu đầu
            {
                float forcast_value = 0.0f;
                int i = _actualData.Rows(l).DataGroupIndex; //l - order_level;

                if (fuzzyRG[i].RightHandCount() < 1)
                {
                    forcast_value = (_dataPartition.Interval(fuzzyRG[i].LeftHandSide(0)).Left + _dataPartition.Interval(fuzzyRG[i].LeftHandSide(0)).Right) / 2.0f;
                }
                else
                {
                    for (int k = 0; k < fuzzyRG[i].RightHandCount(); k++)
                    {
                        forcast_value += (_dataPartition.Interval(fuzzyRG[i].RightHandSide(k)).Left + _dataPartition.Interval(fuzzyRG[i].RightHandSide(k)).Right) / 2.0f;
                    }
                    forcast_value /= fuzzyRG[i].RightHandCount();
                }
                forcastValue.Add(forcast_value);
            }

            return forcastValue;
        }

        public List<float> Defuzzify_TVFLRG_H_Sub_mkj(int order_level, int p_subinterval)
        {
            //lấy điểm giữa của các khoảng  ui1 , ui2,...uip  tương ứng
            int numRow = _actualData.RowsCount;
            List<float> forcastValue = new List<float>();

            /*for (int l = order_level; l < numRow; l++) //Bỏ qua dòng dữ liệu đầu
            {
                float forcast_value = 0.0f;
                int i = _actualData.Rows(l).DataGroupIndex;//l - order_level;

                if (fuzzyRG[i].RightHandCount() < 1)
                {
                    forcast_value = (_dataPartition.Interval(fuzzyRG[i].LeftHandSide(0)).Left + _dataPartition.Interval(fuzzyRG[i].LeftHandSide(0)).Right) / 2.0f;
                }
                else
                {
                    int sum_weight = 0;
                    for (int k = 0; k < fuzzyRG[i].RightHandCount(); k++)
                    {
                        float mi_value = (_dataPartition.Interval(fuzzyRG[i].RightHandSide(k)).Left + _dataPartition.Interval(fuzzyRG[i].RightHandSide(k)).Right) / 2.0f;
                        int w = 1, j = k - 1;
                        while (j >= 0)
                        {
                            if (fuzzyRG[i].RightHandSide(j) == fuzzyRG[i].RightHandSide(k))
                                w++;
                            j--;
                        }
                        forcast_value += w * mi_value;
                        sum_weight += w;
                    }
                    forcast_value /= sum_weight;
                }
                forcastValue.Add(forcast_value);
            }*/

            /*for (int l = order_level; l < numRow; l++) //Bỏ qua dòng dữ liệu đầu
            {
                float forcast_value = 0.0f;
                int i = _actualData.Rows(l).DataGroupIndex; //l - order_level;

                if (fuzzyRG[i].RightHandCount() < 1)
                {
                    forcast_value = (_dataPartition.Interval(fuzzyRG[i].LeftHandSide(0)).Left + _dataPartition.Interval(fuzzyRG[i].LeftHandSide(0)).Right) / 2.0f;
                }
                else
                {
                    int sum_weight = 0;
                    for (int k = 0; k < fuzzyRG[i].RightHandCount(); k++)
                    {
                        float eInter = (_dataPartition.Interval(fuzzyRG[i].RightHandSide(k)).Right - _dataPartition.Interval(fuzzyRG[i].RightHandSide(k)).Left) / p_subinterval;
                        float leftValue = _dataPartition.Interval(fuzzyRG[i].RightHandSide(k)).Left;
                        float rightValue = leftValue + eInter;
                        int j = 0;
                        float subForecastValue = 0.0f, x = 0.0f;
                        while (j < p_subinterval)
                        {
                            x = _actualData.Rows(fuzzyRG[i].RightHandSideData(k))[1];
                            if (x >= leftValue && x <= rightValue)
                            {
                                subForecastValue = (leftValue + rightValue) / 2.0f;
                            }
                            leftValue = rightValue;
                            rightValue += eInter;
                            j++;
                        }
                        int w = 1;
                        j = k - 1;
                        while (j >= 0)
                        {
                            if (fuzzyRG[i].RightHandSide(j) == fuzzyRG[i].RightHandSide(k))
                                w++;
                            j--;
                        } 
                        forcast_value += w * subForecastValue;
                        sum_weight += w;
                    }
                    forcast_value /= sum_weight;
                }
                forcastValue.Add(forcast_value);
            }*/

            //Fuzzy Weighted
            float x = 0.0f;
            for (int l = order_level; l < numRow; l++) //Bỏ qua dòng dữ liệu đầu
            {
                float forcast_value = 0.0f;
                int i = _actualData.Rows(l).DataGroupIndex;//l - order_level;

                if (fuzzyRG[i].RightHandCount() < 1)
                {
                    forcast_value = (_dataPartition.Interval(fuzzyRG[i].LeftHandSide(0)).Right + _dataPartition.Interval(fuzzyRG[i].LeftHandSide(0)).Left) / 2.0f;
                }
                else
                {
                    float sum_weight = 0.0f;
                    float w = 1.0f;
                    for (int k = 0; k < fuzzyRG[i].RightHandCount(); k++)
                    {
                        x = _actualData.Rows(fuzzyRG[i].RightHandSideData(k))[1];
                        w = _dataPartition.Fuzzyset(fuzzyRG[i].RightHandSide(k)).Membership(x);
                        float mi_value = w * (_dataPartition.Interval(fuzzyRG[i].RightHandSide(k)).Right - _dataPartition.Interval(fuzzyRG[i].RightHandSide(k)).Left) + _dataPartition.Interval(fuzzyRG[i].RightHandSide(k)).Left;
                        forcast_value += (k + 1) * mi_value;
                        sum_weight += k + 1;
                    }
                    forcast_value /= sum_weight;
                }
                forcastValue.Add(forcast_value);
            }

            //Sub_mkj with fuzzy weighted
            /*for (int l = order_level; l < numRow; l++) //Bỏ qua dòng dữ liệu đầu
            {
                float forcast_value = 0.0f;
                int i = _actualData.Rows(l).DataGroupIndex; //l - order_level;

                if (fuzzyRG[i].RightHandCount() < 1)
                {
                    forcast_value = (_dataPartition.Interval(fuzzyRG[i].LeftHandSide(0)).Left + _dataPartition.Interval(fuzzyRG[i].LeftHandSide(0)).Right) / 2.0f;
                }
                else
                {
                    int sum_weight = 0;
                    for (int k = 0; k < fuzzyRG[i].RightHandCount(); k++)
                    {
                        float eInter = (_dataPartition.Interval(fuzzyRG[i].RightHandSide(k)).Right - _dataPartition.Interval(fuzzyRG[i].RightHandSide(k)).Left) / p_subinterval;
                        float leftValue = _dataPartition.Interval(fuzzyRG[i].RightHandSide(k)).Left;
                        float rightValue = leftValue + eInter, w = 1.0f;
                        int j = 0;
                        float subForecastValue = 0.0f, x = 0.0f;
                        while (j < p_subinterval)
                        {
                            x = _actualData.Rows(fuzzyRG[i].RightHandSideData(k))[1];
                            if (x >= leftValue && x <= rightValue)
                            {
                                w = _dataPartition.Fuzzyset(fuzzyRG[i].RightHandSide(k)).Membership(x);
                                subForecastValue = w * (rightValue - leftValue) + leftValue;
                            }
                            leftValue = rightValue;
                            rightValue += eInter;
                            j++;
                        }
                        forcast_value += (k + 1) * subForecastValue;
                        sum_weight += k + 1;
                    }
                    forcast_value /= sum_weight;
                }
                forcastValue.Add(forcast_value);
            }*/

            return forcastValue;
        }

        public List<float> Defuzzify_TVFLRG_Sub_mkj(int order_level, int p_subinterval)
        {
            //lấy điểm giữa của khoảng con của ui1 , ui2,...uip của ui
            int numRow = _actualData.RowsCount;
            List<float> forcastValue = new List<float>();

            for (int l = order_level; l < numRow; l++) //Bỏ qua dòng dữ liệu đầu
            {
                float forcast_value = 0.0f;
                int i = _actualData.Rows(l).DataGroupIndex; //l - order_level;

                if (fuzzyRG[i].RightHandCount() < 1)
                {
                    forcast_value = (_dataPartition.Interval(fuzzyRG[i].LeftHandSide(0)).Left + _dataPartition.Interval(fuzzyRG[i].LeftHandSide(0)).Right) / 2.0f;
                }
                else
                {
                    int sum_weight = 0;
                    for (int k = 0; k < fuzzyRG[i].RightHandCount(); k++)
                    {
                        float eInter = (_dataPartition.Interval(fuzzyRG[i].RightHandSide(k)).Right - _dataPartition.Interval(fuzzyRG[i].RightHandSide(k)).Left) / p_subinterval;
                        float leftValue = _dataPartition.Interval(fuzzyRG[i].RightHandSide(k)).Left;
                        float rightValue = leftValue + eInter;
                        int j = 0;
                        float subForecastValue = 0.0f, x = 0.0f;
                        while (j < p_subinterval)
                        {
                            x = _actualData.Rows(fuzzyRG[i].RightHandSideData(k))[1];
                            if (x >= leftValue && x <= rightValue)
                            {
                                subForecastValue = (leftValue + rightValue) / 2.0f;
                                break;
                            }
                            leftValue = rightValue;
                            rightValue += eInter;
                            j++;
                        }
                        forcast_value += subForecastValue;
                        sum_weight++;
                    }
                    forcast_value /= sum_weight;
                }
                forcastValue.Add(forcast_value);
            }

            return forcastValue;
        }

        public List<float> Defuzzify_TVFLRG_Sub_mkj_Weighted(int order_level, int p_subinterval)
        {
            //lấy điểm giữa của khoảng con của ui1 , ui2,...uip của ui
            int numRow = _actualData.RowsCount;
            List<float> forcastValue = new List<float>();

            for (int l = order_level; l < numRow; l++) //Bỏ qua dòng dữ liệu đầu
            {
                float forcast_value = 0.0f;
                int i = _actualData.Rows(l).DataGroupIndex; //l - order_level;

                if (fuzzyRG[i].RightHandCount() < 1)
                {
                    forcast_value = (_dataPartition.Interval(fuzzyRG[i].LeftHandSide(0)).Left + _dataPartition.Interval(fuzzyRG[i].LeftHandSide(0)).Right) / 2.0f;
                }
                else
                {
                    int sum_weight = 0;
                    for (int k = 0; k < fuzzyRG[i].RightHandCount(); k++)
                    {
                        float eInter = (_dataPartition.Interval(fuzzyRG[i].RightHandSide(k)).Right - _dataPartition.Interval(fuzzyRG[i].RightHandSide(k)).Left) / p_subinterval;
                        float leftValue = _dataPartition.Interval(fuzzyRG[i].RightHandSide(k)).Left;
                        float rightValue = leftValue + eInter;
                        int j = 0;
                        float subForecastValue = 0.0f, x = 0.0f;
                        while (j < p_subinterval)
                        {
                            x = _actualData.Rows(fuzzyRG[i].RightHandSideData(k))[1];
                            if (x >= leftValue && x <= rightValue)
                            {
                                subForecastValue = (leftValue + rightValue) / 2.0f;
                                break;
                            }
                            leftValue = rightValue;
                            rightValue += eInter;
                            j++;
                        }
                        forcast_value += (k + 1) * subForecastValue;
                        sum_weight += k + 1;
                    }
                    forcast_value /= sum_weight;
                }
                forcastValue.Add(forcast_value);
            }

            return forcastValue;
        }

        public List<float> Defuzzify_TVFLRG_Sub_A_mkj(int order_level, int p_subinterval)
        {
            //lấy trung bình điểm giữa của ui và của khoảng con của ui1 , ui2,...uip của ui
            int numRow = _actualData.RowsCount;
            List<float> forcastValue = new List<float>();

            for (int l = order_level; l < numRow; l++) //Bỏ qua dòng dữ liệu đầu
            {
                float forcast_value = 0.0f;
                int i = _actualData.Rows(l).DataGroupIndex; //l - order_level;

                if (fuzzyRG[i].RightHandCount() < 1)
                {
                    forcast_value = (_dataPartition.Interval(fuzzyRG[i].LeftHandSide(0)).Left + _dataPartition.Interval(fuzzyRG[i].LeftHandSide(0)).Right) / 2.0f;
                }
                else
                {
                    int sum_weight = 0;
                    for (int k = 0; k < fuzzyRG[i].RightHandCount(); k++)
                    {
                        float mi_value = (_dataPartition.Interval(fuzzyRG[i].RightHandSide(k)).Left + _dataPartition.Interval(fuzzyRG[i].RightHandSide(k)).Right) / 2.0f;
                        float eInter = (_dataPartition.Interval(fuzzyRG[i].RightHandSide(k)).Right - _dataPartition.Interval(fuzzyRG[i].RightHandSide(k)).Left) / p_subinterval;
                        float leftValue = _dataPartition.Interval(fuzzyRG[i].RightHandSide(k)).Left;
                        float rightValue = leftValue + eInter;
                        int j = 0;
                        float subForecastValue = 0.0f, x = 0.0f;
                        while (j < p_subinterval)
                        {
                            x = _actualData.Rows(fuzzyRG[i].RightHandSideData(k))[1];
                            if (x >= leftValue && x <= rightValue)
                            {
                                subForecastValue = (leftValue + rightValue) / 2.0f;
                                break;
                            }
                            leftValue = rightValue;
                            rightValue += eInter;
                            j++;
                        }
                        forcast_value += (mi_value + subForecastValue) / 2.0f;
                        sum_weight++;
                    }
                    forcast_value /= sum_weight;
                }
                forcastValue.Add(forcast_value);
            }

            return forcastValue;
        }

        public List<float> Defuzzify_TVFLRG_Sub_A_mkj_Weight(int order_level, int p_subinterval)
        {
            //lấy trung bình điểm giữa của ui và của khoảng con của ui1 , ui2,...uip của ui
            int numRow = _actualData.RowsCount;
            List<float> forcastValue = new List<float>();

            for (int l = order_level; l < numRow; l++) //Bỏ qua dòng dữ liệu đầu
            {
                float forcast_value = 0.0f;
                int i = _actualData.Rows(l).DataGroupIndex; //l - order_level;

                if (fuzzyRG[i].RightHandCount() < 1)
                {
                    forcast_value = (_dataPartition.Interval(fuzzyRG[i].LeftHandSide(0)).Left + _dataPartition.Interval(fuzzyRG[i].LeftHandSide(0)).Right) / 2.0f;
                }
                else
                {
                    int sum_weight = 0;
                    for (int k = 0; k < fuzzyRG[i].RightHandCount(); k++)
                    {
                        float mi_value = (_dataPartition.Interval(fuzzyRG[i].RightHandSide(k)).Left + _dataPartition.Interval(fuzzyRG[i].RightHandSide(k)).Right) / 2.0f;
                        float eInter = (_dataPartition.Interval(fuzzyRG[i].RightHandSide(k)).Right - _dataPartition.Interval(fuzzyRG[i].RightHandSide(k)).Left) / p_subinterval;
                        float leftValue = _dataPartition.Interval(fuzzyRG[i].RightHandSide(k)).Left;
                        float rightValue = leftValue + eInter;
                        int j = 0;
                        float subForecastValue = 0.0f, x = 0.0f;
                        while (j < p_subinterval)
                        {
                            x = _actualData.Rows(fuzzyRG[i].RightHandSideData(k))[1];
                            if (x >= leftValue && x <= rightValue)
                            {
                                subForecastValue = (leftValue + rightValue) / 2.0f;
                                break;
                            }
                            leftValue = rightValue;
                            rightValue += eInter;
                            j++;
                        }
                        forcast_value += (k + 1) * (mi_value + subForecastValue) / 2.0f;
                        sum_weight += (k + 1);
                    }
                    forcast_value /= sum_weight;
                }
                forcastValue.Add(forcast_value);
            }

            return forcastValue;
        }

        public float Compute_MSE(List<float> forcastValue, int order_level)
        {
            int numRow = _actualData.RowsCount;
            float compute_result = 0.0f;

            for (int i = order_level; i < numRow; i++)
            {
                compute_result += (float)Math.Pow(forcastValue[i - order_level] - _actualData.Rows(i)[1], 2);
            }
            compute_result /= (numRow - order_level);

            return compute_result;
        }

        public float Compute_RMSE(List<float> forcastValue, int order_level)
        {
            float compute_result = (float)Math.Sqrt(Compute_MSE(forcastValue, order_level));

            return compute_result;
        }

        public float Compute_ME(List<float> forcastValue, int order_level)
        {
            int numRow = _actualData.RowsCount;
            float compute_result = 0.0f;

            for (int i = order_level; i < numRow; i++)
            {
                compute_result += (float)Math.Abs(forcastValue[i - order_level] - _actualData.Rows(i)[1]);
            }
            compute_result /= (numRow - order_level);

            return compute_result;
        }

        public float GetEvaluationValue()
        {
            return _evaluationValue;
        }

        public List<float> GetForecastedValue()
        {
            return _forecastedValue;
        }

        public void WriteFuzzyRelation()
        {
            int numrow = _actualData.RowsCount;
            StreamWriter writer = new StreamWriter(_FTS_Parameter.FilePath + "\\FuzzyRelation.txt");

            string title = "Name\t Real Data\t Fuzzy Label";
            writer.WriteLine(title);
            for (int i = 0; i < numrow; i++)
            {
                writer.WriteLine(_actualData.Rows(i)[0].ToString() + "\t" + _actualData.Rows(i)[1].ToString() + "\t A" + (_actualData.Rows(i).TermIndex + 1).ToString());
            }
            writer.WriteLine("-------------------------------------------------------------");
            title = "Name\t Fuzzy Relation";
            writer.WriteLine(title);
            for (int i = 1; i < numrow; i++)
            {
                writer.WriteLine(_actualData.Rows(i)[0].ToString() + "\t A" + (_actualData.Rows(i - 1).TermIndex + 1).ToString() + "-->A" + (_actualData.Rows(i).TermIndex + 1).ToString());
            }
            writer.Close();
        }

        public void WriteFuzzyRelationGroup(int order_level)
        {
            StreamWriter writer = new StreamWriter(_FTS_Parameter.FilePath + "\\FuzzyRelationGroup.txt");
            int numRow = _actualData.RowsCount, j, l;

            string title = "Name\t Real Data\t Fuzzy Label";
            writer.WriteLine(title);
            for (l = 0; l < order_level; l++)
            {
                writer.WriteLine(_actualData.Rows(l)[0].ToString() + "\t" + _actualData.Rows(l)[1].ToString() + "\t");
            }
            for (l = order_level; l < numRow; l++) //Bỏ qua dòng dữ liệu đầu
            {
                int i = _actualData.Rows(l).DataGroupIndex; //l - order_level;

                title = _actualData.Rows(l)[0].ToString() + "\t" + _actualData.Rows(l)[1].ToString() + "\t";
                for (j = 0; j < fuzzyRG[i].LeftHandCount(); j++)
                {
                    title += "A" + (fuzzyRG[i].LeftHandSide(j) + 1).ToString();
                    if (j < fuzzyRG[i].LeftHandCount() - 1) title += ", ";
                }
                title += "-->";
                if (fuzzyRG[i].RightHandCount() >= 1)
                {
                    for (j = 0; j < fuzzyRG[i].RightHandCount(); j++)
                    {
                        title += "A" + (fuzzyRG[i].RightHandSide(j) + 1).ToString();
                        if (j < fuzzyRG[i].RightHandCount() - 1) title += ", ";
                    }
                }
                else
                {
                    title += "#";
                }
                writer.WriteLine(title);
            }
            writer.Close();
        }

        public void WriteForecastValue(List<float> forcastValue, int order_level, float evaluationVa)
        {
            StreamWriter writer = new StreamWriter(_FTS_Parameter.FilePath + "\\Forecasted.txt");
            int numRow = _actualData.RowsCount;

            string title = "Name\tReal Value\t Forecasted Value";
            writer.WriteLine(title);
            for (int i = 0; i < order_level; i++)
                writer.WriteLine(_actualData.Rows(i)[0].ToString() + "\t" + _actualData.Rows(i)[1].ToString());
            for (int i = order_level; i < numRow; i++)
            {
                writer.WriteLine(_actualData.Rows(i)[0].ToString() + "\t" + _actualData.Rows(i)[1].ToString() + "\t" + forcastValue[i - order_level].ToString());
            }
            writer.WriteLine("-------------------------------------------");
            writer.WriteLine("Evaluation value by MSE: " + evaluationVa.ToString());
            writer.WriteLine("Evaluation value by RMSE: " + Math.Sqrt(evaluationVa).ToString());

            writer.Close();
        }
    }
}
