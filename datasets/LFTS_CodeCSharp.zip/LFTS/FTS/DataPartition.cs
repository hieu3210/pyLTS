﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FTS
{
    public class DataPartition
    {
        public float _minValue;
        public float _maxValue;
        public List<DataInterval> _intervalList;
        public List<TriangleFuzzySet> _fuzzysetList;

        public DataInterval Interval(int index)
        {
            try
            {
                return _intervalList[index];
            }
            catch (RankException ex)
            {
                throw ex;
            }

        }

        public TriangleFuzzySet Fuzzyset(int index)
        {
            try
            {
                return _fuzzysetList[index];
            }
            catch (RankException ex)
            {
                throw ex;
            }

        }

        public DataPartition(float v_minValue, float v_maxValue)
        {
            _minValue = v_minValue;
            _maxValue = v_maxValue;
            _intervalList = new List<DataInterval>();
            _fuzzysetList = new List<TriangleFuzzySet>();
        }

        public DataPartition()
        {
            _intervalList = new List<DataInterval>();
            _fuzzysetList = new List<TriangleFuzzySet>();
        }

        public void AddInterval(DataInterval v_interval)
        {
            _intervalList.Add(v_interval);
        }

        public void RemoveInterval(int v_index)
        {
            _intervalList.RemoveAt(v_index);
            _fuzzysetList.RemoveAt(v_index);
        }

        public void RemoveAll()
        {
            _intervalList.Clear();
            _fuzzysetList.Clear();
        }

        public int GetNumberOfInterval()
        {
            return _intervalList.Count;
        }

        public void SetMinMaxValue(float v_minValue, float v_maxValue)
        {
            _minValue = v_minValue;
            _maxValue = v_maxValue;
        }

        public void DetermineDataPartition(List<float> pointList)
        {
            RemoveAll();
            DataInterval vInter1 = new DataInterval(_minValue, _minValue + pointList[0]);
            _intervalList.Add(vInter1);
            for (int i = 1; i < pointList.Count; i++)
            {
                DataInterval vInter = new DataInterval(_minValue + pointList[i - 1], _minValue + pointList[i]);
                _intervalList.Add(vInter);
            }
            DataInterval vInter2 = new DataInterval(_minValue + pointList[pointList.Count - 1], _maxValue);
            _intervalList.Add(vInter2);
            DefineFuzzyset();
        }

        public void DetermineDataPartition(int numberOfInterval)
        {
            float leftValue = _minValue;
            float eInter = (_maxValue - _minValue) / numberOfInterval;
            float rightValue = leftValue + eInter;

            for (int i = 0; i < numberOfInterval; i++)
            {
                DataInterval vInter = new DataInterval(leftValue, rightValue);
                _intervalList.Add(vInter);
                leftValue = rightValue;
                rightValue += eInter;
            }
            DefineFuzzyset();
        }

        public void DefineFuzzyset()
        {
            int numInterval = _intervalList.Count;

            if (numInterval <= 1) return;
            int k = 0;
            while (k < numInterval)
            {
                TriangleFuzzySet vMS;

                if (k == 0)
                {
                    vMS = new TriangleFuzzySet("A" + (k + 1).ToString(), _intervalList[k].Left, _intervalList[k].Left, (_intervalList[k + 1].Left + _intervalList[k + 1].Right) / 2);
                }
                else if (k == numInterval - 1)
                {
                    vMS = new TriangleFuzzySet("A" + (k + 1).ToString(), (_intervalList[k - 1].Left + _intervalList[k - 1].Right) / 2, _intervalList[k].Right, _intervalList[k].Right);
                }
                else
                {
                    float lv = _intervalList[k - 1].Left;
                    if (k > 1) lv = (_intervalList[k - 1].Left + _intervalList[k - 1].Right) / 2;
                    float rv = _intervalList[k + 1].Right;
                    if (k < numInterval - 1) rv = (_intervalList[k + 1].Left + _intervalList[k + 1].Right) / 2;
                    vMS = new TriangleFuzzySet("A" + (k + 1).ToString(), lv, (_intervalList[k].Left + _intervalList[k].Right) / 2, rv);
                }
                _fuzzysetList.Add(vMS);
                k++;
            }
        }

 
    }
}
