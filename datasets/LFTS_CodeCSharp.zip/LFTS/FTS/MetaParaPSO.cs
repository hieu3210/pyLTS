﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PhD.PSO;
using PhD.Common;
using System.IO;
using PhD.HA;

namespace FTS
{
    public class MetaParaPSO
    {
        int dim = 2; // problem dimensions
        int numParticles = 20;
        int maxEpochs = 100;
        double exitError = 0.0; // exit early if reach this error
        double minX = 0.25; // problem-dependent
        double maxX = 0.75;
        private PSOParameters _params;
        private FTS_Parameters _exparams;
        LFTSPSOSwarm _lpop;
        private List<ParticleData> _noDomParValues;
        private double[] globalBestResult;
        private string _FileName;
        private FTSDataTable _actualData;

        public MetaParaPSO(PSOParameters param, FTS_Parameters exparam)
        {
            _params = param;
            _exparams = exparam;
            globalBestResult = new double[2];
            _noDomParValues = new List<ParticleData>();
            maxEpochs = param.NoOuterGenerations;
            numParticles = param.SizeOfOuterPopulation;
            _FileName = exparam.FilePath + "\\" + exparam.FileName;
            _actualData = new FTSDataTable(_FileName);
            exparam.NumberOfForecastedValue = _actualData.LoadData();
            exparam.MaxValue = _actualData.MaxValue;
            exparam.MinValue = _actualData.MinValue;
        }

        public double BestMuyL
        {
            get { return globalBestResult[0]; }
        }

        public double BestMuyFmCMinus
        {
            get { return globalBestResult[1]; }
        }

        private double Evaluate(double[] x)
        {
            List<ParticleData> noDom = new List<ParticleData>();
            HASingleSFISystem haSFI;

            HedgeAlgebras ha = new HedgeAlgebras((float)x[1], (float)x[0]);
            haSFI = new HASingleSFISystem(ha, _exparams.kmax);
            haSFI.CreateSFISystem();
            haSFI.CreateVxR(_exparams.MinValue, _exparams.MaxValue);

            _lpop = new LFTSPSOSwarm(_params, _exparams, _actualData, haSFI);
            _lpop.MuyL = (float)x[0];
            _lpop.MuyFmCMinus = (float)x[1];

            _lpop.start_fly();
            for (int i = 0; i < _lpop.DomParValues.Count; i++)
                noDom.Add(_lpop.DomParValues[i]);

            if (_noDomParValues.Count < 1)
                for (int i = 0; i < noDom.Count; i++)
                    _noDomParValues.Add(noDom[i]);
            else
            {
                if (noDom[0]._evaluationValue < _noDomParValues[0]._evaluationValue)
                {
                    if (_noDomParValues.Count > 0) _noDomParValues.Clear();
                    for (int i = 0; i < noDom.Count; i++)
                        _noDomParValues.Add(noDom[i]);
                }
            }

            return noDom[0]._evaluationValue;
        }


        public void Solve(Object obj)
        {
            // assumes existence of an accessible Error function and a Particle class
            frmMyProgress frm = obj as PhD.PSO.frmMyProgress;
            Random rnd = new Random(0);

            Particle[] swarm = new Particle[numParticles];
            double[] bestGlobalPosition = new double[dim]; // best solution found by any particle in the swarm
            double bestGlobalError = double.MaxValue; // smaller values better

            frm.SetMax(maxEpochs);
            frm.SetCaption("Đang khởi tạo ...");
            // swarm initialization
            for (int i = 0; i < swarm.Length; ++i)
            {
                double[] randomPosition = new double[dim];
                for (int j = 0; j < randomPosition.Length; ++j)
                    randomPosition[j] = (maxX - minX) * rnd.NextDouble() + minX; // 

                double error = Evaluate(randomPosition);
                double[] randomVelocity = new double[dim];

                for (int j = 0; j < randomVelocity.Length; ++j)
                {
                    double lo = minX * 0.1;
                    double hi = maxX * 0.1;
                    randomVelocity[j] = (hi - lo) * rnd.NextDouble() + lo;
                }
                swarm[i] = new Particle(randomPosition, error, randomVelocity, randomPosition, error);

                // does current Particle have global best position/solution?
                if (swarm[i].error < bestGlobalError)
                {
                    bestGlobalError = swarm[i].error;
                    swarm[i].position.CopyTo(bestGlobalPosition, 0);
                }
            } // initialization
            frm.SetCaption("Khởi tạo xong...");

            // prepare
            double w = 0.729; //Inertia weight
            double c1 = 1.49445; // cognitive/local weight
            double c2 = 1.49445; // social/global weight
            double r1, r2; // cognitive and social randomizations
            double probDeath = 0.01;
            int epoch = 0;

            double[] newVelocity = new double[dim];
            double[] newPosition = new double[dim];
            double newError;

            frm.SetCaption("Bắt đầu vào vòng lặp!");
            // main loop
            while (epoch < maxEpochs)
            {
                System.Threading.Thread.Sleep(5);
                frm.SetCaption("Đang thực hiện đến thế hệ thứ: " + (epoch + 1).ToString() + "/" + maxEpochs.ToString());
                frm.IncreasePercent();

                for (int i = 0; i < swarm.Length; ++i) // each Particle
                {
                    Particle currP = swarm[i]; // for clarity

                    // new velocity
                    for (int j = 0; j < currP.velocity.Length; ++j) // each component of the velocity
                    {
                        r1 = rnd.NextDouble();
                        r2 = rnd.NextDouble();

                        newVelocity[j] = (w * currP.velocity[j]) +
                          (c1 * r1 * (currP.bestPosition[j] - currP.position[j])) +
                          (c2 * r2 * (bestGlobalPosition[j] - currP.position[j]));
                    }
                    newVelocity.CopyTo(currP.velocity, 0);

                    // new position
                    for (int j = 0; j < currP.position.Length; ++j)
                    {
                        newPosition[j] = currP.position[j] + newVelocity[j];
                        if (newPosition[j] < minX)
                            newPosition[j] = minX;
                        else if (newPosition[j] > maxX)
                            newPosition[j] = maxX;
                    }
                    newPosition.CopyTo(currP.position, 0);

                    newError = Evaluate(newPosition);
                    currP.error = newError;

                    if (newError < currP.bestError)
                    {
                        newPosition.CopyTo(currP.bestPosition, 0);
                        currP.bestError = newError;
                    }

                    if (newError < bestGlobalError)
                    {
                        newPosition.CopyTo(bestGlobalPosition, 0);
                        bestGlobalError = newError;
                    }

                    // death?
                    double die = rnd.NextDouble();
                    if (die < probDeath)
                    {
                        // new position, leave velocity, update error
                        for (int j = 0; j < currP.position.Length; ++j)
                            currP.position[j] = (maxX - minX) * rnd.NextDouble() + minX;
                        currP.error = Evaluate(currP.position);
                        currP.position.CopyTo(currP.bestPosition, 0);
                        currP.bestError = currP.error;

                        if (currP.error < bestGlobalError) // global best by chance?
                        {
                            bestGlobalError = currP.error;
                            currP.position.CopyTo(bestGlobalPosition, 0);
                        }
                    }

                } // each Particle
                ++epoch;
            } // while

            //double[] result = new double[dim];
            //bestGlobalPosition.CopyTo(result, 0);
            bestGlobalPosition.CopyTo(globalBestResult, 0);
            StreamWriter writer;
            string fname = _exparams.FilePath + "\\GlobalBestResult_k" + _exparams.kmax.ToString() + "-" + _exparams.orderlevel.ToString() + "-nt" + _exparams.NoPartition.ToString() + ".txt";
            if (File.Exists(fname))
                writer = new StreamWriter(fname);
            else
                writer = File.CreateText(fname);

            writer.WriteLine("Number of outer loops: " + _params.NoOuterGenerations.ToString() + ", Number of particles: " + _params.SizeOfOuterPopulation.ToString());
            writer.WriteLine("Number of inner loops: " + _params.NoGenerations.ToString() + ", Number of particles: " + _params.SizeOfPopulation.ToString());
            writer.WriteLine("----------------------------------------------------------------");
            writer.WriteLine("Max length of terms: " + _exparams.kmax.ToString() + ", Number of selected terms: " + _exparams.NoPartition.ToString());
            writer.WriteLine("Order level: " + _exparams.orderlevel.ToString());
            writer.WriteLine("----------------------------------------------------------------");
            int k = 0;
            for (int i = 0; i < _noDomParValues.Count; i++)
            {
                writer.WriteLine("MuyL: " + globalBestResult[0].ToString() + ", MuyFmC-: " + globalBestResult[1].ToString());
                writer.WriteLine("----------------------------------------------------------------");
                for (int j = 0; j < _params.NumberOfDimension; j++)
                {
                    k = (int)Math.Round(_noDomParValues[i].nonDominatedParticle[j], 0);
                    if (j < _params.NumberOfDimension - 1)
                        writer.Write(k.ToString() + " (" + _noDomParValues[i].HASystem.Revert(_noDomParValues[i].HASystem[k].Term.WordX) + "), ");
                    else
                        writer.Write(k.ToString() + " (" + _noDomParValues[i].HASystem.Revert(_noDomParValues[i].HASystem[k].Term.WordX) + ")");
                }
                for (int j = 0; j < _params.NumberOfFunction; j++)
                    writer.Write("---" + _noDomParValues[i].nonDominatedFitness[j].ToString() + "---");
                writer.WriteLine();
                writer.WriteLine("MSE value: " + _noDomParValues[i]._evaluMSE + ", RMSE value: " + (float)Math.Sqrt(_noDomParValues[i]._evaluMSE) + ", ME value: " + _noDomParValues[i]._evaluME + ", MAPE value: " + _noDomParValues[i]._evaluMAPE);
                writer.Write("Forecasted Data: ");
                for (int j = 0; j < _noDomParValues[i].NumberOfForcastedValue; j++)
                    if (j < _noDomParValues[i].NumberOfForcastedValue - 1)
                        writer.Write(_noDomParValues[i].forcastedvalue[j].ToString() + ", ");
                    else
                        writer.Write(_noDomParValues[i].forcastedvalue[j].ToString());
                writer.WriteLine();
            }
            writer.Flush();
            writer.Close();
            frm.CloseForm();

            //return result;
        } // Solve

        public class Particle
        {
            public double[] position;
            public double error;
            public double[] velocity;
            public double[] bestPosition;
            public double bestError;

            public Particle(double[] pos, double err, double[] vel, double[] bestPos, double bestErr)
            {
                this.position = new double[pos.Length];
                pos.CopyTo(this.position, 0);
                this.error = err;
                this.velocity = new double[vel.Length];
                vel.CopyTo(this.velocity, 0);
                this.bestPosition = new double[bestPos.Length];
                bestPos.CopyTo(this.bestPosition, 0);
                this.bestError = bestErr;
            }


        } // Particle

    }
}
