﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using PhD.HA;

namespace FTS
{
    public class LinguisticFuzzyTimeSeries
    {
        private FTSDataTable _actualData;
        private float _minValue;
        private float _maxValue;
        private int _numberOfInterval;
        private List<FuzzyRelationGroup> fuzzyRG;
        private List<float> _forecastedValue = new List<float>();
        FTS_Parameters _FTS_Parameter;
        private float _evaluationValue;
        private float _evaluMSE;
        private float _evaluMAPE;
        private float _evaluME;
        private bool _isTimeVariant;
        HASingleSFISystem haSFI;
        List<int> termList = new List<int>();

        public HASingleSFISystem HASystem
        {
            get { return haSFI; }
            set { HASystem = value; }
        }

        public LinguisticFuzzyTimeSeries(FTS_Parameters FTS_Parameter, FTSDataTable actuData)
        {
            FTS_Parameter.MinValue = actuData.MinValue;
            FTS_Parameter.MaxValue = actuData.MaxValue;
            _isTimeVariant = FTS_Parameter.TimeVariant;
            _minValue = FTS_Parameter.MinValue;
            _maxValue = FTS_Parameter.MaxValue;
            FTS_Parameter.NumberOfForecastedValue = actuData.RowsCount;
            _FTS_Parameter = FTS_Parameter;
            _actualData = actuData;
            _numberOfInterval = _FTS_Parameter.NoPartition;
            fuzzyRG = new List<FuzzyRelationGroup>();
            _forecastedValue = new List<float>();
            _evaluationValue = -1.0f;
            termList = new List<int>();
        }

        public void SetupNewPartition(List<float> pointList)
        {
            int n = pointList.Count;
            termList.Clear();
            for (int i = 0; i < n; i++)
                termList.Add((int)Math.Round(pointList[i], 0));
        }

        public void SetNewMetaParameter(float muyFmC, float muyL)
        {
            _FTS_Parameter.FmC_minus = muyFmC;
            _FTS_Parameter.MuyL = muyL;
        }

        public void StartForecasting(bool isEqualSize, HASingleSFISystem haSFISys)
        {
            int orLevel = 1;

            if (isEqualSize)
            {
                //string tes = "VV-,LV-,LL-,VL-,VL+,LL+,V+";
                string tes = "V-,-,L-,W,L+,+,V+";
                if (_numberOfInterval == 9)
                    tes = "0,V-,-,L-,W,L+,+,V+,1";
                else if (_numberOfInterval == 14)
                    //tes = "0, VV-,V-,LV-,-,LL-,L-,VL-,W,VL+,L+,LL+,+,LV+,V+,VV+,1";
                    tes = "0,VV-,V-,LV-,LL-,L-,VL-,W,VL+,L+,+,LV+,VV+,1";
                List<string> terms = new List<string>();
                string[] spl = tes.Split(',');
                for (byte i = 0; i < spl.Length; i++)
                {
                    terms.Add(spl[i].Trim());
                }

                HedgeAlgebras ha = new HedgeAlgebras(_FTS_Parameter.FmC_minus, _FTS_Parameter.MuyL);
                haSFI = new HASingleSFISystem(ha, _FTS_Parameter.kmax);
                haSFI.CreateSFISystem();
                haSFI.CreateVxR(_minValue, _maxValue);
                //termList = haSFI.RandomTermSelection(_numberOfInterval);
                termList = haSFI.SelectGivenTerms(terms);
            }
            else
                haSFI = haSFISys;

            FuzzifyData();
            if (isEqualSize) WriteFuzzyRelation();
            //--------------------------------------------------------
            if (_FTS_Parameter.orderlevel == OrderLevel.SecondOrder)
                orLevel = 2;
            else if (_FTS_Parameter.orderlevel == OrderLevel.ThirdOrder)
                orLevel = 3;
            else if (_FTS_Parameter.orderlevel == OrderLevel.FourthOrder)
                orLevel = 4;
            else if (_FTS_Parameter.orderlevel == OrderLevel.FifthOrder)
                orLevel = 5;
            else if (_FTS_Parameter.orderlevel == OrderLevel.SixthOrder)
                orLevel = 6;
            else if (_FTS_Parameter.orderlevel == OrderLevel.SeventhOrder)
                orLevel = 7;
            else if (_FTS_Parameter.orderlevel == OrderLevel.EighthOrder)
                orLevel = 8;
            else if (_FTS_Parameter.orderlevel == OrderLevel.NinthOrder)
                orLevel = 9;
            //---------------------------------------------------------------
            if (_FTS_Parameter.orderlevel == OrderLevel.FirstOrder)
                CreateFirstOrderTVFLRG();
            else
            {
                Create_M_OrderTVFLRG(orLevel);
            }
            WriteFuzzyRelationGroup(orLevel);
            //-----------------------------------------------------------------------------------
            if (_FTS_Parameter.defuzzificationMethod == DefuzzificationMethod.TVFLRG_Weighted)
                _forecastedValue = Defuzzify_Weighted(orLevel);
            else if (_FTS_Parameter.defuzzificationMethod == DefuzzificationMethod.TVFLRG_NoWeight)
                _forecastedValue = Defuzzify_NoWeight(orLevel);
            else if (_FTS_Parameter.defuzzificationMethod == DefuzzificationMethod.TVFLRG_Proportion)
                _forecastedValue = Defuzzify_No_weight_LH(orLevel);
            //-----------------------------------------------------------------------------------
            _evaluMSE = Compute_MSE(_forecastedValue, orLevel);
            _evaluMAPE = Compute_MAPE(_forecastedValue, orLevel);
            _evaluME = Compute_ME(_forecastedValue, orLevel);
            if (_FTS_Parameter.evaluationMethod == EvaluationMethod.MSE)
                _evaluationValue = _evaluMSE;
            else if (_FTS_Parameter.evaluationMethod == EvaluationMethod.RMSE)
                _evaluationValue = Compute_RMSE(_forecastedValue, orLevel);
            else if (_FTS_Parameter.evaluationMethod == EvaluationMethod.ME)
                _evaluationValue = _evaluME;
            //-----------------------------------------------------------------------------------
            if (isEqualSize) WriteForecastValue(_forecastedValue, orLevel, _evaluationValue);
            //WriteForecastValue(_forecastedValue, orLevel, _evaluationValue);
        }

        public void FuzzifyData()
        {
            int numRow = _actualData.RowsCount;
            int noTerm = termList.Count;

            for (int row = 0; row < numRow; row++)
            {
                int termIndex = termList[0];
                float mindis = Convert.ToSingle(Math.Pow(_actualData.Rows(row)[1] - haSFI[termIndex].Term.VxR, 2)), dis;

                for (int j = 1; j < noTerm; j++)
                {
                    dis = Convert.ToSingle(Math.Pow(_actualData.Rows(row)[1] - haSFI[termList[j]].Term.VxR, 2));
                    if (dis < mindis)
                    {
                        mindis = dis;
                        termIndex = termList[j];
                    }
                }
                _actualData.Rows(row).TermIndex = termIndex;
            }

        }

        public void CreateFirstOrderTVFLRG()
        {
            int numRow = _actualData.RowsCount;
            List<int> leftHand = new List<int>();
            List<int> rightHand = new List<int>();
            List<int> rightHand_data = new List<int>();

            int i = 1, k, l;
            while (i < numRow)
            {
                leftHand.Add(_actualData.Rows(i - 1).TermIndex);
                rightHand.Add(_actualData.Rows(i).TermIndex);
                rightHand_data.Add(i);
                i++;
            }

            i = 0;
            FuzzyRelationGroup frg = new FuzzyRelationGroup();
            frg.AddLeftHandSide(leftHand[i]);
            frg.AddRightHandSide(rightHand[i], rightHand_data[i]);
            fuzzyRG.Add(frg);
            l = i + 1;
            _actualData.Rows(l).DataGroupIndex = 0;
            i++; l++;
            while (i < leftHand.Count)
            {
                k = fuzzyRG.Count - 1;
                if (_isTimeVariant)
                {
                    FuzzyRelationGroup new_frg = new FuzzyRelationGroup();
                    while (k >= 0)
                    {
                        if (fuzzyRG[k].LeftHandSide(0) == leftHand[i]) //Neu cung ve trai thi add them ve phai
                        {
                            for (int j = 0; j < fuzzyRG[k].RightHandCount(); j++)
                            {
                                new_frg.AddRightHandSide(fuzzyRG[k].RightHandSide(j), fuzzyRG[k].RightHandSideData(j));
                            }
                            break;
                        }
                        k--;
                    }
                    new_frg.AddLeftHandSide(leftHand[i]);
                    new_frg.AddRightHandSide(rightHand[i], rightHand_data[i]);
                    _actualData.Rows(l).DataGroupIndex = fuzzyRG.Count;
                    fuzzyRG.Add(new_frg); //Tao FRG moi
                }
                else
                {
                    bool isNotAdded = true;
                    while (k >= 0)
                    {
                        if (fuzzyRG[k].LeftHandSide(0) == leftHand[i]) //Neu cung ve trai thi add them ve phai
                        {
                            if (_FTS_Parameter.isChenModel)
                            {
                                //Nếu là Chen model thì loại bỏ vế phải trùng
                                int j = fuzzyRG[k].RightHandCount() - 1;
                                while (j >= 0)
                                {
                                    if (fuzzyRG[k].RightHandSide(j) == rightHand[i]) break;
                                    j--;
                                }
                                if (j < 0) fuzzyRG[k].AddRightHandSide(rightHand[i], rightHand_data[i]);
                            }
                            else fuzzyRG[k].AddRightHandSide(rightHand[i], rightHand_data[i]);
                            _actualData.Rows(l).DataGroupIndex = k;
                            isNotAdded = false;
                            break;
                        }
                        k--;
                    }
                    if (isNotAdded)
                    {
                        FuzzyRelationGroup new_frg = new FuzzyRelationGroup();
                        new_frg.AddLeftHandSide(leftHand[i]);
                        new_frg.AddRightHandSide(rightHand[i], rightHand_data[i]);
                        _actualData.Rows(l).DataGroupIndex = fuzzyRG.Count;
                        fuzzyRG.Add(new_frg); //Tao FRG moi
                    }
                }
                i++; l++;
            }

        }

        public void Create_M_OrderTVFLRG(int orderLevel)
        {
            int numRow = _actualData.RowsCount;
            List<List<int>> leftHand = new List<List<int>>();
            List<int> rightHand = new List<int>();
            List<int> rightHand_data = new List<int>();

            int i = orderLevel, k, l;
            while (i < numRow)
            {
                k = i;
                List<int> ld = new List<int>();
                while (k > i - orderLevel)
                {
                    ld.Add(_actualData.Rows(k - 1).TermIndex);
                    k--;
                }
                leftHand.Add(ld);
                rightHand.Add(_actualData.Rows(i).TermIndex);
                rightHand_data.Add(i);
                i++;
            }

            i = 0;
            FuzzyRelationGroup frg = new FuzzyRelationGroup();
            for (int j = 0; j < leftHand[i].Count; j++)
            {
                frg.AddLeftHandSide(leftHand[i][j]);
            }
            frg.AddRightHandSide(rightHand[i], rightHand_data[i]);
            fuzzyRG.Add(frg);
            l = i + orderLevel;
            _actualData.Rows(l).DataGroupIndex = 0;
            i++; l++;
            while (i < leftHand.Count)
            {
                FuzzyRelationGroup new_frg = new FuzzyRelationGroup();
                for (int j = 0; j < leftHand[i].Count; j++)
                {
                    new_frg.AddLeftHandSide(leftHand[i][j]);
                }
                k = fuzzyRG.Count - 1;
                bool isNotAdded = true;
                while (k >= 0)
                {
                    if (new_frg.IsLeftHandEqual(fuzzyRG[k])) //Neu cung ve trai thi add them ve phai
                    {
                        if (_isTimeVariant)
                        {
                            for (int j = 0; j < fuzzyRG[k].RightHandCount(); j++)
                            {
                                new_frg.AddRightHandSide(fuzzyRG[k].RightHandSide(j), fuzzyRG[k].RightHandSideData(j));
                            }
                            _actualData.Rows(l).DataGroupIndex = i - orderLevel;
                        }
                        else
                        {
                            if (_FTS_Parameter.isChenModel)
                            {
                                //Nếu là Chen model thì loại bỏ vế phải trùng
                                int j = fuzzyRG[k].RightHandCount() - 1;
                                while (j >= 0)
                                {
                                    if (fuzzyRG[k].RightHandSide(j) == rightHand[i]) break;
                                    j--;
                                }
                                if (j < 0) fuzzyRG[k].AddRightHandSide(rightHand[i], rightHand_data[i]);
                            }
                            else fuzzyRG[k].AddRightHandSide(rightHand[i], rightHand_data[i]);
                            _actualData.Rows(l).DataGroupIndex = k;
                            isNotAdded = false;
                        }
                        break;
                    }
                    k--;
                }
                if (_isTimeVariant || isNotAdded)
                {
                    new_frg.AddRightHandSide(rightHand[i], rightHand_data[i]);
                    _actualData.Rows(l).DataGroupIndex = fuzzyRG.Count;
                    fuzzyRG.Add(new_frg); //Tao FRG moi
                }
                i++; l++;
            }
        }


        public List<float> Defuzzify_NoWeight(int order_level)
        {
            int numRow = _actualData.RowsCount;
            List<float> forcastValue = new List<float>();

            for (int l = order_level; l < numRow; l++) //Bỏ qua dòng dữ liệu đầu
            {
                float forcast_value = 0.0f;
                int i = _actualData.Rows(l).DataGroupIndex; //l - order_level;

                if (fuzzyRG[i].RightHandCount() < 1)
                {
                    forcast_value = haSFI[_actualData.Rows(l).TermIndex].Term.VxR;
                }
                else
                {
                    for (int k = 0; k < fuzzyRG[i].RightHandCount(); k++)
                    {
                        forcast_value += haSFI[fuzzyRG[i].RightHandSide(k)].Term.VxR;
                    }
                    forcast_value /= fuzzyRG[i].RightHandCount();
                }
                forcastValue.Add(forcast_value);
            }

            return forcastValue;
        }

        public List<float> Defuzzify_Weighted(int order_level)
        {
            int numRow = _actualData.RowsCount;
            List<float> forcastValue = new List<float>();

            for (int l = order_level; l < numRow; l++) //Bỏ qua dòng dữ liệu đầu
            {
                float forcast_value = 0.0f;
                int i = _actualData.Rows(l).DataGroupIndex; //l - order_level;

                if (fuzzyRG[i].RightHandCount() < 1)
                {
                    forcast_value = haSFI[_actualData.Rows(l).TermIndex].Term.VxR;
                }
                else
                {
                    float sum = 0;
                    for (int k = 0; k < fuzzyRG[i].RightHandCount(); k++)
                    {
                        forcast_value += (k + 1) * haSFI[fuzzyRG[i].RightHandSide(k)].Term.VxR;
                        sum += k + 1;
                    }
                    forcast_value /= sum;
                }
                forcastValue.Add(forcast_value);
            }

            return forcastValue;
        }

        public List<float> Defuzzify_No_weight_LH(int order_level)
        {
            int numRow = _actualData.RowsCount;
            List<float> forcastValue = new List<float>();

            for (int l = order_level; l < numRow; l++) //Bỏ qua dòng dữ liệu đầu
            {
                float forcast_value = 0.0f;
                int i = _actualData.Rows(l).DataGroupIndex; //l - order_level;

                if (fuzzyRG[i].RightHandCount() < 1)
                {
                    forcast_value = haSFI[_actualData.Rows(l).TermIndex].Term.VxR;
                }
                else
                {
                    for (int k = 0; k < fuzzyRG[i].RightHandCount(); k++)
                    {
                        forcast_value += haSFI[fuzzyRG[i].RightHandSide(k)].Term.VxR;
                    }
                    forcast_value /= fuzzyRG[i].RightHandCount();
                    forcast_value = 0.5f * (forcast_value + haSFI[_actualData.Rows(l).TermIndex].Term.VxR);
                }
                forcastValue.Add(forcast_value);
            }

            return forcastValue;
        }

        public float Compute_MSE(List<float> forcastValue, int order_level)
        {
            int numRow = _actualData.RowsCount;
            float compute_result = 0.0f;

            for (int i = order_level; i < numRow; i++)
            {
                compute_result += (float)Math.Pow(forcastValue[i - order_level] - _actualData.Rows(i)[1], 2);
            }
            compute_result /= (numRow - order_level);

            return compute_result;
        }

        public float Compute_RMSE(List<float> forcastValue, int order_level)
        {
            float compute_result = (float)Math.Sqrt(Compute_MSE(forcastValue, order_level));

            return compute_result;
        }

        public float Compute_ME(List<float> forcastValue, int order_level)
        {
            int numRow = _actualData.RowsCount;
            float compute_result = 0.0f;

            for (int i = order_level; i < numRow; i++)
            {
                compute_result += (float)Math.Abs(forcastValue[i - order_level] - _actualData.Rows(i)[1]);
            }
            compute_result /= (numRow - order_level);

            return compute_result;
        }

        public float Compute_MAPE(List<float> forcastValue, int order_level)
        {
            int numRow = _actualData.RowsCount;
            float compute_result = 0.0f;

            for (int i = order_level; i < numRow; i++)
            {
                compute_result += (float)Math.Abs(forcastValue[i - order_level] - _actualData.Rows(i)[1]) / _actualData.Rows(i)[1];
            }
            compute_result /= (numRow - order_level);

            return compute_result * 100;
        }

        public float GetEvaluationValue()
        {
            return _evaluationValue;
        }

        public float GetMSEValue()
        {
            return _evaluMSE;
        }

        public float GetMEValue()
        {
            return _evaluME;
        }

        public float GetMAPEValue()
        {
            return _evaluMAPE;
        }

        public List<float> GetForecastedValue()
        {
            return _forecastedValue;
        }

        public void WriteFuzzyRelation()
        {
            int numrow = _actualData.RowsCount;
            StreamWriter writer = new StreamWriter(_FTS_Parameter.FilePath + "\\FuzzyRelation.txt");

            string title = "Name\t Real Data\t Fuzzy Label";
            writer.WriteLine(title);
            for (int i = 0; i < numrow; i++)
            {
                writer.WriteLine(_actualData.Rows(i)[0].ToString() + "\t" + _actualData.Rows(i)[1].ToString() + "\t A" + (_actualData.Rows(i).TermIndex + 1).ToString() + " (" + haSFI[_actualData.Rows(i).TermIndex].Term.RWordX + ")");
            }
            writer.WriteLine("-------------------------------------------------------------");
            title = "Name\t Fuzzy Relation";
            writer.WriteLine(title);
            for (int i = 1; i < numrow; i++)
            {
                writer.WriteLine(_actualData.Rows(i)[0].ToString() + "\t A" + (_actualData.Rows(i - 1).TermIndex + 1).ToString() + " (" + haSFI[_actualData.Rows(i - 1).TermIndex].Term.RWordX + ")" + " --> A" + (_actualData.Rows(i).TermIndex + 1).ToString() + " (" + haSFI[_actualData.Rows(i).TermIndex].Term.RWordX + ")");
            }
            writer.Close();
        }

        public void WriteFuzzyRelationGroup(int order_level)
        {
            StreamWriter writer = new StreamWriter(_FTS_Parameter.FilePath + "\\FuzzyRelationGroup.txt");
            int numRow = _actualData.RowsCount, j, l;

            string title = "Name\t Real Data\t Fuzzy Label";
            writer.WriteLine(title);
            for (l = 0; l < order_level; l++)
            {
                writer.WriteLine(_actualData.Rows(l)[0].ToString() + "\t" + _actualData.Rows(l)[1].ToString() + "\t");
            }
            for (l = order_level; l < numRow; l++) //Bỏ qua dòng dữ liệu đầu
            {
                int i = _actualData.Rows(l).DataGroupIndex; //l - order_level;

                title = _actualData.Rows(l)[0].ToString() + "\t" + _actualData.Rows(l)[1].ToString() + "\t";
                for (j = 0; j < fuzzyRG[i].LeftHandCount(); j++)
                {
                    title += "A" + (fuzzyRG[i].LeftHandSide(j) + 1).ToString() + " (" + haSFI[fuzzyRG[i].LeftHandSide(j)].Term.RWordX + ")";
                    if (j < fuzzyRG[i].LeftHandCount() - 1) title += ", ";
                }
                title += " --> ";
                if (fuzzyRG[i].RightHandCount() >= 1)
                {
                    for (j = 0; j < fuzzyRG[i].RightHandCount(); j++)
                    {
                        title += "A" + (fuzzyRG[i].RightHandSide(j) + 1).ToString() + " (" + haSFI[fuzzyRG[i].RightHandSide(j)].Term.RWordX + ")";
                        if (j < fuzzyRG[i].RightHandCount() - 1) title += ", ";
                    }
                }
                else
                {
                    title += "#";
                }
                writer.WriteLine(title);
            }
            writer.Close();
        }

        public void WriteForecastValue(List<float> forcastValue, int order_level, float evaluationVa)
        {
            StreamWriter writer = new StreamWriter(_FTS_Parameter.FilePath + "\\Forecasted.txt");
            int numRow = _actualData.RowsCount;

            string title = "Name\tReal Value\t Forecasted Value";
            writer.WriteLine(title);
            for (int i = 0; i < order_level; i++)
                writer.WriteLine(_actualData.Rows(i)[0].ToString() + "\t" + _actualData.Rows(i)[1].ToString());
            for (int i = order_level; i < numRow; i++)
            {
                writer.WriteLine(_actualData.Rows(i)[0].ToString() + "\t" + _actualData.Rows(i)[1].ToString() + "\t" + forcastValue[i - order_level].ToString());
            }
            writer.WriteLine("-------------------------------------------");
            writer.WriteLine("Evaluation value by MSE: " + evaluationVa.ToString());
            writer.WriteLine("Evaluation value by RMSE: " + Math.Sqrt(evaluationVa).ToString());
            writer.WriteLine("Evaluation value by ME: " + _evaluME.ToString());
            writer.WriteLine("Evaluation value by MAPE: " + _evaluMAPE.ToString());

            writer.Close();
        }
    }
}
