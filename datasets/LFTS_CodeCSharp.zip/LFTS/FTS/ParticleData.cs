﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PhD.HA;

namespace FTS
{
    public class ParticleData
    {
        public float[] nonDominatedParticle;
        public float[] nonDominatedFitness;
        public List<FuzzyRelationGroup> fuzzyRG;
        public float[] forcastedvalue;
        public float _evaluationValue;
        public float _evaluMSE;
        public float _evaluMAPE;
        public float _evaluME;
        public int NumberOfForcastedValue;
        public HASingleSFISystem HASystem;

        public ParticleData(int NoDimention, int NoFitness, int NoForecastV)
        {
            nonDominatedParticle = new float[NoDimention];
            nonDominatedFitness = new float[NoFitness];
            forcastedvalue = new float[NoForecastV];
            fuzzyRG = new List<FuzzyRelationGroup>();
            NumberOfForcastedValue = NoForecastV;
        }
    }
}
