﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using PhD.FRSData;
using PhD.Common;

namespace PhD.HASGERD
{
    public class SGERDRulesSystem
    {
        private List<SGERDRule> _listRules;
        private SGERDParameter _params;      
        
        /// <summary>
        /// Danh sách các luật trong hệ luật
        /// </summary>
        public List<SGERDRule> Rules
        {
            get { return _listRules; }
        }
        /// <summary>
        /// Giá trị lớn nhất chiều dài luật
        /// </summary>
        public byte MaxLengthOfRules
        {
            get
            {
                byte max = _listRules[0].Length;
                for (int i = 1; i < _listRules.Count; i++)
                    if (max < _listRules[i].Length)
                        max = _listRules[i].Length;
                return max;
            }  
        }
        /// <summary>
        /// Trả lại giá trị trung bình chiều dài của hệ luật
        /// </summary>
        public float AverageLengthOfRules
        {
            get
            {
                float sum = 0;
                for (int i = 0; i < _listRules.Count; i++)
                    sum += _listRules[i].Length;
                return sum / _listRules.Count;
            }
        }
        /// <summary>
        /// Hàm tạo
        /// </summary>
        /// <param name="noClass"> Số lớp kết luận của dữ liệu</param>
        public SGERDRulesSystem(SGERDParameter param)
        {
            _params = param;
            _listRules = new List<SGERDRule>();
        }

        /// <summary>
        /// Hàm kiểm tra luật r có trong hệ luật hay không
        /// </summary>
        /// <param name="r">luật cần kiểm tra</param>
        /// <returns></returns>
        public bool Contains(SGERDRule r)
        {
            for (int i=0;i<_listRules.Count;i++)
                if ( r.Equals(_listRules[i]))
                    return true;
            return false;
        }
       
        /// <summary>
        /// Hàm lấy ra hệ luật gồm m luật tốt nhất
        /// </summary>
        /// <param name="m">Số luật tốt nhất cần lấy</param>
        /// <returns></returns>
        public SGERDRulesSystem GetBestRules()
        {
            SGERDRulesSystem frs = new SGERDRulesSystem(_params);
            int k = _params.NoSelectedRules / _params.NoConseqClass;     //Số luật cần lấy trên mỗi lớp
            int odd = _params.NoSelectedRules % _params.NoConseqClass;   //Số luật lẻ
            int t =0;                                                       //Số luật chưa lấy hết trên các lớp, vì chúng ta muốn lấy
                                                                             //ra k luật nhưng trong hệ luật chỉ có số luật < k
            int i, j, d;
            int idxmin, idxmax;
            for (int conseqClass = 0; conseqClass < _params.NoConseqClass; conseqClass++)
            {
                DetermineIndexOfClass(conseqClass, out idxmin, out idxmax);                
                if (idxmax < idxmin)
                    d = k;
                else
                {
                    i = idxmin;
                    j = 0;
                    while (j < k && i <= idxmax)
                    {
                        frs.Rules.Add(_listRules[i]);
                        _listRules[i].Selected = true;
                        j++;
                        i++;
                    }
                    d = k - j;
                }
                t += d; 
            }
            odd += t;  //phần lẻ cộng thêm số luật mà các lớp thiếu
            
            i = _listRules.Count-1;
            while (i > 0) //Loại bỏ các luật đã chọn
            {
                if(_listRules[i].Selected)
                    _listRules.RemoveAt(i);
                i--;
            }          
            i = 0;
            while (i < _listRules.Count && i < odd) //Lây thêm các luật lẻ
            {
                frs.Rules.Add(_listRules[i]);
                _listRules[i].Selected = true;
                i++;
            }
            
            i = _listRules.Count - 1;
            while (i > 0)//bỏ các luật đã chọn
            {
                if (_listRules[i].Selected)
                    _listRules.RemoveAt(i);
                i--;
            }     
            return frs;//trả lại hệ luật được chọn
        }
        public void SortOnClassAndFitness()
        {
            SortOnConsequenceClass();
            SortOnFitnessInConsequenceClass();
        }
        private void SortOnFitnessInConsequenceClass()
        {
            SGERDRule r;
            int idxmin, idxmax;
            for (int k = 0; k < _params.NoConseqClass; k++)
            {
                DetermineIndexOfClass(k, out idxmin, out  idxmax);
                for (int i = idxmin; i < idxmax; i++)
                    for (int j = i + 1; j <= idxmax; j++)
                        if (_listRules[i].Fitness < _listRules[j].Fitness)
                        {
                            r = _listRules[i];
                            _listRules[i] = _listRules[j];
                            _listRules[j] = r;
                        }
            }

        }
             
        /// <summary>
        /// Hàm sắp xếp các luật theo thứ tự của lớp kết luận
        /// </summary>
        private void SortOnConsequenceClass()
        {
            SGERDRule r;
            for (int i = 0; i < _listRules.Count - 1; i++)
                for (int j = i+1; j < _listRules.Count; j++)
                    if (_listRules[i].ConseqClass > _listRules[j].ConseqClass)
                    {
                        r = _listRules[i];
                        _listRules[i] = _listRules[j];
                        _listRules[j] = r;
                    }           
        }       
        /// <summary>
        /// Hàm xác định chỉ số đầu và chỉ số cuối của tập các luật có cùng kết luận là conseqClass trong hệ luật
        /// </summary>
        /// <param name="conseqClass"> Lớp kết luận</param>
        /// <param name="idxmin"></param>
        /// <param name="idxmax"></param>
        public void DetermineIndexOfClass(int conseqClass, out int idxmin, out int idxmax)
        {
            if (conseqClass >= _params.NoConseqClass)
            {
                idxmin = -1;
                idxmax = -2;
                return; 
            }
              
            int i=0;
            while( (i<_listRules.Count)&& (_listRules[i].ConseqClass != conseqClass))
                i++;
            idxmin = i;
            while((i<_listRules.Count) && (_listRules[i].ConseqClass==conseqClass))
                i++;
            if (i >= _listRules.Count)
                idxmax = _listRules.Count - 1;
            else
                idxmax = i - 1;
        }
       /// <summary>
       /// Lập luận trên mẫu dữ liệu, hàm trả lại lớp kết luận
       /// </summary>
       /// <param name="method">Phương pháp lập luận Single winer hoặc Vote </param>
        /// <param name="rowIndex"> Chỉ số của mẫu dữ liệu trong bảng</param>
       /// <param name="table">Bảng mẫu dữ liệu</param>
       /// <returns></returns>
        public byte Resioning(int rowIndex, FRSDatatable table)
        {
            float muy, maxmuy;
            int i; 
            byte conseqClass;
            if (_params.ResionMethod == ResionMethodType.SingleWiner) //single winner rule
            {
                maxmuy = 0; conseqClass = byte.MaxValue;
                for (i = 0; i < _listRules.Count; i++)
                {
                    muy = _listRules[i].MuyAq(table.Rows(rowIndex));
                    muy *= _listRules[i].Weight;
                    if (muy > maxmuy)
                    {
                        maxmuy = muy;
                        conseqClass = _listRules[i].ConseqClass;
                    }
                }
                return conseqClass;
            }
            else //Ver==2 : weighted vote method
            {
                float[] smuy = new float[table.ConseqClassCount];
                for (i = 0; i < table.ConseqClassCount; i++)
                    smuy[i] = 0;
                for (i = 0; i < _listRules.Count; i++)
                {
                    muy = _listRules[i].MuyAq(table.Rows(rowIndex));
                    smuy[_listRules[i].ConseqClass] += muy;
                }
                byte j ;
                for (conseqClass = 0, j = 1; j < table.ConseqClassCount; j++)
                    if (smuy[conseqClass] < smuy[j])
                        conseqClass = j;
                return conseqClass;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="fname"></param>
        public void WriteToFile(string fname)
        {
            StreamWriter writer = new StreamWriter(fname);
            string title = "CDai\t";
            for (int j = 0; j < _params.NoAttribute; j++)
            {
                title += "TT-" + j.ToString() + "\t";
            }
            title += "Conseq\tFitness";
            writer.WriteLine(title);
            for (int i = 0; i < _listRules.Count; i++)
            {
                writer.Write(_listRules[i].Length + "\t"); 
                for (int j = 0; j < _listRules[i].AttibuteCount; j++)
                {
                    writer.Write(_listRules[i][j].ToString() + "\t");
                }
                writer.Write(_listRules[i].ConseqClass.ToString() + "\t");
                //riter.Write(_listRules[i].Confident +"\t");
                //writer.Write(_listRules[i].Support +"\t");
                writer.WriteLine(_listRules[i].Fitness);
            }
            writer.Close();
        }

    }
}
