﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using PhD.Common;

namespace PhD.HASGERD
{
    public class SGERDParameter
    {
        private string _filepath;
        private string _fName;          //Tên file dữ liệu
        private byte _noAttribute;      //Số thuộc tính
        private byte _noConseqClass;    //Số lớp kết luận
        private int _noPatterns;     //Số mẫu dữ liệu
        private List<float> _fmc;       //Fmc-
        private List<float> _muyL;  
        private List<byte>  _kj;        //Chiều dài hạng từ 
        private SGERDFitnessFuntion _fitnessFunctionType;
        private ResionMethodType _resionMethod;
        private MethodTestType _methodTest;
        private int _noSelectedRules; //so luật được chọn
        
        public string Filepath
        {
            get { return _filepath; }
            set { _filepath = value; }
        }
        public string FileName
        {
            get { return _fName; }
        }
        public byte NoAttribute
        {
            get { return _noAttribute; }
            set { _noAttribute = value; }
        }
        public byte NoConseqClass
        {
            get { return _noConseqClass; }
            set { _noConseqClass = value; }
        }
        public int NoPatterns
        {
            get { return _noPatterns; }
            set { _noPatterns = value; }
        }

        public List<float> FmC
        {
            get { return _fmc; }
        }
        public List<float> MuyL
        {
            get { return _muyL; }
        }
        public List<byte> KJ
        {
            get { return _kj; }
        }
       
        public SGERDFitnessFuntion FitnessFunctionType
        {
            get { return _fitnessFunctionType;}
            set { _fitnessFunctionType = value; }
        }
        public ResionMethodType ResionMethod
        {
            get { return _resionMethod; }
            set { _resionMethod = value; }
        }
        public MethodTestType MethodTest
        {
            get { return _methodTest; }
            set { _methodTest = value; }
        }

        public int NoSelectedRules
        {
            get { return _noSelectedRules; }
            set { _noSelectedRules = value; }
        }
        public SGERDParameter()
        {
            _fmc = new List<float>();
            _muyL = new List<float>();
            _kj = new List<byte>();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="fname"></param>
        public void LoadParametersForOptimal(string fname)
        {
            try
            {
                StreamReader rd = new StreamReader(fname);
                _filepath = Path.GetDirectoryName(fname);
                string s;
                for(int i=0;i<17;i++)
                    s = rd.ReadLine();
                 s = rd.ReadLine();//bỏ dong hướng dẫn
                //Đọc tên file dữ liệu
                _fName = rd.ReadLine();
                //Đọc số thuộc tính
                s = rd.ReadLine();          //Bỏ qua dòng chú thích
                s = rd.ReadLine();
                _noAttribute = byte.Parse(s);
                //Đọc số lớp kết luận
                s = rd.ReadLine();          //Bỏ qua dòng chú thích
                s = rd.ReadLine();
                _noConseqClass = byte.Parse(s);
                //Số mẫu dữ liệu
                s = rd.ReadLine();          //Bỏ qua dòng chú thích
                s = rd.ReadLine();
                _noPatterns = int.Parse(s);
                //Số luật cần chon
                s = rd.ReadLine();          //Bỏ qua dòng chú thích
                s = rd.ReadLine();
                _noSelectedRules = int.Parse(s);
                //Đọc phương pháp thử nghiệm 
                s = rd.ReadLine();          //Bỏ qua dòng chú thích
                s = rd.ReadLine();
                int n = Convert.ToInt16(s);
                if (n == 1)
                    _methodTest = MethodTestType.LiveOne;
                else
                    if (n == 10)
                        _methodTest = MethodTestType.TenFolder;
                    else
                        if (n == 50)
                            _methodTest = MethodTestType.FiftyFolder;
                        else
                            _methodTest = MethodTestType.All;               
                //Đọc phương pháp lập luận
                s = rd.ReadLine();          //Bỏ qua dòng chú thích
                s = rd.ReadLine();
                n = Convert.ToInt16(s);
                if (n == 1)
                    _resionMethod = ResionMethodType.SingleWiner;
                else
                    _resionMethod = ResionMethodType.Voted;
                //Đọc ham thich nghi
                s = rd.ReadLine();          //Bỏ qua dòng chú thích
                s = rd.ReadLine();
                n = Convert.ToInt16(s);
                if (n == 8)
                    _fitnessFunctionType = SGERDFitnessFuntion.FF8;
                else
                    if (n == 10)
                        _fitnessFunctionType = SGERDFitnessFuntion.FF10;
                    else
                        if (n == 13)
                            _fitnessFunctionType = SGERDFitnessFuntion.FF13;
                        else
                            _fitnessFunctionType = SGERDFitnessFuntion.FF17;
               //Đoc các tham số đại số gia tử
                _fmc.Clear();
                s = rd.ReadLine();          //Bỏ qua dòng chú thích
                s = rd.ReadLine();
                string[] G = s.Split(new char[] { ' ' });
                for (int j = 0; j < G.Length; j++)
                    _fmc.Add(float.Parse(G[j]));

                _muyL.Clear();
                s = rd.ReadLine();          //Bỏ qua dòng chú thích
                s = rd.ReadLine();
                G = s.Split(new char[] { ' ' });
                for (int j = 0; j < G.Length; j++)
                    _muyL.Add(float.Parse(G[j]));

                s = rd.ReadLine();          //Bỏ qua dòng chú thích
                s = rd.ReadLine();
                G = s.Split(new char[] { ' ' });
                for (int j = 0; j < G.Length; j++)
                    _kj.Add(byte.Parse(G[j]));
                rd.Close();
                
            }
            catch (IOException ex)
            {
                throw ex;
            } 
 
        }
        public void LoadParametersForExperiment(string fname)
        {
            try
            {
                StreamReader rd = new StreamReader(fname);
                _filepath = Path.GetDirectoryName(fname);
                string s;               
                s = rd.ReadLine();//bỏ dong hướng dẫn
                //Đọc tên file dữ liệu
                _fName = rd.ReadLine();
                //Đọc số thuộc tính
                s = rd.ReadLine();          //Bỏ qua dòng chú thích
                s = rd.ReadLine();
                _noAttribute = byte.Parse(s);
                //Đọc số lớp kết luận
                s = rd.ReadLine();          //Bỏ qua dòng chú thích
                s = rd.ReadLine();
                _noConseqClass = byte.Parse(s);
                //Số mẫu dữ liệu
                s = rd.ReadLine();          //Bỏ qua dòng chú thích
                s = rd.ReadLine();
                _noPatterns = int.Parse(s);
                //Số luật cần chon
                s = rd.ReadLine();          //Bỏ qua dòng chú thích
                s = rd.ReadLine();
                _noSelectedRules = int.Parse(s);
                //Đọc phương pháp thử nghiệm 
                s = rd.ReadLine();          //Bỏ qua dòng chú thích
                s = rd.ReadLine();
                int n = Convert.ToInt16(s);
                if (n == 1)
                    _methodTest = MethodTestType.LiveOne;
                else
                    if (n == 10)
                        _methodTest = MethodTestType.TenFolder;
                    else
                        if (n == 50)
                            _methodTest = MethodTestType.FiftyFolder;
                        else
                            _methodTest = MethodTestType.All;
                //Đọc phương pháp lập luận
                s = rd.ReadLine();          //Bỏ qua dòng chú thích
                s = rd.ReadLine();
                n = Convert.ToInt16(s);
                if (n == 1)
                    _resionMethod = ResionMethodType.SingleWiner;
                else
                    _resionMethod = ResionMethodType.Voted;
                //Đọc ham thich nghi
                s = rd.ReadLine();          //Bỏ qua dòng chú thích
                s = rd.ReadLine();
                n = Convert.ToInt16(s);
                if (n == 8)
                    _fitnessFunctionType = SGERDFitnessFuntion.FF8;
                else
                    if (n == 10)
                        _fitnessFunctionType = SGERDFitnessFuntion.FF10;
                    else
                        if (n == 13)
                            _fitnessFunctionType = SGERDFitnessFuntion.FF13;
                        else
                            _fitnessFunctionType = SGERDFitnessFuntion.FF17;
                //Đoc các tham số đại số gia tử
                _fmc.Clear();
                s = rd.ReadLine();          //Bỏ qua dòng chú thích
                s = rd.ReadLine();
                string[] G = s.Split(new char[] { ' ' });
                for (int j = 0; j < G.Length; j++)
                    _fmc.Add(float.Parse(G[j]));

                _muyL.Clear();
                s = rd.ReadLine();          //Bỏ qua dòng chú thích
                s = rd.ReadLine();
                G = s.Split(new char[] { ' ' });
                for (int j = 0; j < G.Length; j++)
                    _muyL.Add(float.Parse(G[j]));

                s = rd.ReadLine();          //Bỏ qua dòng chú thích
                s = rd.ReadLine();
                G = s.Split(new char[] { ' ' });
                for (int j = 0; j < G.Length; j++)
                    _kj.Add(byte.Parse(G[j]));
                rd.Close();

            }
            catch (IOException ex)
            {
                throw ex;
            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="fname"></param>
        public void Save(string fname)
        {

        }
    }
}
