﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using PhD.FRSData;
using PhD.HA;
using PhD.Common;
namespace PhD.HASGERD
{
    public class SGERDRule
    {
        private List<byte> _left;   //Giá trị _left[i]= BFRConstant.Dontcare có nghĩa là don'tcare
        //Giá trị _left[i] != -1 có nghĩa là chỉ số của hạng từ trong hệ khoảng tính mờ ứng với thuộc tính thứ i
        private byte _conseqClass;   //Lớp kết luận được đánh số từ 0 cho đến hết         
        private float _support;     //Độ hỗ trợ của luật
        private float _confident;   //Độ tin cậy
        private float _weight;      //Trọng số  
        private bool _selected;     //= true luật này được chọn, = false  không được chọn
        private byte _length;        //Chiều dài luật
        private byte _noAttribute;  //So thuoc tinh
        private float _fitness;      //Giá trị thích nghi của luật cho thuật toán SGERD
        private List<HASFISystem> _listHASFIS;
       /// <summary>
       /// Giá trị lớp kết luận
       /// </summary>
        public byte ConseqClass
        {
            get { return _conseqClass; }
            set { _conseqClass = value; }
        }     
        /// <summary>
        /// Độ hỗ trợ của luật
        /// </summary>
        public float Support
        {
            get { return _support; }
        }
        /// <summary>
        /// Độ tin cậy của luật
        /// </summary>
        public float Confident
        {
            get { return _confident; }
        }
        public float Weight
        {
            get { return _weight; }
        }
        /// <summary>
        /// Lấy chỉ số của hạng từ trong hệ khoảng tính mờ của thuộc tính có thứ index
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public byte this[int index]
        {
            get { return _left[index]; }
            set { _left[index] = value; }
        }
        public bool Selected
        {
            get { return _selected; }
            set { _selected = value; }
        }
        public byte Length
        {
            get
            {
                return _length;
            }
            set
            {
                _length = value;
            }
        }
        public byte AttibuteCount
        {
            get
            {
                return _noAttribute;
            }
            set
            {
                _noAttribute = value;
            }
        }
        public float Fitness
        {
            get { return _fitness; }
        }
        public SGERDRule(SGERDRule r)
        {
            _left = new List<byte>();
            _noAttribute = r.AttibuteCount;
            _length = r.Length;
            _selected = r.Selected;
            _listHASFIS = r._listHASFIS;
            _noAttribute = r._noAttribute;
            for (int i = 0; i < r._noAttribute; i++)
                _left.Add(r[i]);            
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="noAttribute"></param>
        public SGERDRule(byte noAttribute, List<HASFISystem> listHASFIS)
        {
            _left = new List<byte>();
            for (int i = 0; i < noAttribute; i++)
                _left.Add(DontCare.Value);
            _selected = false;
            _length = 0;
            _noAttribute = noAttribute;
            _listHASFIS = listHASFIS;
        }
        public bool EqualLeft(SGERDRule rule)
        {
            if (_length != rule.Length)
                return false;
            for (int i = 0; i < _left.Count; i++)
                if (_left[i] != rule[i])
                    return false;
            return true;
        }
        public bool Equals(SGERDRule rule)
        {
            if (_length != rule.Length)
                return false;           
            if (_conseqClass != rule.ConseqClass)
                return false;
            for (int i = 0; i < _left.Count; i++)
                if (_left[i] != rule[i])
                    return false;            
            return true;
        }
        /// <summary>
        /// Hàm xác định độ phù hợp của luật với mẫu dữ liệu 
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        public float MuyAq(FRSRow row)
        {
            float muy = 1;
            for (int i = 0; i < _left.Count; i++)
                if (_left[i] != DontCare.Value )
                    muy *= _listHASFIS[i][_left[i]].Membership(row[i]);  
            return muy;
        }
        /// <summary>
        /// Hàm xác định lớp kết luận của luật
        /// </summary>
        /// <param name="table"></param>
        /// <param name="folderIdx">Chi so cua folder kiem tra</param>
        public void DetermineConseqClass(FRSDatatable table)
        {
            int idx = -1;
            float maxMuyAq = float.MinValue;
            float muy;        
            for (int i = 0; i < table.RowsCount; i++)
            {
                if (table.Rows(i).IsTesting)            //Nếu thuộc tập training
                {
                    muy = MuyAq(table.Rows(i));
                    if (maxMuyAq < muy)
                    {
                        maxMuyAq = muy;
                        idx = i;
                    }
                }
            }
            if (idx >= 0 && idx < table.RowsCount)
                _conseqClass = table.Rows(idx).ConseqClass;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="table"></param>
        /// <returns></returns>
        public void ComputingConfAndSupp(FRSDatatable table)
        {            
            float sum1=0, sum2=0;
            float t;                       
                 
            for(int i=0; i<table.RowsCount; i++)
            {
                if (table.Rows(i).IsTesting)            //Nếu thuộc tập training
                {
                    t = MuyAq(table.Rows(i));
                    if (table.Rows(i).ConseqClass == _conseqClass)
                        sum1 = sum1 + t;
                    sum2 = sum2 + t;
                }
            }
            int noRowTraining;
            if (table.RowsCount == table.NoTestingRows)
                noRowTraining = table.RowsCount;
            else
                noRowTraining = table.RowsCount - table.NoTestingRows;
            _support = sum1/noRowTraining;
            if (sum2!=0)
                _confident = sum1 / sum2;
            else
                _confident = 0;          
        }
        #region Computing Fitness function SSGERD
        public void ComputingFitness(SGERDFitnessFuntion fitnessType,FRSDatatable table)
        {
            ComputingConfAndSupp(table);
            _weight = _confident;
            if (fitnessType == SGERDFitnessFuntion.FF8)
                Fitness8(table);
            if (fitnessType == SGERDFitnessFuntion.FF10)
                Fitness10(table);
            if (fitnessType == SGERDFitnessFuntion.FF13)
                Fitness13(table);
            if (fitnessType == SGERDFitnessFuntion.FF17)
                Fitness17(table);
        }
        private void Fitness8(FRSDatatable table)
        {
          
            _fitness = _confident * _support;
            
        }
        private void Fitness10(FRSDatatable table)
        {
            float sumpos = 0, sumneg = 0;
            float t;
            for (int i = 0; i < table.RowsCount; i++)
            {
                if (table.Rows(i).IsTesting)            //Nếu thuộc tập training
                {
                    t = MuyAq(table.Rows(i));
                    if (table.Rows(i).ConseqClass == _conseqClass)
                        sumpos = sumpos + t;
                    else
                        sumneg = sumneg + t;
                }
            }
            _fitness = sumpos - sumneg;
        }
        private void Fitness13(FRSDatatable table)
        {
            float Toj = Convert.ToSingle(Math.Pow(0.5,_length));
            float sumpos = 0, sumneg = 0;
            float t;
            int gama = 0;
            for (int i = 0; i < table.RowsCount; i++)
            {
                if (table.Rows(i).IsTesting)            //Nếu thuộc tập training
                {
                    t = MuyAq(table.Rows(i));
                    if (table.Rows(i).ConseqClass == _conseqClass)
                        sumpos = sumpos + t;
                    else
                        sumneg = sumneg + t;
                    if (t > Toj)
                        gama++;
                }
            }
            _fitness = sumpos - sumneg - gama*(1-Toj);
        }
        private void Fitness17(FRSDatatable table)
        {

        }
        #endregion

    }
}
