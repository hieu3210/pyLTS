﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PhD.HA;
using PhD.FRSData;
using PhD.Common;
namespace PhD.HASGERD
{
    public class HASGERD
    {
        private SGERDRulesSystem _initRules;
        private SGERDRulesSystem _parentRules;
        private SGERDRulesSystem _childRules;
        private SGERDRulesSystem _auxiRules;      
        private List<HASFISystem> _listhaSFI;      
        private SGERDParameter _param;
        private FRSDatatable _table;
        private float _aveLengthOfRules;
        public float AveLengthOfRules
        {
            get { return _aveLengthOfRules; }
        }
        public HASGERD(SGERDParameter param)
        {
            _param = param;
            _initRules = new SGERDRulesSystem(_param);
            _listhaSFI = new List<HASFISystem>();
            _initRules = new SGERDRulesSystem(_param);
            _parentRules = new SGERDRulesSystem(_param);
            _auxiRules = new SGERDRulesSystem(_param);
            _childRules = new SGERDRulesSystem(_param);
           
        }

        private void InitPop()
        {
            _initRules.Rules.Clear();
            _parentRules.Rules.Clear();
            _auxiRules.Rules.Clear();
            _childRules.Rules.Clear();
            for (int i = 0; i < _param.NoAttribute; i++)
            {
                for (byte j = 0; j < _listhaSFI[i].Count; j++)
                {
                    SGERDRule r = new SGERDRule(_param.NoAttribute, _listhaSFI);
                    r[i] =j;
                    r.Length = 1;
                    r.DetermineConseqClass(_table);
                    r.ComputingFitness(_param.FitnessFunctionType, _table);
                    _initRules.Rules.Add(r);
                } 
            }
           
        }
        /// <summary>
        /// /
        /// </summary>
        /// <param name="rj"></param>
        /// <param name="rp"></param>
        /// <param name="mutation"></param>
        /// <returns></returns>
        private int Crossover(SGERDRule rj , SGERDRule rp, int mutation)
        {
	        int npos=0;
            byte i, kt=0;
            int idx=0;
            if(mutation==0)
            {                
                for(i=0;i<_param.NoAttribute;i++)
                    if(rp[i] != DontCare.Value) npos++;		//Xac dinh so bien active cua luat rp
                int sidx = MyRandom.RandomN(npos);
                //Xac dinh vi tri lai ghep).              
                for(i = 0;i< _param.NoAttribute;i++)
                {
                    if(idx==sidx)
                    {
                        idx=i;
                        break;
                    }
                    idx++;
                }
            }
            else
            {
                for( i = 0; i <_param.NoAttribute;i++)
                    if(rp[i]!= DontCare.Value)
                    { 
                        idx=i;
                        break;
                    }
            }
            if(rj[idx]==DontCare.Value)//vi tri nay bien chua active thi tao ra con neu da active thi khong tao con 
            {
                for(i = 0; i< _listhaSFI[idx].Count; i++) //Lan luot thay the bien bang 1 trong cac gia tri L1,..L14
                {
                    SGERDRule newR = new SGERDRule(rj);
                    newR[idx]= i ;
                    newR.DetermineConseqClass(_table);
                    newR.ComputingFitness(_param.FitnessFunctionType, _table);
                    newR.Length++;
                    if(newR.Fitness>rj.Fitness)
                    {
                        _childRules.Rules.Add(newR);
                        kt = 1;
                    }
                }
            }
            return kt;
        }   
        /// <summary>
        /// Ham tao sinh quan the
        /// </summary>
        /// <returns></returns>
        private int ReProduction()
        {
            int i;
            int idxRule;
	        int hasNextGeneration = 0;
            int m, n;

            _childRules.Rules.Clear();
	        for(i=0;i<_parentRules.Rules.Count;i++)
	        {
                //idxRule = MyRandom.RandomN(_parentRules.Rules.Count-1);
                _parentRules.DetermineIndexOfClass(_parentRules.Rules[i].ConseqClass, out m, out n);
                idxRule = MyRandom.RandomMtoN(m, n);
                if(idxRule != i) //crossover
                {
                    hasNextGeneration += Crossover(_parentRules.Rules[i], _parentRules.Rules[idxRule], 0);
                }
                else //mutation
                {
                    idxRule = MyRandom.RandomN(_auxiRules.Rules.Count); //mutation
                    hasNextGeneration += Crossover(_parentRules.Rules[i], _auxiRules.Rules[idxRule],1);
                }
	        }
	        //Nap quan the con vao quan the cha
	        for( i=0; i<_childRules.Rules.Count; i++)
	        {
		      _parentRules.Rules.Add(_childRules.Rules[i]);
			     
	        }	
	        if(hasNextGeneration>0)
		        return 1;
	        else
		        return 0;
        }
        /// <summary>
        /// Thực hiện thử nghiệm xây dựng hệ luật và kiểm tra 
        /// </summary>
        /// <returns></returns>
        public float Experiment()
        {
	        //Buoc 1 khoi tao quan the, xac dinh lop ket luan va do thich nghi
	        int kt, generation = 0;
            for (byte i = 0; i < _param.NoAttribute; i++)
            {
                HedgeAlgebras ha = new HedgeAlgebras(_param.FmC[i], _param.MuyL[i]);
                _listhaSFI.Add(new HASFISystem(ha,_param.KJ[i]));
                _listhaSFI[i].CreateSFISystem();
                // _listhaSFI[i].WriteHASFISystem(FilePathExperiment.FilePath+"HAparam.txt");
            }
            _table = new FRSDatatable(_param.Filepath + "\\" + _param.FileName, _param.MethodTest, _param.NoAttribute, _param.NoConseqClass);
            _table.LoadData();
            float total = 0;
            float totalLength = 0;
           
            for (int j = 0; j < 5; j++)
            {
                _table.CreateFolder();
                for (int i = 0; i < _table.FolderCount; i++)
                {
                    _table.SetFolderTest(i);               
                    InitPop();
                    _initRules.SortOnClassAndFitness();
                    _initRules.WriteToFile(_param.Filepath+"\\Rules\\_init.rul");
                    _parentRules = _initRules.GetBestRules();
                    _parentRules.WriteToFile(_param.Filepath + "\\Rules\\_parent.rul");
                    _auxiRules = _initRules.GetBestRules();
                    _initRules.Rules.Clear();
                    generation = 1;                   
                    do
                    {
                        kt = ReProduction();
                        if (kt != 0)
                        {
                            _parentRules.SortOnClassAndFitness();
                            _initRules = _parentRules;
                            _parentRules = _initRules.GetBestRules();
                            _parentRules.WriteToFile(_param.Filepath + "\\Rules\\_parent_" + i.ToString() + "_" + generation.ToString() + ".rul");
                            _initRules.Rules.Clear();
                        }
                        //Buoc 5 Lap lai buoc 2
                        generation++;
                    } while ((kt == 1) && generation <= _param.NoAttribute);
                    total += Classification(i);
                    totalLength += _parentRules.AverageLengthOfRules;
                }
            }
            _aveLengthOfRules = totalLength /(5* _table.FolderCount);
            return total /(5*_table.FolderCount)*100;
        }

        private float Classification(int folderIdx)
        {
            List<int> folder = _table.Folder(folderIdx);
	        float perf = 0;
            for (int i = 0; i <folder.Count; i++)
            {
                if (_parentRules.Resioning(folder[i], _table) == _table.Rows(folder[i]).ConseqClass)
                    perf++;                                
            }
            return perf/folder.Count;
        }
        
    }
}
