﻿//Lớp mô tả hệ khoảng tính mờ tương tự mức k
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
namespace PhD.HA
{
   public class HASFISystem
   {
       private byte _k;
       private List<List<Term>> _list_K_Terms;  //Danh sách các hạng từ có độ dài mức k
       private List<List<Term>> _list_K2_Terms; //Danh sách các hạng từ có độ dài mức k+
       private List<List<HASFI>> _listHASFIS;   ////Danh sách các khoảng tính mờ tương tự mức k
       private HedgeAlgebras _ha;

       public byte K_Level
       {
           get { return _k; }
           set 
           {
               _k = value;             
           }
       }
       
       public List<HASFI> this[int index]
       {
           get
           {
               try
               {
                   return _listHASFIS[index];
               }
               catch (IndexOutOfRangeException ex)
               {
                   throw ex;
               }
           }
       }
       public int Count
       {
           get { return Convert.ToInt32(_listHASFIS.Count); }
       }
       #region Constructor
       public HASFISystem(HedgeAlgebras ha, byte k)
       {
           try
           {
               _k = k;
               _ha = ha;
               _list_K_Terms = new List<List<Term>>();
               _list_K2_Terms = new List<List<Term>>();
               _listHASFIS = new List<List<HASFI>>();
           }
           catch (AccessViolationException Ex)
           {
               throw Ex;
           }
       }
       #endregion

        /// <summary>
        /// Hàm tạo ra các hạng từ mức K
        /// </summary>
        /// <returns></returns>
        private void CreateTermsAtK() 
        {
            List<Term> temp1 = new List<Term>();
            List<Term> temp2 = new List<Term>();
            Term t;
            string x1, x2;
            int i, j;

            //Khởi tạo các khoảng tính mờ mức 1
            if (_list_K_Terms == null)
                _list_K_Terms = new List<List<Term>>();
            _list_K_Terms.Clear();
            if (_list_K2_Terms == null)
                _list_K2_Terms = new List<List<Term>>();
            _list_K2_Terms.Clear();

            t = new Term(TermConstans.C_minus, _ha.Vx(TermConstans.C_minus), _ha.FMC_Minus);
            temp1.Add(t);
            t = new Term(TermConstans.W, _ha.FMC_Minus, 0);
            temp1.Add(t);
            t = new Term(TermConstans.C_plus, _ha.Vx(TermConstans.C_plus), _ha.FMC_Plus);
            temp1.Add(t);
            List<Term> tem1 = new List<Term>();
            List<Term> tem2 = new List<Term>();
            for (int jj = 0; jj < temp1.Count; jj++)
            {
                tem1.Add(temp1[jj]);
                tem2.Add(temp1[jj]);
            }
            _list_K_Terms.Add(tem1);
            _list_K2_Terms.Add(tem2);

            //Xác định các hạng tử có độ dài  >=2)
            for (i = 2; i <= _k + 2; i++)
            {
                temp2.Clear();
                for (j = 0; j < temp1.Count; j++)
                {
                    if (temp1[j].WordX.Length < i - 1 || temp1[j].WordX.Substring(0, 1).Equals(TermConstans.W))
                    {
                        temp2.Add(temp1[j]);
                    }
                    else
                    {
                        temp2.Add(temp1[j]);
                        x1 = temp1[j].WordX + Hedge.Very;
                        x2 = temp1[j].WordX + Hedge.Little;
                        Term t1 = new Term(x1, _ha.Vx(x1), _ha.Muy_Very * temp1[j].fmx);
                        Term t2 = new Term(x2, _ha.Vx(x2), _ha.Muy_Litte * temp1[j].fmx);
                        temp2.Add(t1); //V
                        temp2.Add(t2); //L
                    }
                }
                for (int ii = 0; ii < temp2.Count - 1; ii++)
                    for (int jj = ii + 1; jj < temp2.Count; jj++)
                        if (temp2[ii].Vx > temp2[jj].Vx)
                        {
                            t = temp2[ii];
                            temp2[ii] = temp2[jj];
                            temp2[jj] = t;
                        }

                temp1.Clear();
                List<Term> tmp1 = new List<Term>();
                List<Term> tmp2 = new List<Term>();
                for (j = 0; j < temp2.Count; j++)
                {
                    temp1.Add(temp2[j]);
                    tmp1.Add(temp2[j]);
                    if (temp2[j].WordX.Length == i && !temp1[j].WordX.Substring(0, 1).Equals(TermConstans.W))
                        tmp2.Add(temp2[j]);
                }

                if (i <= _k) _list_K_Terms.Add(tmp1);
                _list_K2_Terms.Add(tmp2);
            }

            for (i = 0; i < _k; i++)
            {
                t = new Term(TermConstans.ZERO, 0, 0);
                _list_K_Terms[i].Insert(0, t);
            }
            for (i = 0; i < _k; i++)
            {
                t = new Term(TermConstans.UNIT, 1, 0);
                _list_K_Terms[i].Add(t);
            }

        }

       /// <summary>
       /// 
       /// </summary>
       public void CreateSFISystem()
       {

           CreateTermsAtK();
           _listHASFIS.Clear();
           float left = 0.0f, right = 0.0f;
           int lenx, l = 0, r = 0;

           for (int kk = 0; kk < _k; kk++)
           {
               left = _list_K2_Terms[kk + 2][0].fmx;
               right = left;
               List<HASFI> _listHASFISTemp = new List<HASFI>();
               for (int i = 0; i < _list_K_Terms[kk].Count; i++)
               {
                   lenx = _list_K_Terms[kk][i].WordX.Length;

                   if (i == 0)
                   {
                       HASFI sfi = new HASFI(0.0f, _list_K2_Terms[_k + 1][0].fmx, 0.0f, _list_K_Terms[kk][1].Vx, (kk + 1).ToString() + "_" + _list_K_Terms[kk][i].WordX, _list_K_Terms[kk][i].Vx);
                       _listHASFISTemp.Add(sfi);
                   }
                   else
                       if (i == _list_K_Terms[kk].Count - 1)
                       {
                           HASFI sfi = new HASFI(1.0f - _list_K2_Terms[_k + 1][_list_K2_Terms[_k + 1].Count - 1].fmx, 1.0f, _list_K_Terms[kk][i - 1].Vx, 1.0f, (kk + 1).ToString() + "_" + _list_K_Terms[kk][i].WordX, 1.0f);
                           _listHASFISTemp.Add(sfi);
                       }
                       else
                       {
                           HASFI sfi;
                           left = right;
                           right = left + _list_K2_Terms[kk + 2][2 * i - 1].fmx + _list_K2_Terms[kk + 2][2 * i].fmx;

                           string ss = _list_K_Terms[kk][i].WordX;
                           if (lenx == kk + 1)
                           {

                               if (lenx > 1)
                               {
                                   int j;
                                   //Tim hang tu co do dai lenx
                                   for (j = i + 1; j < _list_K_Terms[kk].Count - 1; j++)
                                   {
                                       if (_list_K_Terms[kk][j].WordX.Length == lenx)
                                       {
                                           r = j;
                                           break;
                                       }
                                   }
                                   if (j >= _list_K_Terms[kk].Count - 1) r = _list_K_Terms[kk].Count - 1;
                                   for (j = i - 1; j > 0; j--)
                                   {
                                       if (_list_K_Terms[kk][j].WordX.Length == lenx)
                                       {
                                           l = j;
                                           break;
                                       }
                                   }
                                   if (j <= 0) l = 0;
                               }
                               else
                               {
                                   l = i - 1;
                                   r = i + 1;
                               }
                               sfi = new HASFI(left, right, _list_K_Terms[kk][l].Vx, _list_K_Terms[kk][r].Vx, _list_K_Terms[kk][i].WordX, _list_K_Terms[kk][i].Vx);
                               _listHASFISTemp.Add(sfi);
                           }
                           else
                           {
                               int j = kk - 1;
                               while (j >= 0)
                               {
                                   for (int jj = 1; jj < _listHASFIS[j].Count - 1; jj++)
                                   {
                                       if (_listHASFIS[j][jj].Term.WordX.Equals(ss))
                                       {
                                           _listHASFIS[j][jj].Left = left;
                                           _listHASFIS[j][jj].Right = right;
                                           break;
                                       }
                                   }
                                   j--;
                               }
                           }
                       }
               }
               _listHASFIS.Add(_listHASFISTemp);
           }
       }

       public void WriteTermstoFile(string filename)
        {
            StreamWriter fwriter = new StreamWriter(filename);
            for (int i = 0; i < _list_K_Terms[_k - 1].Count; i++)
            {
                fwriter.Write(_list_K_Terms[_k - 1][i].WordX);
                fwriter.WriteLine("\t" + _list_K_Terms[_k - 1][i].fmx);
            }
            fwriter.Close();
        }
       public void WriteHASFISystem(string filename)
       {
           StreamWriter fwriter = new StreamWriter(filename, true);
           for (int i = 0; i < _listHASFIS[_k - 1].Count; i++)
           {
               fwriter.WriteLine("<" + _listHASFIS[_k - 1][i].VxLeft.ToString() + "\t<" + _listHASFIS[_k - 1][i].Left.ToString() + "\t<" + _listHASFIS[_k - 1][i].Term.Vx.ToString() + "~" + Revert(_listHASFIS[_k - 1][i].Term.WordX) + ">\t" + _listHASFIS[_k - 1][i].Right.ToString() + ">\t" + _listHASFIS[_k - 1][i].VxRight.ToString() + ">");
           }
           fwriter.Close();
       }
       private string Revert(string s)
       {
           string w="";
           for (int i = s.Length - 1; i >= 0; i--)
               w = w + s[i];
           return w;
       }


   }
}
