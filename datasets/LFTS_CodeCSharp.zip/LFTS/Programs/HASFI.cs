﻿//Lớp biểu diễn khoảng tính mờ của một giá trị ngôn ngữ ở mức k
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PhD.HA
{
    public class HASFI  //Similar Fuzzy Interval khoảng tính mờ tương tự
    {
        #region fields
        private float _left;  //Cận dưới của khoảng tính mờ tương tự
        private float _right; //Cận trên của khoảng tính mờ tương tự
        private float _VxLeft; //Cận dưới của khoảng tính mờ
        private float _VxRight; //Cận trên của khoảng tính mờ 
        private Term _term;     //Hạng từ    
        
        
        #endregion
        #region Properties
        /// <summary>
        /// Cận phải của khoảng tính mờ tương tự
        /// </summary>
        public float Right
        {
            get
            {
                return _right;
            }
            set
            {
                if (value < _left)
                    _right = _left;
                else
                    _right = value;
            }
        }
        /// <summary>
        /// Cận trái của khoảng tính mờ tương tự
        /// </summary>
        public float Left
        {
            get
            {
                return _left;
            }
            set
            {
                if (value < _right)
                    _left = value;
                else
                    _left = _right;
            }
        }
        /// <summary>
        /// Giá trị định lượng ngữ nghĩa của từ bên phải
        /// </summary>
        public float VxRight
        {
            get { return _VxRight; }
            set { _VxRight = value; }
        }
        /// <summary>
        /// Giá trị định lượng ngữ nghĩa của từ bên phải
        /// </summary>
        public float VxLeft
        {
            get { return _VxLeft; }
            set { _VxLeft = value; }
        }
       
        public Term Term
        {
            get { return _term; }
            set { _term = value; }
        }
        #endregion
        #region Methods
        public HASFI()
        {
            _left = 0.0f;
            _right = 1.0f;
            _VxLeft = 0.0f;
            _VxRight = 0.0f;
            _term = new Term();
            _term.Vx = 0.0f;
            _term.WordX = "";
        }
        public HASFI(float left, float right, float vxleft, float vxright, string wordX, float vx)
        {
            _left = left;
            _right = right;
            _VxLeft = vxleft;
            _VxRight = vxright;
            _term = new Term();
            _term.Vx = vx;
            _term.WordX = wordX;
        }
        /// <summary>
        /// Hàm thuộc dạng tam giác
        /// </summary>
        /// <param name="vx1"> giá trị định lượng của từ đứng trước</param>
        /// <param name="vx">giá trị định lượng của từ x</param>
        /// <param name="vx2">giá định lượng của từ </param>
        /// <param name="idxJx"></param>
        /// <param name="maxIdxJx"></param>
        /// <returns></returns>
        /// 
        public float Membership(float x)
        {
            if (x < _VxLeft || _VxRight < x)
                return 0.0f;

            /*if (_VxLeft == _VxRight)
            {
                if (x == _VxLeft) return 1.0f;
                else return 0.0f;
            }*/

            if (x <= _term.Vx)
            {
                if (_term.Vx == _VxLeft) return 1.0f;
                else return (x - _VxLeft) / (_term.Vx - _VxLeft);
            }
            else
            {
                if (_term.Vx == _VxRight) return 1.0f;
                else return (_VxRight - x) / (_VxRight - _term.Vx);
            }
        }

        /*public float Membership(float x)
        {
            if (x < _VxLeft || _VxRight < x)
                return 0.0f;
            if(x==0.0f || x==1.0f) return x;
            float zero = 0.0f;
            float tg1 = (_term.Vx - _VxLeft);
            if (tg1 != 0.0f)
                tg1 = zero + (x - _VxLeft)* (1.0f - zero) / tg1;
            else 
                tg1 = 1.0f;
            float tg2 = (_VxRight - _term.Vx);
            if (tg2 != 0.0f)
                //tg2 = 1.0f - (x - _term.Vx) * (1.0f - zero) / tg2;
                tg2 = zero + (_VxRight - x) * (1.0f - zero) / tg2;
            else 
                tg2 = 1.0f;
           return  MAX(0, MIN(MAX(tg1, zero), MAX(tg2, zero)));
            
        }*/

        private float MAX(float a, float b)
        {
            return a > b ? a : b;
        }
        private float MIN(float a, float b)
        {
            return a < b ? a : b;
        }
    } 
}

#endregion

