﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PhD.HA
{
    public static class TermConstans
    {
        public static string ZERO = "0";
        public static string C_minus = "-";
        public static string C_plus = "+";
        public static string W = "W";
        public static string UNIT = "1";
    }
    public static class ConstanChars
    {
        public static char ZERO = '0';
        public static char C_minus = '-';
        public static char C_plus = '+';
        public static char W = 'W';
        public static char UNIT = '1';
        public static char Very = 'V';
        public static char Little = 'L';

    }
    public static class Hedge
    {
        public static string Very = "V";
        public static string Little = "L";
    }
}
