﻿//Lớp mô tả hệ khoảng tính mờ tương tự mức k
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using PhD.Common;

namespace PhD.HA
{
    public class HASingleSFISystem
    {
        private byte _k;
        private List<Term> _list_K_Terms;  //Danh sách các hạng từ có độ dài mức k
        private List<Term> _list_K2_Terms; //Danh sách các hạng từ có độ dài mức k+
        private List<HASFI> _listHASFIS;   ////Danh sách các khoảng tính mờ tương tự mức k
        private HedgeAlgebras _ha;

        public byte K_Level
        {
            get { return _k; }
            set
            {
                _k = value;
            }
        }
        public HASFI this[int index]
        {
            get
            {
                try
                {
                    return _listHASFIS[index];
                }
                catch (IndexOutOfRangeException ex)
                {
                    throw ex;
                }
            }
        }
        public int Count
        {
            get { return Convert.ToInt32(_listHASFIS.Count); }
        }
        #region Constructor
        public HASingleSFISystem(HedgeAlgebras ha, byte k)
        {
            try
            {
                _k = k;
                _ha = ha;
                _list_K_Terms = new List<Term>();
                _list_K2_Terms = new List<Term>();
                _listHASFIS = new List<HASFI>();
            }
            catch (AccessViolationException Ex)
            {
                throw Ex;
            }
        }
        #endregion
        //Ham thuc hien sap xep cac tu da duoc sinh trong J theo thu tu dinh luong ngu nghia
        private void Sort_listTermsAtK()
        {
            Term x;
            int i, j;
            for (i = 0; i < _list_K_Terms.Count - 1; i++)
                for (j = i + 1; j < _list_K_Terms.Count(); j++)
                    if (_list_K_Terms[i].Vx > _list_K_Terms[j].Vx)
                    {
                        x = _list_K_Terms[i];
                        _list_K_Terms[i] = _list_K_Terms[j];
                        _list_K_Terms[j] = x;
                    }
        }

        /// <summary>
        /// Hàm tạo ra các hạng từ mức K
        /// </summary>
        /// <returns></returns>
        private void CreateTermsAtK()
        {
            List<Term> temp1 = new List<Term>();
            List<Term> temp2 = new List<Term>();
            Term t;
            //Khởi tạo các khoảng tính mờ mức 1
            if (_list_K_Terms == null)
                _list_K_Terms = new List<Term>();
            _list_K_Terms.Clear();
            if (_list_K2_Terms == null)
                _list_K2_Terms = new List<Term>();
            _list_K2_Terms.Clear();

            t = new Term(TermConstans.C_minus, _ha.Vx(TermConstans.C_minus), _ha.FMC_Minus);
            _list_K_Terms.Add(t);
            t = new Term(TermConstans.C_plus, _ha.Vx(TermConstans.C_plus), _ha.FMC_Plus);
            _list_K_Terms.Add(t);
            //Xác định các hạng tử có độ dài  >=2)
            string x1, x2;
            int i, j;
            for (i = 0; i < _list_K_Terms.Count; i++)
            {
                temp1.Add(_list_K_Terms[i]);
                //_list_K2_Terms.Add(_list_K_Terms[i]);
            }
            for (i = 2; i <= _k + 2; i++)
            {
                temp2.Clear();
                for (j = 0; j < temp1.Count; j++)
                {
                    x1 = temp1[j].WordX + Hedge.Very;
                    x2 = temp1[j].WordX + Hedge.Little;
                    Term t1 = new Term(x1, _ha.Vx(x1), _ha.Muy_Very * temp1[j].fmx);
                    Term t2 = new Term(x2, _ha.Vx(x2), _ha.Muy_Litte * temp1[j].fmx);
                    temp2.Add(t1);
                    temp2.Add(t2);
                    if (i <= _k)
                    {
                        _list_K_Terms.Add(t1);
                        _list_K_Terms.Add(t2);
                    }
                    else if (i == _k + 2)
                    {
                        _list_K2_Terms.Add(t1);
                        _list_K2_Terms.Add(t2);
                    }
                }
                temp1.Clear();
                for (j = 0; j < temp2.Count; j++)
                    temp1.Add(temp2[j]);
            }

            t = new Term(TermConstans.ZERO, 0, 0);
            _list_K_Terms.Add(t);
            t = new Term(TermConstans.W, _ha.FMC_Minus, 0);
            _list_K_Terms.Add(t);
            t = new Term(TermConstans.UNIT, 1, 0);
            _list_K_Terms.Add(t);
            Sort_listTermsAtK();
            Sort_listTermsAtKplus2();
        }
        //Ham thuc hien sap xep cac tu da duoc sinh trong J theo thu tu dinh luong ngu nghia
        private void Sort_listTermsAtKplus2()
        {
            Term x;
            int i, j;
            for (i = 0; i < _list_K2_Terms.Count - 1; i++)
                for (j = i + 1; j < _list_K2_Terms.Count(); j++)
                    if (_list_K2_Terms[i].Vx > _list_K2_Terms[j].Vx)
                    {
                        x = _list_K2_Terms[i];
                        _list_K2_Terms[i] = _list_K2_Terms[j];
                        _list_K2_Terms[j] = x;
                    }
        }

        /// <summary>
        /// 
        /// </summary>
        public void CreateSFISystem()
        {
            CreateTermsAtK();
            _listHASFIS.Clear();
            float left = _list_K2_Terms[0].fmx, right;
            int lenx, l, r;

            right = left;
            for (int i = 0; i < _list_K_Terms.Count; i++)
            {
                lenx = _list_K_Terms[i].WordX.Length;
                if (i == 0)
                {
                    r = i + 1;
                    HASFI sfi = new HASFI(0.0f, right, _list_K_Terms[0].Vx, _list_K_Terms[r].Vx, _list_K_Terms[0].WordX, _list_K_Terms[0].Vx);
                    _listHASFIS.Add(sfi);
                }
                else
                    if (i == _list_K_Terms.Count - 1)
                    {
                        l = i - 1;
                        HASFI sfi = new HASFI(right, 1.0f, _list_K_Terms[l].Vx, _list_K_Terms[i].Vx, _list_K_Terms[i].WordX, _list_K_Terms[i].Vx);
                        _listHASFIS.Add(sfi);
                    }
                    else
                    {
                        /*HASFI sfi;
                        left = right;
                        right = left + _list_K2_Terms[2 * i - 1].fmx + _list_K2_Terms[2 * i].fmx;

                        if (lenx > 1)
                        {
                            l = i - (int)Math.Pow(2, _k - lenx + 1);
                            r = i + (int)Math.Pow(2, _k - lenx + 1);
                        }
                        else
                        {
                            l = i - (int)Math.Pow(2, _k - lenx);
                            r = i + (int)Math.Pow(2, _k - lenx);
                        }
                        if (l < 0) l = 0;
                        if (r > _list_K_Terms.Count - 1) r = _list_K_Terms.Count - 1;
                       sfi = new HASFI(left, right, _list_K_Terms[l].Vx, _list_K_Terms[r].Vx, _list_K_Terms[i].WordX, _list_K_Terms[i].Vx);
                       _listHASFIS.Add(sfi);
                        */

                        HASFI sfi;
                        left = right;
                        right = left + _list_K2_Terms[2 * i - 1].fmx + _list_K2_Terms[2 * i].fmx;

                        if (_k > 1)
                        {
                            l = i - 1; r = i + 1;
                            if (l < 0) l = 0;
                            if (r > _list_K_Terms.Count - 1) r = _list_K_Terms.Count - 1;
                            sfi = new HASFI(left, right, _list_K_Terms[l].Vx, _list_K_Terms[r].Vx, _list_K_Terms[i].WordX, _list_K_Terms[i].Vx);
                        }
                        else
                            sfi = new HASFI(left, right, _list_K_Terms[i - 1].Vx, _list_K_Terms[i + 1].Vx, _list_K_Terms[i].WordX, _list_K_Terms[i].Vx);
                        _listHASFIS.Add(sfi);
                    }
            }
        }

        public void CreateVxR(float lowerBound, float upperBound)
        {
            float iterval = upperBound - lowerBound;

            for (int i = 0; i < _listHASFIS.Count; i++)
            {
                _listHASFIS[i].Term.VxR = lowerBound + iterval * _listHASFIS[i].Term.Vx;
            }
        }

        public List<int> RandomTermSelection(int noTerm)
        {
            List<int> tl = new List<int>();

            if (noTerm >= _listHASFIS.Count)
                for (int i = 0; i < _listHASFIS.Count; i++)
                    tl.Add(i);
            else
            {
                int i = 0;
                while (i < noTerm)
                {
                    int k = MyRandom.RandomMtoN(0, _listHASFIS.Count - 1);
                    int j = 0;
                    while (j < tl.Count)
                    {
                        if (k == tl[j]) break;
                        j++;
                    }
                    if (j >= tl.Count)
                    {
                        tl.Add(k);
                        i++;
                    }
                }
            }

            tl.Sort();

            return tl;
        }

        public List<int> SelectGivenTerms(List<string> termList)
        {
            List<int> tl = new List<int>();
            string rterm = "";

            for (int i = 0; i < termList.Count; i++)
            {
                for (int j = 0; j < _listHASFIS.Count; j++)
                {
                    rterm = Revert(termList[i]);
                    if (rterm.Equals(_listHASFIS[j].Term.WordX))
                    {
                        tl.Add(j);
                        break;
                    }
                }
            }

            return tl;
        }

/*        public List<Term> RandomTermSelection(int noTerm)
        {
            List<Term> tl = new List<Term>();

            if (noTerm >= _listHASFIS.Count)
                for (int i = 0; i < _listHASFIS.Count; i++)
                    tl.Add(_listHASFIS[i].Term);
            else
            {
                int i = 0;
                List<int> selectedTerm = new List<int>();
                while (i < noTerm)
                {
                    int k = MyRandom.RandomMtoN(0, _listHASFIS.Count);
                    int j = 0;
                    while (j < selectedTerm.Count)
                    {
                        if (k == selectedTerm[j]) break;
                        j++;
                    }
                    if (j >= selectedTerm.Count)
                    {
                        selectedTerm.Add(k);
                        tl.Add(_listHASFIS[i].Term);
                    }
                    i++;
                }
            }

            tl = Sort_listTerms(tl);

            return tl;
        }

        private List<Term> Sort_listTerms(List<Term> tl)
        {
            Term x;
            int i, j;
            for (i = 0; i < tl.Count - 1; i++)
                for (j = i + 1; j < tl.Count; j++)
                    if (tl[i].Vx > tl[j].Vx)
                    {
                        x = tl[i];
                        tl[i] = tl[j];
                        tl[j] = x;
                    }

            return tl;
        } */

        public void WriteTermstoFile(string filename)
        {
            StreamWriter fwriter = new StreamWriter(filename);
            for (int i = 0; i < _list_K_Terms.Count; i++)
            {
                fwriter.Write(_list_K_Terms[i].Vx);
                fwriter.WriteLine("  " + _list_K_Terms[i].WordX);
            }
            fwriter.Close();
        }
        public void WriteHASFISystem(string filename)
        {
            StreamWriter fwriter = new StreamWriter(filename, true);
            for (int i = 0; i < _listHASFIS.Count; i++)
            {
                fwriter.WriteLine("<" + _listHASFIS[i].VxLeft.ToString() + "\t<" + _listHASFIS[i].Left.ToString() + "\t<" + _listHASFIS[i].Term.Vx.ToString() + "~" + Revert(_listHASFIS[i].Term.WordX) + ">\t" + _listHASFIS[i].Right.ToString() + ">\t" + _listHASFIS[i].VxRight.ToString() + ">");
            }
            fwriter.Close();
        }
        public string Revert(string s)
        {
            string w = "";
            for (int i = s.Length - 1; i >= 0; i--)
                w = w + s[i];
            return w;
        }


    }
}
