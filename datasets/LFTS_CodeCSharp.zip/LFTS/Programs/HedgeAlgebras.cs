﻿// Lớp biểu diễn đối tượng Đại số gia tử Hedge Algebra
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PhD.HA
{
    public class HedgeAlgebras
    {
        float _fmc_plus;
        float _w;       
        float _fmc_minus;
        float _muyV;
        float _muyL;

        public float FMC_Minus
        {
            get { return _fmc_minus; }
            set
            { 
                _fmc_minus = value;
                _fmc_plus = 1.0f - _fmc_minus;
                _w = _fmc_minus;
            }
        }
        public float FMC_Plus
        {
            get { return _fmc_plus; }            
        }
        public float W
        {
            get { return _w; }           
        }
        public float Muy_Very
        {
            get { return _muyV; }           
        }
        public float Muy_Litte
        {
            get { return _muyL; }
            set
            {
                _muyL = value;
                _muyV = 1.0f - _muyL;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        public HedgeAlgebras()
        {
            _fmc_minus =0.0f;
            _fmc_plus = 0.0f;
            _muyL = 0.0f; ;
            _muyV = 0.0f;
            _w = 0.0f;

        }
        /// <summary>
        /// Cấu tử
        /// </summary>
        /// <param name="fmcminus1"></param>
        /// <param name="muyL1"></param>
        public HedgeAlgebras(float fmcminus, float muyL)
        {
            _fmc_minus = fmcminus;
            _fmc_plus = 1.0f - _fmc_minus;
            _muyL = muyL;
            _muyV = 1.0f - muyL;
            _w = _fmc_minus;
           
        }
        /// <summary>
        ///Ham qui dinh dau cua cac gia tu voi nhau, dau cua cac gia tu voi cac phan tu sinh -,+ 
        /// </summary>
        /// <param name="h1">gia tử thứ nhất</param>
        /// <param name="h2"> gia tử thứ 2</param>
        /// <returns></returns>

        public int SignHHHX(char h1, char h2)
        {
            int dau = 1;

            if (h1 == ConstanChars.Little) //h1='L'
                dau *= -1;

            return dau;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="x">X luu tu can xac dinh dau x[0] c+ hoac c-, x[1],x[2],.. la cac gia tu</param>
        /// <returns></returns>
        public int Sign(string x)
        {
            int dau = 0;
            if (x.Length == 1)
                if (x == TermConstans.C_minus)    //X chỉ lưu phần tử sinh c- hoặc c+, ta qui ước dấu c-="-" và c+ ="+"
                    dau = -1;
                else
                    dau = 1;
            else //X có chứa các gia tử
            {
                if (x[0] == ConstanChars.C_minus)    //Từ  x được sinh ra bởi c-
                    dau = -1;
                else
                    dau = 1;

                if (x[1] == ConstanChars.Little) dau *= -1; //h1*sign(c)

                if (x.Length > 2) //Nếu chiều dài từ lớn hơn 2
                {

                    for (int i = 2; i < x.Length; i++)
                        dau = dau * SignHHHX(x[i], x[i - 1]);
                }
            }
            return dau;
        }

        /// <summary>
        /// Hàm xác định độ đo tính mờ của từ x
        /// </summary>
        /// <param name="x"></param>
        /// <returns></returns>
        public float Fm(string wordX)
        {
            float f = 0.0f;
            if (wordX.Length == 1)
                if (wordX[0] == ConstanChars.C_minus)  //c-
                    f = _fmc_minus;
                else
                    f = _fmc_plus;
            else
            {
                if (wordX[0] == ConstanChars.C_minus)
                    f = _fmc_minus;
                else
                    f = _fmc_plus;
                for (int i = 1; i < wordX.Length; i++)
                {
                    if (wordX[i] == ConstanChars.Little)
                        f = f * _muyL;
                    else
                        f = f * _muyV;

                }

            }
            return f;
        }

        private float OmegaHx(string wordX, float alpha, float beta)
        {
            return (1.0f + Sign(wordX) * Sign(wordX + Hedge.Very) * (beta - alpha)) / 2.0f;
        }
        /// <summary>
        /// Hàm xác định giá trị định lượng của từ x
        /// </summary>
        /// <param name="x"></param>
        /// <returns></returns>
        public float Vx(string wordX)
        {
           
            float alpha, beta;
            alpha = _muyL;
            beta = _muyV;
            string x1;
            if (wordX.Length == 1)
            {
                if (wordX[0] == ConstanChars.W)
                    return _w;
                else
                    if (wordX[0] == ConstanChars.C_minus)
                        return _w - alpha * Fm(TermConstans.C_minus);
                    else
                        return _w + alpha * Fm(TermConstans.C_plus);
            }
            else
            {
                x1 = wordX.Substring(0,wordX.Length-1);
                //for (int i = 0; i < wordX.Length - 1; i++)
                //    x1 = x1 + wordX[i];
                int dau = Sign(wordX);
                float fm = Fm(wordX);
                float omega = OmegaHx(wordX, alpha, beta);
                return Vx(x1) + dau * (fm - omega * fm); //Do đại số 2 gia tử
            }
        }       
    }
}