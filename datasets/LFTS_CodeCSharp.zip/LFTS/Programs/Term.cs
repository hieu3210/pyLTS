﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PhD.HA
{
    public class Term
    {
        private string _wordX;
        private float _vx;
        private float _vxR;
        private float _fmx;
        private float _c_fmx;
        
        public string WordX
        {
            get { return _wordX; }
            set { _wordX = value; } 
        }

        public string RWordX
        {
            get { return Revert(_wordX); }
        }

        public float Vx
        {
            get { return _vx ; }
            set { _vx = value; }  
        }

        public float VxR
        {
            get { return _vxR; }
            set { _vxR = value; }
        }

        public float fmx
        {
            get { return _fmx; }
            set { _fmx = value; }
        }
        public float cfmx
        {
            get { return _c_fmx; }
            set { _c_fmx = value; }
        }

        public Term()
        {
            _wordX = "";
            _vx = 0.0f;
            _vxR = 0;
        }
        public Term(string wordX, float vx, float fmx)
        {
            _wordX = wordX;
            _vx = vx;
            _vxR = 0;
            _fmx = fmx;
        }
        private string Revert(string s)
        {
            string w = "";
            for (int i = s.Length - 1; i >= 0; i--)
                w = w + s[i];
            return w;
        }

    }
}
