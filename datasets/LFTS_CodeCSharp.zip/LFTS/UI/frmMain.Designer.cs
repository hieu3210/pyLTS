﻿namespace UI
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dockPanel2 = new WeifenLuo.WinFormsUI.DockPanel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnExit = new System.Windows.Forms.ToolStripMenuItem();
            this.xâyDựngHệLuậtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nuOptimalHAParams = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.muOptimalHAParamsPSO = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuExperiment = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.mnRBOOptimal = new System.Windows.Forms.ToolStripMenuItem();
            this.muRBOExperiment = new System.Windows.Forms.ToolStripMenuItem();
            this.fuzzyTimeSeriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuTSForecast = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dockPanel2
            // 
            this.dockPanel2.ActiveAutoHideContent = null;
            this.dockPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dockPanel2.DockBottomPortion = 0.0001D;
            this.dockPanel2.DockLeftPortion = 9.9999999999988987E-05D;
            this.dockPanel2.DockRightPortion = 0.9999D;
            this.dockPanel2.DockTopPortion = 0.0001D;
            this.dockPanel2.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World);
            this.dockPanel2.Location = new System.Drawing.Point(0, 24);
            this.dockPanel2.Name = "dockPanel2";
            this.dockPanel2.Size = new System.Drawing.Size(784, 538);
            this.dockPanel2.TabIndex = 2;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.xâyDựngHệLuậtToolStripMenuItem,
            this.fuzzyTimeSeriesToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(784, 24);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnExit});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // mnExit
            // 
            this.mnExit.Name = "mnExit";
            this.mnExit.Size = new System.Drawing.Size(105, 22);
            this.mnExit.Text = "Thoát";
            this.mnExit.Click += new System.EventHandler(this.mnExit_Click);
            // 
            // xâyDựngHệLuậtToolStripMenuItem
            // 
            this.xâyDựngHệLuậtToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nuOptimalHAParams,
            this.toolStripSeparator1,
            this.muOptimalHAParamsPSO,
            this.mnuExperiment,
            this.toolStripSeparator2,
            this.mnRBOOptimal,
            this.muRBOExperiment});
            this.xâyDựngHệLuậtToolStripMenuItem.Name = "xâyDựngHệLuậtToolStripMenuItem";
            this.xâyDựngHệLuậtToolStripMenuItem.Size = new System.Drawing.Size(108, 20);
            this.xâyDựngHệLuậtToolStripMenuItem.Text = "Xây dựng hệ luật";
            // 
            // nuOptimalHAParams
            // 
            this.nuOptimalHAParams.Name = "nuOptimalHAParams";
            this.nuOptimalHAParams.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.G)));
            this.nuOptimalHAParams.Size = new System.Drawing.Size(282, 22);
            this.nuOptimalHAParams.Text = "Tôi ưu tham số ĐSGT bằng GA";
            this.nuOptimalHAParams.Click += new System.EventHandler(this.nuOptimalHAParams_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(279, 6);
            // 
            // muOptimalHAParamsPSO
            // 
            this.muOptimalHAParamsPSO.Name = "muOptimalHAParamsPSO";
            this.muOptimalHAParamsPSO.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.P)));
            this.muOptimalHAParamsPSO.Size = new System.Drawing.Size(282, 22);
            this.muOptimalHAParamsPSO.Text = "Tối ưu tham số ĐSGT bằng PSO";
            this.muOptimalHAParamsPSO.Click += new System.EventHandler(this.muOptimalHAParamsPSO_Click);
            // 
            // mnuExperiment
            // 
            this.mnuExperiment.Name = "mnuExperiment";
            this.mnuExperiment.Size = new System.Drawing.Size(282, 22);
            this.mnuExperiment.Text = "Thử nghiệm trên bộ tham số tối ưu";
            this.mnuExperiment.Click += new System.EventHandler(this.mnuExperiment_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(279, 6);
            // 
            // mnRBOOptimal
            // 
            this.mnRBOOptimal.Name = "mnRBOOptimal";
            this.mnRBOOptimal.Size = new System.Drawing.Size(282, 22);
            this.mnRBOOptimal.Text = "Tối ưu hệ luật bằng PSO";
            this.mnRBOOptimal.Click += new System.EventHandler(this.mnRBOOptimal_Click);
            // 
            // muRBOExperiment
            // 
            this.muRBOExperiment.Name = "muRBOExperiment";
            this.muRBOExperiment.Size = new System.Drawing.Size(282, 22);
            this.muRBOExperiment.Text = "Thử nghiệm trên hệ tối ưu";
            // 
            // fuzzyTimeSeriesToolStripMenuItem
            // 
            this.fuzzyTimeSeriesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuTSForecast});
            this.fuzzyTimeSeriesToolStripMenuItem.Name = "fuzzyTimeSeriesToolStripMenuItem";
            this.fuzzyTimeSeriesToolStripMenuItem.Size = new System.Drawing.Size(111, 20);
            this.fuzzyTimeSeriesToolStripMenuItem.Text = "Fuzzy Time Series";
            // 
            // mnuTSForecast
            // 
            this.mnuTSForecast.Name = "mnuTSForecast";
            this.mnuTSForecast.Size = new System.Drawing.Size(152, 22);
            this.mnuTSForecast.Text = "FTS Forecast";
            this.mnuTSForecast.Click += new System.EventHandler(this.mnuTSForecast_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 562);
            this.Controls.Add(this.dockPanel2);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Chương trình xây dựng hệ luật mờ dựa trên ĐSGT";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private WeifenLuo.WinFormsUI.DockPanel dockPanel2;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mnExit;
        private System.Windows.Forms.ToolStripMenuItem xâyDựngHệLuậtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nuOptimalHAParams;
        private System.Windows.Forms.ToolStripMenuItem mnuExperiment;
        private System.Windows.Forms.ToolStripMenuItem muOptimalHAParamsPSO;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem mnRBOOptimal;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem muRBOExperiment;
        private System.Windows.Forms.ToolStripMenuItem fuzzyTimeSeriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mnuTSForecast;

    }
}