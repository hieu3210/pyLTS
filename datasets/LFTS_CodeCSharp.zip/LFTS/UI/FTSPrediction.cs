﻿using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI;
using System.Windows;
using System.IO;
using FTS;
using PhD.Common;
using PhD.PSO;

namespace UI
{
    public partial class frmFTSPrediction : DockContent
    {
        string filename;
        FTS_Parameters _FTS_Parameter;
        PSOParameters _psoParams;
        FuzzyTimeSeries _fts;
        LinguisticFuzzyTimeSeries _lfts;
        FTSPSOSwarm _pop;
        MetaParaPSO _mpop;

        public frmFTSPrediction()
        {
            InitializeComponent();
            _FTS_Parameter = new FTS_Parameters();
            _psoParams = new PSOParameters();
        }

        private void SetParameter()
        {
            if (cboDefuzzification.SelectedIndex == 0)
                _FTS_Parameter.defuzzificationMethod = DefuzzificationMethod.TVFLRG_Weighted;
            else if (cboDefuzzification.SelectedIndex == 1)
                _FTS_Parameter.defuzzificationMethod = DefuzzificationMethod.TVFLRG_NoWeight;
            else if (cboDefuzzification.SelectedIndex == 2)
                _FTS_Parameter.defuzzificationMethod = DefuzzificationMethod.TVFLRG_H_Sub_mkj;
            else if (cboDefuzzification.SelectedIndex == 3)
                _FTS_Parameter.defuzzificationMethod = DefuzzificationMethod.TVFLRG_Sub_And_mkj;
            else if (cboDefuzzification.SelectedIndex == 4)
                _FTS_Parameter.defuzzificationMethod = DefuzzificationMethod.TVFLRG_Sub_And_mkj_Weighted;
            else if (cboDefuzzification.SelectedIndex == 5)
                _FTS_Parameter.defuzzificationMethod = DefuzzificationMethod.TVFLRG_FuzzyWeighted;
            else if (cboDefuzzification.SelectedIndex == 6)
                _FTS_Parameter.defuzzificationMethod = DefuzzificationMethod.TVFLRG_Sub_mkj;
            else if (cboDefuzzification.SelectedIndex == 7)
                _FTS_Parameter.defuzzificationMethod = DefuzzificationMethod.TVFLRG_Sub_mkj_Weighted;
            else
                _FTS_Parameter.defuzzificationMethod = DefuzzificationMethod.TVFLRG_Proportion;
            //-------------------------------------------------------------------------
            if (cboEvaluation.SelectedIndex == 0)
                _FTS_Parameter.evaluationMethod = EvaluationMethod.MSE;
            else if (cboEvaluation.SelectedIndex == 1)
                _FTS_Parameter.evaluationMethod = EvaluationMethod.RMSE;
            else
                _FTS_Parameter.evaluationMethod = EvaluationMethod.ME;
            //--------------------------------------------------------------------------
            if (cboOrderLevel.SelectedIndex == 0)
                _FTS_Parameter.orderlevel = OrderLevel.FirstOrder;
            else if (cboOrderLevel.SelectedIndex == 1)
                _FTS_Parameter.orderlevel = OrderLevel.SecondOrder;
            else if (cboOrderLevel.SelectedIndex == 2)
                _FTS_Parameter.orderlevel = OrderLevel.ThirdOrder;
            else if (cboOrderLevel.SelectedIndex == 3)
                _FTS_Parameter.orderlevel = OrderLevel.FourthOrder;
            else if (cboOrderLevel.SelectedIndex == 4)
                _FTS_Parameter.orderlevel = OrderLevel.FifthOrder;
            else if (cboOrderLevel.SelectedIndex == 5)
                _FTS_Parameter.orderlevel = OrderLevel.SixthOrder;
            else if (cboOrderLevel.SelectedIndex == 6)
                _FTS_Parameter.orderlevel = OrderLevel.SeventhOrder;
            else if (cboOrderLevel.SelectedIndex == 7)
                _FTS_Parameter.orderlevel = OrderLevel.EighthOrder;
            else
                _FTS_Parameter.orderlevel = OrderLevel.NinthOrder;
            //--------------------------------------------------------------------------
            _FTS_Parameter.NoPartition = Convert.ToInt32(txtNoPartition.Text.Trim());
            _FTS_Parameter.MinValue = Convert.ToSingle(txtMinValue.Text.Trim());
            _FTS_Parameter.MaxValue = Convert.ToSingle(txtMaxValue.Text.Trim());
            _FTS_Parameter.TimeVariant = chTimeVariant.Checked;
            _FTS_Parameter.NumberOfForecastedValue = 22;
            _FTS_Parameter.kmax = Convert.ToByte(txtkmax.Text);
            _FTS_Parameter.FmC_minus = Convert.ToSingle(txtfmCminus.Text);
            _FTS_Parameter.MuyL = Convert.ToSingle(txtMuyL.Text);
            _FTS_Parameter.isEliminated = chDupElimi.Checked;
            _FTS_Parameter.isChenModel = chChenModel.Checked;
            //--------------------------------------------------------------------------
            _psoParams.NoGenerations = Convert.ToInt32(txtnoGenerations.Text.Trim());
            _psoParams.SizeOfPopulation = Convert.ToInt32(txtpopsize.Text.Trim());
            _psoParams.NoOuterGenerations = Convert.ToInt32(txtnoOuterGen.Text.Trim());
            _psoParams.SizeOfOuterPopulation = Convert.ToInt32(txtouterpopsize.Text.Trim());
            _psoParams.SizeOfRepository = _psoParams.SizeOfPopulation;
            _psoParams.NumberOfDimension = _FTS_Parameter.NoPartition;
            _psoParams.NumberOfFunction = Convert.ToInt32(txtNF.Text.Trim());
            _psoParams.IntertiaWeight = Convert.ToSingle(txtInertia.Text);
            _psoParams.C1 = Convert.ToSingle(txtC1.Text);
            _psoParams.C2 = Convert.ToSingle(txtC2.Text);
            _psoParams.R1 = Convert.ToSingle(txtR1.Text);
            _psoParams.R2 = Convert.ToSingle(txtR2.Text);
            List<float> lb = new List<float>();
            List<float> ub = new List<float>();
            for (int i = 0; i < _psoParams.NumberOfDimension; i++)
            {
                //lb.Add(30.0f);
                //ub.Add(_FTS_Parameter.MaxValue - _FTS_Parameter.MinValue - 30.0f);
                lb.Add(0);
                ub.Add(2 * ((float)Math.Pow(2, _FTS_Parameter.kmax) - 1) + 2);
            }
            _psoParams.LowBound = lb;
            _psoParams.UpBound = ub;

        }

        private void btnExecute_Click(object sender, EventArgs e)
        {
            if (txtDataFile.Text.Trim().Length <= 1)
            {
                MessageBox.Show("Please select data file!");
                btnExecute.Focus();
                return;
            }
            SetParameter();
            //--------------------------------------------------------------------------
            _fts = new FuzzyTimeSeries(_FTS_Parameter);
            _fts.StartForecasting(true);
            MessageBox.Show("Completed");
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Parameter files (*.data)|*.data|All files (*.*)|*.*";
            dialog.InitialDirectory = Application.ExecutablePath;
            dialog.Title = "Chọn tệp dữ liệu";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                filename = dialog.FileName;
                txtDataFile.Text = filename;
                _FTS_Parameter.FileName = Path.GetFileName(filename);
                _FTS_Parameter.FilePath = Path.GetDirectoryName(filename);
            }

        }

        private void btnOptimize_Click(object sender, EventArgs e)
        {
            if (txtDataFile.Text.Trim().Length <= 1)
            {
                MessageBox.Show("Please select data file!");
                btnExecute.Focus();
                return;
            }
            SetParameter();
            _pop = new FTSPSOSwarm(_psoParams, _FTS_Parameter);
            frmMyProgress frm = new frmMyProgress(ProgressBarStyle.Continuous);
            frm.Text = "Thế hệ thứ:";
            System.Threading.ThreadPool.QueueUserWorkItem(new System.Threading.WaitCallback(_pop.start_fly), frm);
            frm.ShowDialog(this);
        }

        private void btnTest_Click(object sender, EventArgs e)
        {
            if (txtDataFile.Text.Trim().Length <= 1)
            {
                MessageBox.Show("Please select data file!");
                btnExecute.Focus();
                return;
            }
            SetParameter();
            //--------------------------------------------------------------------------
            List<float> partiList = new List<float>();
            FuzzyTimeSeries _fts = new FuzzyTimeSeries(_FTS_Parameter);
            string testData = txtTestData.Text.Trim();
            string[] td = testData.Split(new char[] {' '});

            for (int j = 0; j < td.Length; j++)
                partiList.Add(float.Parse(td[j]));

            _fts.SetupNewPartition(partiList);
            _fts.StartForecasting(false);
            MessageBox.Show("Completed");
        }

        private void frmFTSPrediction_Load(object sender, EventArgs e)
        {

        }

        private void btnLFTSP_Click(object sender, EventArgs e)
        {
            if (txtDataFile.Text.Trim().Length <= 1)
            {
                MessageBox.Show("Please select data file!");
                btnLFTSP.Focus();
                return;
            }
            SetParameter();
            //--------------------------------------------------------------------------
            string filename = _FTS_Parameter.FilePath + "\\" + _FTS_Parameter.FileName;
            FTSDataTable actualData = new FTSDataTable(filename);
            _FTS_Parameter.NumberOfForecastedValue = actualData.LoadData();
            _FTS_Parameter.MaxValue = actualData.MaxValue;
            _FTS_Parameter.MinValue = actualData.MinValue;
            _lfts = new LinguisticFuzzyTimeSeries(_FTS_Parameter, actualData);
            _lfts.StartForecasting(true, null);
            MessageBox.Show("Completed");
        }

        private void btnOptLFTS_Click(object sender, EventArgs e)
        {
            if (txtDataFile.Text.Trim().Length <= 1)
            {
                MessageBox.Show("Please select data file!");
                btnOptLFTS.Focus();
                return;
            }
            SetParameter();
            _mpop = new MetaParaPSO(_psoParams, _FTS_Parameter);
            txtMinValue.Text = _FTS_Parameter.MinValue.ToString();
            txtMaxValue.Text = _FTS_Parameter.MaxValue.ToString();
            frmMyProgress frm = new frmMyProgress(ProgressBarStyle.Continuous);
            frm.Text = "Thế hệ thứ:";
            System.Threading.ThreadPool.QueueUserWorkItem(new System.Threading.WaitCallback(_mpop.Solve), frm);
            frm.ShowDialog(this);
        }
    }
}
