﻿namespace UI
{
    partial class frmFTSPrediction
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExecute = new System.Windows.Forms.Button();
            this.btnOpen = new System.Windows.Forms.Button();
            this.cboDefuzzification = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cboEvaluation = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cboOrderLevel = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtNoPartition = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtDataFile = new System.Windows.Forms.TextBox();
            this.btnOptimize = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtMinValue = new System.Windows.Forms.TextBox();
            this.txtMaxValue = new System.Windows.Forms.TextBox();
            this.txtpopsize = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtNF = new System.Windows.Forms.TextBox();
            this.txtnoGenerations = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtInertia = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtR2 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtR1 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtC2 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txtC1 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.btnTest = new System.Windows.Forms.Button();
            this.txtTestData = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.chTimeVariant = new System.Windows.Forms.CheckBox();
            this.txtkmax = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtMuyL = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtfmCminus = new System.Windows.Forms.TextBox();
            this.lbfmCminus = new System.Windows.Forms.Label();
            this.btnLFTSP = new System.Windows.Forms.Button();
            this.btnOptLFTS = new System.Windows.Forms.Button();
            this.txtouterpopsize = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txtnoOuterGen = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.chDupElimi = new System.Windows.Forms.CheckBox();
            this.chChenModel = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // btnExecute
            // 
            this.btnExecute.Location = new System.Drawing.Point(872, 532);
            this.btnExecute.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnExecute.Name = "btnExecute";
            this.btnExecute.Size = new System.Drawing.Size(121, 35);
            this.btnExecute.TabIndex = 0;
            this.btnExecute.Text = "&Predict";
            this.btnExecute.UseVisualStyleBackColor = true;
            this.btnExecute.Click += new System.EventHandler(this.btnExecute_Click);
            // 
            // btnOpen
            // 
            this.btnOpen.Location = new System.Drawing.Point(22, 532);
            this.btnOpen.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.Size = new System.Drawing.Size(112, 35);
            this.btnOpen.TabIndex = 1;
            this.btnOpen.Text = "Mở tệp tham số";
            this.btnOpen.UseVisualStyleBackColor = true;
            this.btnOpen.Click += new System.EventHandler(this.btnOpen_Click);
            // 
            // cboDefuzzification
            // 
            this.cboDefuzzification.FormattingEnabled = true;
            this.cboDefuzzification.Items.AddRange(new object[] {
            "TVFLRG_Weighted",
            "TVFLRG_NoWeight",
            "TVFLRG_FuzzyWeight",
            "TVFLRG_Sub_And_mkj",
            "TVFLRG_Sub_And_mkj_Weighted",
            "TVFLRG_FuzzyWeighted",
            "TVFLRG_Sub_mkj",
            "TVFLRG_Sub_mkj_Weighted",
            "TVFLRG_Proportion"});
            this.cboDefuzzification.Location = new System.Drawing.Point(237, 28);
            this.cboDefuzzification.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cboDefuzzification.Name = "cboDefuzzification";
            this.cboDefuzzification.Size = new System.Drawing.Size(180, 28);
            this.cboDefuzzification.TabIndex = 20;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(40, 40);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(176, 20);
            this.label1.TabIndex = 21;
            this.label1.Text = "Defuzzification Method:";
            // 
            // cboEvaluation
            // 
            this.cboEvaluation.FormattingEnabled = true;
            this.cboEvaluation.Items.AddRange(new object[] {
            "MSE",
            "RMSE",
            "ME"});
            this.cboEvaluation.Location = new System.Drawing.Point(237, 77);
            this.cboEvaluation.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cboEvaluation.Name = "cboEvaluation";
            this.cboEvaluation.Size = new System.Drawing.Size(180, 28);
            this.cboEvaluation.TabIndex = 22;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(40, 89);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(145, 20);
            this.label2.TabIndex = 23;
            this.label2.Text = "Evaluation Method:";
            // 
            // cboOrderLevel
            // 
            this.cboOrderLevel.FormattingEnabled = true;
            this.cboOrderLevel.Items.AddRange(new object[] {
            "FirstOrder",
            "SecondOrder",
            "ThirdOrder",
            "FourthOrder",
            "FifthOrder",
            "SixthOrder",
            "SeventhOrder",
            "EighthOrder",
            "NinthOrder"});
            this.cboOrderLevel.Location = new System.Drawing.Point(237, 128);
            this.cboOrderLevel.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cboOrderLevel.Name = "cboOrderLevel";
            this.cboOrderLevel.Size = new System.Drawing.Size(180, 28);
            this.cboOrderLevel.TabIndex = 24;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(40, 140);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 20);
            this.label3.TabIndex = 25;
            this.label3.Text = "Order Level:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(40, 188);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(156, 20);
            this.label4.TabIndex = 26;
            this.label4.Text = "Number of partitions:";
            // 
            // txtNoPartition
            // 
            this.txtNoPartition.Location = new System.Drawing.Point(237, 177);
            this.txtNoPartition.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtNoPartition.Name = "txtNoPartition";
            this.txtNoPartition.Size = new System.Drawing.Size(180, 26);
            this.txtNoPartition.TabIndex = 27;
            this.txtNoPartition.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(40, 326);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 20);
            this.label5.TabIndex = 28;
            this.label5.Text = "Data file:";
            // 
            // txtDataFile
            // 
            this.txtDataFile.Location = new System.Drawing.Point(237, 322);
            this.txtDataFile.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtDataFile.Name = "txtDataFile";
            this.txtDataFile.Size = new System.Drawing.Size(262, 26);
            this.txtDataFile.TabIndex = 29;
            this.txtDataFile.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnOptimize
            // 
            this.btnOptimize.Location = new System.Drawing.Point(1013, 532);
            this.btnOptimize.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnOptimize.Name = "btnOptimize";
            this.btnOptimize.Size = new System.Drawing.Size(121, 35);
            this.btnOptimize.TabIndex = 30;
            this.btnOptimize.Text = "&Optimize";
            this.btnOptimize.UseVisualStyleBackColor = true;
            this.btnOptimize.Click += new System.EventHandler(this.btnOptimize_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(40, 235);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(83, 20);
            this.label6.TabIndex = 31;
            this.label6.Text = "Min Value:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(40, 278);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 20);
            this.label7.TabIndex = 32;
            this.label7.Text = "Max Value:";
            // 
            // txtMinValue
            // 
            this.txtMinValue.Location = new System.Drawing.Point(237, 225);
            this.txtMinValue.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtMinValue.Name = "txtMinValue";
            this.txtMinValue.Size = new System.Drawing.Size(148, 26);
            this.txtMinValue.TabIndex = 33;
            this.txtMinValue.Text = "6200";
            this.txtMinValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtMaxValue
            // 
            this.txtMaxValue.Location = new System.Drawing.Point(237, 274);
            this.txtMaxValue.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtMaxValue.Name = "txtMaxValue";
            this.txtMaxValue.Size = new System.Drawing.Size(148, 26);
            this.txtMaxValue.TabIndex = 34;
            this.txtMaxValue.Text = "7600";
            this.txtMaxValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtpopsize
            // 
            this.txtpopsize.Location = new System.Drawing.Point(756, 66);
            this.txtpopsize.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtpopsize.Name = "txtpopsize";
            this.txtpopsize.Size = new System.Drawing.Size(88, 26);
            this.txtpopsize.TabIndex = 39;
            this.txtpopsize.Text = "30";
            this.txtpopsize.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(575, 74);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(150, 20);
            this.label8.TabIndex = 38;
            this.label8.Text = "Kích thước quần thể";
            // 
            // txtNF
            // 
            this.txtNF.Location = new System.Drawing.Point(1011, 18);
            this.txtNF.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtNF.Name = "txtNF";
            this.txtNF.Size = new System.Drawing.Size(88, 26);
            this.txtNF.TabIndex = 37;
            this.txtNF.Text = "1";
            this.txtNF.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtnoGenerations
            // 
            this.txtnoGenerations.Location = new System.Drawing.Point(756, 18);
            this.txtnoGenerations.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtnoGenerations.Name = "txtnoGenerations";
            this.txtnoGenerations.Size = new System.Drawing.Size(88, 26);
            this.txtnoGenerations.TabIndex = 36;
            this.txtnoGenerations.Text = "100";
            this.txtnoGenerations.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(575, 26);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(127, 20);
            this.label9.TabIndex = 35;
            this.label9.Text = "Số thế hệ (inner)";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(873, 28);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(127, 20);
            this.label10.TabIndex = 40;
            this.label10.Text = "Số biến mục tiêu";
            // 
            // txtInertia
            // 
            this.txtInertia.Location = new System.Drawing.Point(1013, 65);
            this.txtInertia.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtInertia.Name = "txtInertia";
            this.txtInertia.Size = new System.Drawing.Size(88, 26);
            this.txtInertia.TabIndex = 42;
            this.txtInertia.Text = "0.4";
            this.txtInertia.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(875, 74);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(100, 20);
            this.label11.TabIndex = 41;
            this.label11.Text = "Hế số Inertia";
            // 
            // txtR2
            // 
            this.txtR2.Location = new System.Drawing.Point(938, 152);
            this.txtR2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtR2.Name = "txtR2";
            this.txtR2.Size = new System.Drawing.Size(88, 26);
            this.txtR2.TabIndex = 50;
            this.txtR2.Text = "1.0";
            this.txtR2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(850, 157);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(69, 20);
            this.label12.TabIndex = 49;
            this.label12.Text = "Hệ số r2";
            // 
            // txtR1
            // 
            this.txtR1.Location = new System.Drawing.Point(938, 112);
            this.txtR1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtR1.Name = "txtR1";
            this.txtR1.Size = new System.Drawing.Size(88, 26);
            this.txtR1.TabIndex = 48;
            this.txtR1.Text = "1.0";
            this.txtR1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(850, 117);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(69, 20);
            this.label13.TabIndex = 47;
            this.label13.Text = "Hệ số r1";
            // 
            // txtC2
            // 
            this.txtC2.Location = new System.Drawing.Point(664, 152);
            this.txtC2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtC2.Name = "txtC2";
            this.txtC2.Size = new System.Drawing.Size(88, 26);
            this.txtC2.TabIndex = 46;
            this.txtC2.Text = "2.0";
            this.txtC2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(578, 157);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(72, 20);
            this.label17.TabIndex = 45;
            this.label17.Text = "Hệ số c2";
            // 
            // txtC1
            // 
            this.txtC1.Location = new System.Drawing.Point(664, 112);
            this.txtC1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtC1.Name = "txtC1";
            this.txtC1.Size = new System.Drawing.Size(88, 26);
            this.txtC1.TabIndex = 44;
            this.txtC1.Text = "2.0";
            this.txtC1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(578, 117);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(72, 20);
            this.label16.TabIndex = 43;
            this.label16.Text = "Hệ số c1";
            // 
            // btnTest
            // 
            this.btnTest.Location = new System.Drawing.Point(1056, 469);
            this.btnTest.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnTest.Name = "btnTest";
            this.btnTest.Size = new System.Drawing.Size(78, 35);
            this.btnTest.TabIndex = 51;
            this.btnTest.Text = "&Test";
            this.btnTest.UseVisualStyleBackColor = true;
            this.btnTest.Click += new System.EventHandler(this.btnTest_Click);
            // 
            // txtTestData
            // 
            this.txtTestData.Location = new System.Drawing.Point(129, 419);
            this.txtTestData.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtTestData.Name = "txtTestData";
            this.txtTestData.Size = new System.Drawing.Size(442, 26);
            this.txtTestData.TabIndex = 52;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(38, 425);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(80, 20);
            this.label14.TabIndex = 53;
            this.label14.Text = "Test data:";
            // 
            // chTimeVariant
            // 
            this.chTimeVariant.AutoSize = true;
            this.chTimeVariant.Location = new System.Drawing.Point(41, 371);
            this.chTimeVariant.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.chTimeVariant.Name = "chTimeVariant";
            this.chTimeVariant.Size = new System.Drawing.Size(121, 24);
            this.chTimeVariant.TabIndex = 54;
            this.chTimeVariant.Text = "Time-variant";
            this.chTimeVariant.UseVisualStyleBackColor = true;
            // 
            // txtkmax
            // 
            this.txtkmax.Location = new System.Drawing.Point(748, 294);
            this.txtkmax.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtkmax.Name = "txtkmax";
            this.txtkmax.Size = new System.Drawing.Size(88, 26);
            this.txtkmax.TabIndex = 56;
            this.txtkmax.Text = "3";
            this.txtkmax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(586, 302);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(120, 20);
            this.label15.TabIndex = 55;
            this.label15.Text = "Độ dài từ tối đa:";
            // 
            // txtMuyL
            // 
            this.txtMuyL.Location = new System.Drawing.Point(946, 296);
            this.txtMuyL.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtMuyL.Name = "txtMuyL";
            this.txtMuyL.Size = new System.Drawing.Size(88, 26);
            this.txtMuyL.TabIndex = 58;
            this.txtMuyL.Text = "0.5";
            this.txtMuyL.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(860, 301);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(47, 20);
            this.label18.TabIndex = 57;
            this.label18.Text = "MuyL";
            // 
            // txtfmCminus
            // 
            this.txtfmCminus.Location = new System.Drawing.Point(946, 332);
            this.txtfmCminus.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtfmCminus.Name = "txtfmCminus";
            this.txtfmCminus.Size = new System.Drawing.Size(88, 26);
            this.txtfmCminus.TabIndex = 60;
            this.txtfmCminus.Text = "0.5";
            this.txtfmCminus.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbfmCminus
            // 
            this.lbfmCminus.AutoSize = true;
            this.lbfmCminus.Location = new System.Drawing.Point(860, 337);
            this.lbfmCminus.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbfmCminus.Name = "lbfmCminus";
            this.lbfmCminus.Size = new System.Drawing.Size(48, 20);
            this.lbfmCminus.TabIndex = 59;
            this.lbfmCminus.Text = "FmC-";
            // 
            // btnLFTSP
            // 
            this.btnLFTSP.Location = new System.Drawing.Point(359, 532);
            this.btnLFTSP.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnLFTSP.Name = "btnLFTSP";
            this.btnLFTSP.Size = new System.Drawing.Size(128, 35);
            this.btnLFTSP.TabIndex = 61;
            this.btnLFTSP.Text = "&LF Predict";
            this.btnLFTSP.UseVisualStyleBackColor = true;
            this.btnLFTSP.Click += new System.EventHandler(this.btnLFTSP_Click);
            // 
            // btnOptLFTS
            // 
            this.btnOptLFTS.Location = new System.Drawing.Point(515, 532);
            this.btnOptLFTS.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnOptLFTS.Name = "btnOptLFTS";
            this.btnOptLFTS.Size = new System.Drawing.Size(146, 35);
            this.btnOptLFTS.TabIndex = 62;
            this.btnOptLFTS.Text = "Optimize L&FTS";
            this.btnOptLFTS.UseVisualStyleBackColor = true;
            this.btnOptLFTS.Click += new System.EventHandler(this.btnOptLFTS_Click);
            // 
            // txtouterpopsize
            // 
            this.txtouterpopsize.Location = new System.Drawing.Point(760, 242);
            this.txtouterpopsize.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtouterpopsize.Name = "txtouterpopsize";
            this.txtouterpopsize.Size = new System.Drawing.Size(88, 26);
            this.txtouterpopsize.TabIndex = 66;
            this.txtouterpopsize.Text = "20";
            this.txtouterpopsize.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(579, 249);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(150, 20);
            this.label19.TabIndex = 65;
            this.label19.Text = "Kích thước quần thể";
            // 
            // txtnoOuterGen
            // 
            this.txtnoOuterGen.Location = new System.Drawing.Point(760, 194);
            this.txtnoOuterGen.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtnoOuterGen.Name = "txtnoOuterGen";
            this.txtnoOuterGen.Size = new System.Drawing.Size(88, 26);
            this.txtnoOuterGen.TabIndex = 64;
            this.txtnoOuterGen.Text = "30";
            this.txtnoOuterGen.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(579, 202);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(129, 20);
            this.label20.TabIndex = 63;
            this.label20.Text = "Số thế hệ (outer)";
            // 
            // chDupElimi
            // 
            this.chDupElimi.AutoSize = true;
            this.chDupElimi.Checked = true;
            this.chDupElimi.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chDupElimi.Location = new System.Drawing.Point(237, 371);
            this.chDupElimi.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.chDupElimi.Name = "chDupElimi";
            this.chDupElimi.Size = new System.Drawing.Size(181, 24);
            this.chDupElimi.TabIndex = 67;
            this.chDupElimi.Text = "Duplicate elimination";
            this.chDupElimi.UseVisualStyleBackColor = true;
            // 
            // chChenModel
            // 
            this.chChenModel.AutoSize = true;
            this.chChenModel.Location = new System.Drawing.Point(590, 371);
            this.chChenModel.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.chChenModel.Name = "chChenModel";
            this.chChenModel.Size = new System.Drawing.Size(131, 24);
            this.chChenModel.TabIndex = 68;
            this.chChenModel.Text = "Chen\'s model";
            this.chChenModel.UseVisualStyleBackColor = true;
            // 
            // frmFTSPrediction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1193, 602);
            this.Controls.Add(this.chChenModel);
            this.Controls.Add(this.chDupElimi);
            this.Controls.Add(this.txtouterpopsize);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.txtnoOuterGen);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.btnOptLFTS);
            this.Controls.Add(this.btnLFTSP);
            this.Controls.Add(this.txtfmCminus);
            this.Controls.Add(this.lbfmCminus);
            this.Controls.Add(this.txtMuyL);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.txtkmax);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.chTimeVariant);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txtTestData);
            this.Controls.Add(this.btnTest);
            this.Controls.Add(this.txtR2);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txtR1);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txtC2);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.txtC1);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.txtInertia);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txtpopsize);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtNF);
            this.Controls.Add(this.txtnoGenerations);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtMaxValue);
            this.Controls.Add(this.txtMinValue);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btnOptimize);
            this.Controls.Add(this.txtDataFile);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtNoPartition);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cboOrderLevel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cboEvaluation);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cboDefuzzification);
            this.Controls.Add(this.btnOpen);
            this.Controls.Add(this.btnExecute);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "frmFTSPrediction";
            this.TabText = "Fuzzy Time Series Prediction";
            this.Text = "Fuzzy Time Series Prediction";
            this.Load += new System.EventHandler(this.frmFTSPrediction_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnExecute;
        private System.Windows.Forms.Button btnOpen;
        private System.Windows.Forms.ComboBox cboDefuzzification;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cboEvaluation;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cboOrderLevel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtNoPartition;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtDataFile;
        private System.Windows.Forms.Button btnOptimize;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtMinValue;
        private System.Windows.Forms.TextBox txtMaxValue;
        private System.Windows.Forms.TextBox txtpopsize;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtNF;
        private System.Windows.Forms.TextBox txtnoGenerations;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtInertia;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtR2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtR1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtC2;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtC1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button btnTest;
        private System.Windows.Forms.TextBox txtTestData;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.CheckBox chTimeVariant;
        private System.Windows.Forms.TextBox txtkmax;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtMuyL;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtfmCminus;
        private System.Windows.Forms.Label lbfmCminus;
        private System.Windows.Forms.Button btnLFTSP;
        private System.Windows.Forms.Button btnOptLFTS;
        private System.Windows.Forms.TextBox txtouterpopsize;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtnoOuterGen;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.CheckBox chDupElimi;
        private System.Windows.Forms.CheckBox chChenModel;
    }
}