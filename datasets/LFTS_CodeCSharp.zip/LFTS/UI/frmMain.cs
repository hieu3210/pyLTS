﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using PhD.FRSData;

namespace UI
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void nuOptimalHAParams_Click(object sender, EventArgs e)
        {
            frmOptimalHAParams frmOHAP = new frmOptimalHAParams();
            frmOHAP.Show(dockPanel2, WeifenLuo.WinFormsUI.DockState.DockRight);
        }

        private void mnuExperiment_Click(object sender, EventArgs e)
        {
            frmOptimalHAExperiment frmHAExp = new frmOptimalHAExperiment();
            frmHAExp.Show(dockPanel2, WeifenLuo.WinFormsUI.DockState.DockRight);
        }

        private void muOptimalHAParamsPSO_Click(object sender, EventArgs e)
        {
            frmOptimalHAParametersPSO frmOHAP = new frmOptimalHAParametersPSO();
            frmOHAP.Show(dockPanel2, WeifenLuo.WinFormsUI.DockState.DockRight);
        }

        private void mnExit_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Application.UserAppDataPath);
        }

        private void mnRBOOptimal_Click(object sender, EventArgs e)
        {
            frmOptimalFuzzyRulesPSO frmRBO = new frmOptimalFuzzyRulesPSO();
            frmRBO.Show(dockPanel2, WeifenLuo.WinFormsUI.DockState.DockRight);
        }

        private void mnuTSForecast_Click(object sender, EventArgs e)
        {
            frmFTSPrediction frmTSF = new frmFTSPrediction();
            frmTSF.Show(dockPanel2, WeifenLuo.WinFormsUI.DockState.DockRight);
        }
                

        
    }
}
