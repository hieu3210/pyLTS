﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI;
using PhD.PSO;
using PhD.Common;
using System.Windows;
using System.IO;
using PhD.FRSData;
using PhD.BuildingFuzzyRulesSystem;
using PhD.FeatureSelection;

namespace UI
{
    public partial class frmOptimalHAParametersPSO : DockContent
    {
        PSOParameters _psoParams;
        PSOExpParameters _exParams;
        OptimalHAParameter _optHAParam;
        PSOSwarm _pop;
        string fname;

        public frmOptimalHAParametersPSO()
        {
            InitializeComponent();
            _exParams = new PSOExpParameters();
            _psoParams = new PSOParameters();
            fname = "";
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Parameter files (*.para)|*.para|All files (*.*)|*.*";
            dialog.InitialDirectory = Application.ExecutablePath;
            dialog.Title = "Chọn tệp tham số";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                fname = dialog.FileName;
                _psoParams.LoadParameters(fname);
                _exParams.LoadParameter(fname);
                txtnoGenerations.Text = _psoParams.NoGenerations.ToString();
                txtpopsize.Text = _psoParams.SizeOfPopulation.ToString();
                txtNF.Text = _psoParams.NumberOfDimension.ToString();
                //----------------------------------------------------------
                txtFileName.Text = _exParams.FileName;
                txtNoAttibute.Text = _exParams.NoAttribute.ToString();
                txtNoClass.Text = _exParams.NoConsequenClass.ToString();
                txtMaxRuleLength.Text = _exParams.MaxRuleLength.ToString();
                txtNoReceivedRules.Text = _exParams.NoRecievedRules.ToString();
                //txtC1.Text = _exParams.W1.ToString();
                //txtC2.Text = _exParams.W2.ToString();
                if (_exParams.MethodTest == MethodTestType.All)
                    cboMethodTest.SelectedIndex = 0;
                else
                    if (_exParams.MethodTest == MethodTestType.FiftyFolder)
                        cboMethodTest.SelectedIndex = 1;
                    else
                        if (_exParams.MethodTest == MethodTestType.TenFolder)
                            cboMethodTest.SelectedIndex = 2;
                        else
                            cboMethodTest.SelectedIndex = 3;
                if (_exParams.WeightType == RuleWeightType.CFI_CONFIDENT)
                    cboWeightType.SelectedIndex = 0;
                else
                    if (_exParams.WeightType == RuleWeightType.CFII_CONFIDENT_CAVE)
                        cboWeightType.SelectedIndex = 1;
                    else
                        if (_exParams.WeightType == RuleWeightType.CFIII_CONFIDENT_C2ND)
                            cboWeightType.SelectedIndex = 2;
                        else
                            if (_exParams.WeightType == RuleWeightType.CFIV_CONFIDENT_CSUM)
                                cboWeightType.SelectedIndex = 3;
                            else
                                cboWeightType.SelectedIndex = 4;
                if (_exParams.PreScreenType == PreScreeningType.Conf)
                    cboPreScreen.SelectedIndex = 0;
                else
                    if (_exParams.PreScreenType == PreScreeningType.Supp)
                        cboPreScreen.SelectedIndex = 1;
                    else
                        cboPreScreen.SelectedIndex = 2;
                if (_exParams.ResionMethod == ResionMethodType.SingleWiner)
                    cboResionMethod.SelectedIndex = 0;
                else
                    cboResionMethod.SelectedIndex = 1;
                btnOptimal.Enabled = true;
                this.Text = "Tep tham so: " + Path.GetFileName(fname);
            }

        }
        private void AssignFormToParamVariables()
        {
            _psoParams.NoGenerations = Convert.ToInt16(txtnoGenerations.Text);
            _psoParams.SizeOfPopulation = Convert.ToInt16(txtpopsize.Text);
            _psoParams.NumberOfDimension = Convert.ToInt32(txtNF.Text);
            _psoParams.IntertiaWeight = Convert.ToSingle(txtInertia.Text);
            _psoParams.C1 = Convert.ToSingle(txtC1.Text);
            _psoParams.C2 = Convert.ToSingle(txtC2.Text);
            _psoParams.R1 = Convert.ToSingle(txtR1.Text);
            _psoParams.R2 = Convert.ToSingle(txtR2.Text);
            //-------------------------------------------------------------
            _exParams.FileName = txtFileName.Text;
            _exParams.NoAttribute = Convert.ToInt32(txtNoAttibute.Text);
            _exParams.NoConsequenClass = Convert.ToByte(txtNoClass.Text);
            _exParams.MaxRuleLength = Convert.ToByte(txtMaxRuleLength.Text);
            _exParams.NoRecievedRules = Convert.ToInt16(txtNoReceivedRules.Text);
            //_exParams.W1 = Convert.ToSingle(txtC1.Text);
            //_exParams.W2 = Convert.ToSingle(txtC2.Text);
            if (cboMethodTest.SelectedIndex == 0)
                _exParams.MethodTest = MethodTestType.All;
            else
            if (cboMethodTest.SelectedIndex == 1)
                _exParams.MethodTest = MethodTestType.FiftyFolder;
            else
                if (cboMethodTest.SelectedIndex == 2)
                    _exParams.MethodTest = MethodTestType.TenFolder;
                else
                    _exParams.MethodTest = MethodTestType.LiveOne;

            if (cboWeightType.SelectedIndex == 0)
                _exParams.WeightType = RuleWeightType.CFI_CONFIDENT;
            else
                if (cboWeightType.SelectedIndex == 1)
                    _exParams.WeightType = RuleWeightType.CFII_CONFIDENT_CAVE;
                else
                    if (cboWeightType.SelectedIndex == 2)
                        _exParams.WeightType = RuleWeightType.CFIII_CONFIDENT_C2ND;
                    else
                        if (cboWeightType.SelectedIndex == 3)
                            _exParams.WeightType = RuleWeightType.CFIV_CONFIDENT_CSUM;
                        else
                            _exParams.WeightType = RuleWeightType.CFV;
            if (cboPreScreen.SelectedIndex == 0)
                _exParams.PreScreenType = PreScreeningType.Conf;
            else
                if (cboPreScreen.SelectedIndex == 1)
                    _exParams.PreScreenType = PreScreeningType.Supp;
                else
                    _exParams.PreScreenType = PreScreeningType.SuppConf;

            if (cboResionMethod.SelectedIndex == 0)
                _exParams.ResionMethod = ResionMethodType.SingleWiner;
            else
                _exParams.ResionMethod = ResionMethodType.Voted;
            //---------------------------------------------------------
            _psoParams.NumberOfFunction = 1; //Ba hàm muc tiêu
            _psoParams.SizeOfRepository = _psoParams.SizeOfPopulation;
            //---------------------------------------------------------
            //Khởi tạo các cận trên và cận dưới cho các biến fm(c-), uL, kj
            //Đoạn mã tạm để chạy thử, sau này sẽ được lấy vào từ 1 file.            
            List<float> lb = new List<float>();
            List<float> ub = new List<float>();
            for (int i = 0; i < _exParams.NoAttribute; i++)
            {
                lb.Add(0.2f); //Cận dưới fm(c-)
                lb.Add(0.2f); //Cận dưới uL
                lb.Add(0.1f); //Cận dưới kj
                ub.Add(0.8f); //Cận trên fm(c-)
                ub.Add(0.8f); //Cận trên uL
                ub.Add(3.0f);//Cận trên kj
            }
            _psoParams.LowBound = lb;
            _psoParams.UpBound = ub;

        }

        private void txtnoGenerations_TextChanged(object sender, EventArgs e)
        {
            try
            {
                _psoParams.NoGenerations = Convert.ToInt16(txtnoGenerations.Text);
            }
            catch (FormatException ex)
            {
                throw ex;
            }
        }

        private void btnOptimal_Click(object sender, EventArgs e)
        {
            AssignFormToParamVariables();
            _optHAParam = new OptimalHAParameter(_exParams);
            _pop = new PSOSwarm(_psoParams, _exParams);
            _pop.f = _optHAParam;
            frmMyProgress frm = new frmMyProgress(ProgressBarStyle.Continuous);
            frm.Text = "Thế hệ thứ:";
            System.Threading.ThreadPool.QueueUserWorkItem(new System.Threading.WaitCallback(_pop.start_fly), frm);
            frm.ShowDialog(this);

        }

        private void btnFeatureSel_Click(object sender, EventArgs e)
        {
            AssignFormToParamVariables();
            FRSDatatable table = new FRSDatatable(_exParams.FilePath + "\\" + _exParams.FileName, _exParams.MethodTest, _exParams.NoAttribute, _exParams.NoConsequenClass, _exParams.minValueOfConseqClass, 1);
            table.LoadData(Path.GetFileNameWithoutExtension(_exParams.FileName));
            FeatureSelection featureSel = new FeatureSelection(table, _exParams);
            frmMyProgress frm = new frmMyProgress(ProgressBarStyle.Continuous);
            if(chDiscrete.CheckState == CheckState.Checked)
                System.Threading.ThreadPool.QueueUserWorkItem(new System.Threading.WaitCallback(featureSel.DWFS_discrete), frm);
            else
                System.Threading.ThreadPool.QueueUserWorkItem(new System.Threading.WaitCallback(featureSel.DWFS), frm);
            frm.ShowDialog(this);
        }




    }
}
