﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI;
using PhD.PSO;
using PhD.Common;
using System.Windows;
using System.IO;
using PhD.FRSData;
using PhD.BuildingFuzzyRulesSystem;

namespace UI
{
    public partial class frmOptimalHAExperiment : DockContent
    {
        PSOExpParameters _exParams;
        OptimalHAParameter _optHAParam;
        string fname;
        List<float> _HAParam; //Danh sách các tham số ĐSGT
        ExperimentExecution _eeClass;//Lớp thực thi thử nghiệm

        public frmOptimalHAExperiment()
        {
            InitializeComponent();
            _exParams = new PSOExpParameters();
            _HAParam = new List<float>();
            fname = "";
        }

        private void AssignFormToParamVariables()
        {
            _exParams.FileName = txtFileName.Text;
            _exParams.NoAttribute = Convert.ToByte(txtNoAttibute.Text);
            _exParams.NoConsequenClass = Convert.ToByte(txtNoClass.Text);
            _exParams.MaxRuleLength = Convert.ToByte(txtMaxRuleLength.Text);
            _exParams.NoRecievedRules = Convert.ToInt16(txtNoReceivedRules.Text);
            if (cboMethodTest.SelectedIndex == 0)
                _exParams.MethodTest = MethodTestType.All;
            else
            if (cboMethodTest.SelectedIndex == 1)
                _exParams.MethodTest = MethodTestType.FiftyFolder;
            else
                if (cboMethodTest.SelectedIndex == 2)
                    _exParams.MethodTest = MethodTestType.TenFolder;
                else
                    _exParams.MethodTest = MethodTestType.LiveOne;

            if (cboWeightType.SelectedIndex == 0)
                _exParams.WeightType = RuleWeightType.CFI_CONFIDENT;
            else
                if (cboWeightType.SelectedIndex == 1)
                    _exParams.WeightType = RuleWeightType.CFII_CONFIDENT_CAVE;
                else
                    if (cboWeightType.SelectedIndex == 2)
                        _exParams.WeightType = RuleWeightType.CFIII_CONFIDENT_C2ND;
                    else
                        if (cboWeightType.SelectedIndex == 3)
                            _exParams.WeightType = RuleWeightType.CFIV_CONFIDENT_CSUM;
                        else
                            _exParams.WeightType = RuleWeightType.CFV;
            if (cboPreScreen.SelectedIndex == 0)
                _exParams.PreScreenType = PreScreeningType.Conf;
            else
                if (cboPreScreen.SelectedIndex == 1)
                    _exParams.PreScreenType = PreScreeningType.Supp;
                else
                    _exParams.PreScreenType = PreScreeningType.SuppConf;

            if (cboResionMethod.SelectedIndex == 0)
                _exParams.ResionMethod = ResionMethodType.SingleWiner;
            else
                _exParams.ResionMethod = ResionMethodType.Voted;

            if (rdTestData.Checked)
                _exParams.ExperimentType = ExperimentDataType.OnTestingData;
            else
                _exParams.ExperimentType = ExperimentDataType.OnTrainingData;
        }

        private void frmHAParam_Click(object sender, EventArgs e)
        {
            string lfname, s;

            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Parameter files (*.para)|*.para|All files (*.*)|*.*";
            dialog.InitialDirectory = Application.ExecutablePath;
            dialog.Title = "Chọn tệp tham số";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                lfname = dialog.FileName;
                StreamReader rd = new StreamReader(lfname);
                s = rd.ReadLine();          //Bỏ qua header
                s = rd.ReadLine();
                s.Trim();
                txtHAParam.Text = s;
                rd.Close();
            }
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Parameter files (*.para)|*.para|All files (*.*)|*.*";
            dialog.InitialDirectory = Application.ExecutablePath;
            dialog.Title = "Chọn tệp tham số";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                fname = dialog.FileName;
                _exParams.LoadParameter(fname);
                //----------------------------------------------------------
                txtFileName.Text = _exParams.FileName;
                txtNoAttibute.Text = _exParams.NoAttribute.ToString();
                txtNoClass.Text = _exParams.NoConsequenClass.ToString();
                txtMaxRuleLength.Text = _exParams.MaxRuleLength.ToString();
                txtNoReceivedRules.Text = _exParams.NoRecievedRules.ToString();
                if (_exParams.MethodTest == MethodTestType.All)
                    cboMethodTest.SelectedIndex = 0;
                else
                    if (_exParams.MethodTest == MethodTestType.FiftyFolder)
                        cboMethodTest.SelectedIndex = 1;
                    else
                        if (_exParams.MethodTest == MethodTestType.TenFolder)
                            cboMethodTest.SelectedIndex = 2;
                        else
                            cboMethodTest.SelectedIndex = 3;
                if (_exParams.WeightType == RuleWeightType.CFI_CONFIDENT)
                    cboWeightType.SelectedIndex = 0;
                else
                    if (_exParams.WeightType == RuleWeightType.CFII_CONFIDENT_CAVE)
                        cboWeightType.SelectedIndex = 1;
                    else
                        if (_exParams.WeightType == RuleWeightType.CFIII_CONFIDENT_C2ND)
                            cboWeightType.SelectedIndex = 2;
                        else
                            if (_exParams.WeightType == RuleWeightType.CFIV_CONFIDENT_CSUM)
                                cboWeightType.SelectedIndex = 3;
                            else
                                cboWeightType.SelectedIndex = 4;
                if (_exParams.PreScreenType == PreScreeningType.Conf)
                    cboPreScreen.SelectedIndex = 0;
                else
                    if (_exParams.PreScreenType == PreScreeningType.Supp)
                        cboPreScreen.SelectedIndex = 1;
                    else
                        cboPreScreen.SelectedIndex = 2;
                if (_exParams.ResionMethod == ResionMethodType.SingleWiner)
                    cboResionMethod.SelectedIndex = 0;
                else
                    cboResionMethod.SelectedIndex = 1;
                btnSave.Enabled = true;
                btnSaveAs.Enabled = true;
                btnOptimal.Enabled = true;
                this.Text = "Tep tham so: " + Path.GetFileName(fname);
            }

        }

        private void btnOptimal_Click(object sender, EventArgs e)
        {
            if (txtHAParam.Text.Trim() == "")
            {
                MessageBox.Show("Chưa nhập các tham số gia tử! Hãy nhập");
                txtHAParam.Focus();
                return;
            }

            AssignFormToParamVariables();

            string[] G = txtHAParam.Text.Split(new char[] { ' ' });
            _HAParam.Clear();
            for (int j = 0; j < G.Length; j++)
                _HAParam.Add(float.Parse(G[j]));

            _eeClass = new ExperimentExecution(_HAParam, _exParams);
            _optHAParam = new OptimalHAParameter(_exParams);
            _eeClass.f = _optHAParam;
            frmMyProgress frm = new frmMyProgress(ProgressBarStyle.Continuous);
            frm.Text = "Đang thực hiện phân lớp theo các tham số đã có";
            System.Threading.ThreadPool.QueueUserWorkItem(new System.Threading.WaitCallback(_eeClass.evaluation), frm);
            frm.ShowDialog(this);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            AssignFormToParamVariables();
            _exParams.SaveParams(fname);
            MessageBox.Show("Ghi thành công");
        }

        private void btnSaveAs_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.DefaultExt = "opt";
            saveFileDialog1.Filter = "Parameter files (*.para)|*.para|All files (*.*)|*.*";
            saveFileDialog1.Title = "Ghi voi ten khac";
            saveFileDialog1.InitialDirectory = Application.ExecutablePath;
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                fname = saveFileDialog1.FileName;
                AssignFormToParamVariables();
                _exParams.SaveParams(fname);
                MessageBox.Show("Ghi thành công");
            }

        }


    }
}
