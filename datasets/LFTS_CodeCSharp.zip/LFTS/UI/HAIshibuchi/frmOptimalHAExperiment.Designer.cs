﻿namespace UI
{
    partial class frmOptimalHAExperiment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSave = new System.Windows.Forms.Button();
            this.frmHAOptimization = new System.Windows.Forms.GroupBox();
            this.rdTrainingData = new System.Windows.Forms.RadioButton();
            this.rdTestData = new System.Windows.Forms.RadioButton();
            this.txtNoReceivedRules = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtMaxRuleLength = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.cboResionMethod = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.cboPreScreen = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.cboWeightType = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.cboMethodTest = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtNoPatterm = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtNoClass = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtNoAttibute = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtFileName = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btnOptimal = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnSaveAs = new System.Windows.Forms.Button();
            this.btnOpen = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.frmHAParam = new System.Windows.Forms.Button();
            this.txtHAParam = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.frmHAOptimization.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(95, 17);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 1;
            this.btnSave.Text = "Ghi lại";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // frmHAOptimization
            // 
            this.frmHAOptimization.Controls.Add(this.rdTrainingData);
            this.frmHAOptimization.Controls.Add(this.rdTestData);
            this.frmHAOptimization.Controls.Add(this.txtNoReceivedRules);
            this.frmHAOptimization.Controls.Add(this.label18);
            this.frmHAOptimization.Controls.Add(this.txtMaxRuleLength);
            this.frmHAOptimization.Controls.Add(this.label15);
            this.frmHAOptimization.Controls.Add(this.cboResionMethod);
            this.frmHAOptimization.Controls.Add(this.label14);
            this.frmHAOptimization.Controls.Add(this.cboPreScreen);
            this.frmHAOptimization.Controls.Add(this.label13);
            this.frmHAOptimization.Controls.Add(this.cboWeightType);
            this.frmHAOptimization.Controls.Add(this.label12);
            this.frmHAOptimization.Controls.Add(this.cboMethodTest);
            this.frmHAOptimization.Controls.Add(this.label11);
            this.frmHAOptimization.Controls.Add(this.txtNoPatterm);
            this.frmHAOptimization.Controls.Add(this.label10);
            this.frmHAOptimization.Controls.Add(this.txtNoClass);
            this.frmHAOptimization.Controls.Add(this.label9);
            this.frmHAOptimization.Controls.Add(this.txtNoAttibute);
            this.frmHAOptimization.Controls.Add(this.label8);
            this.frmHAOptimization.Controls.Add(this.txtFileName);
            this.frmHAOptimization.Controls.Add(this.label7);
            this.frmHAOptimization.Dock = System.Windows.Forms.DockStyle.Fill;
            this.frmHAOptimization.Location = new System.Drawing.Point(3, 114);
            this.frmHAOptimization.Name = "frmHAOptimization";
            this.frmHAOptimization.Size = new System.Drawing.Size(563, 246);
            this.frmHAOptimization.TabIndex = 1;
            this.frmHAOptimization.TabStop = false;
            this.frmHAOptimization.Text = "Các tham số thử nghiệm";
            // 
            // rdTrainingData
            // 
            this.rdTrainingData.AutoSize = true;
            this.rdTrainingData.Location = new System.Drawing.Point(419, 136);
            this.rdTrainingData.Name = "rdTrainingData";
            this.rdTrainingData.Size = new System.Drawing.Size(136, 17);
            this.rdTrainingData.TabIndex = 35;
            this.rdTrainingData.Text = "Trên dữ liệu huấn luyện";
            this.rdTrainingData.UseVisualStyleBackColor = true;
            // 
            // rdTestData
            // 
            this.rdTestData.AutoSize = true;
            this.rdTestData.Checked = true;
            this.rdTestData.Location = new System.Drawing.Point(291, 136);
            this.rdTestData.Name = "rdTestData";
            this.rdTestData.Size = new System.Drawing.Size(105, 17);
            this.rdTestData.TabIndex = 34;
            this.rdTestData.TabStop = true;
            this.rdTestData.Text = "Trên dữ liệu Test";
            this.rdTestData.UseVisualStyleBackColor = true;
            // 
            // txtNoReceivedRules
            // 
            this.txtNoReceivedRules.Location = new System.Drawing.Point(106, 149);
            this.txtNoReceivedRules.Name = "txtNoReceivedRules";
            this.txtNoReceivedRules.Size = new System.Drawing.Size(60, 20);
            this.txtNoReceivedRules.TabIndex = 33;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(9, 149);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(67, 13);
            this.label18.TabIndex = 32;
            this.label18.Text = "Số luật chọn";
            // 
            // txtMaxRuleLength
            // 
            this.txtMaxRuleLength.Location = new System.Drawing.Point(106, 123);
            this.txtMaxRuleLength.Name = "txtMaxRuleLength";
            this.txtMaxRuleLength.Size = new System.Drawing.Size(60, 20);
            this.txtMaxRuleLength.TabIndex = 27;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(9, 123);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(71, 13);
            this.label15.TabIndex = 26;
            this.label15.Text = "Chiều dài luật";
            // 
            // cboResionMethod
            // 
            this.cboResionMethod.FormattingEnabled = true;
            this.cboResionMethod.Items.AddRange(new object[] {
            "SingleWiner",
            "Voted"});
            this.cboResionMethod.Location = new System.Drawing.Point(419, 98);
            this.cboResionMethod.Name = "cboResionMethod";
            this.cboResionMethod.Size = new System.Drawing.Size(121, 21);
            this.cboResionMethod.TabIndex = 25;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(287, 101);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(111, 13);
            this.label14.TabIndex = 24;
            this.label14.Text = "Phương pháp lập luận";
            // 
            // cboPreScreen
            // 
            this.cboPreScreen.FormattingEnabled = true;
            this.cboPreScreen.Items.AddRange(new object[] {
            "Confident",
            "Support",
            "Confident*Support"});
            this.cboPreScreen.Location = new System.Drawing.Point(419, 69);
            this.cboPreScreen.Name = "cboPreScreen";
            this.cboPreScreen.Size = new System.Drawing.Size(121, 21);
            this.cboPreScreen.TabIndex = 23;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(287, 72);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(52, 13);
            this.label13.TabIndex = 22;
            this.label13.Text = "Sàng luật";
            // 
            // cboWeightType
            // 
            this.cboWeightType.FormattingEnabled = true;
            this.cboWeightType.Items.AddRange(new object[] {
            "Confident",
            "Confident-ave",
            "Confident-2ndMax",
            "Confident-sum",
            "1"});
            this.cboWeightType.Location = new System.Drawing.Point(419, 41);
            this.cboWeightType.Name = "cboWeightType";
            this.cboWeightType.Size = new System.Drawing.Size(121, 21);
            this.cboWeightType.TabIndex = 21;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(287, 44);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(69, 13);
            this.label12.TabIndex = 20;
            this.label12.Text = "Trọng số luật";
            // 
            // cboMethodTest
            // 
            this.cboMethodTest.FormattingEnabled = true;
            this.cboMethodTest.Items.AddRange(new object[] {
            "All",
            "Fifty",
            "Ten",
            "LiveOneOut"});
            this.cboMethodTest.Location = new System.Drawing.Point(419, 14);
            this.cboMethodTest.Name = "cboMethodTest";
            this.cboMethodTest.Size = new System.Drawing.Size(121, 21);
            this.cboMethodTest.TabIndex = 19;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(287, 17);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(126, 13);
            this.label11.TabIndex = 18;
            this.label11.Text = "Phương pháp thử nghiệm";
            // 
            // txtNoPatterm
            // 
            this.txtNoPatterm.Location = new System.Drawing.Point(106, 97);
            this.txtNoPatterm.Name = "txtNoPatterm";
            this.txtNoPatterm.Size = new System.Drawing.Size(60, 20);
            this.txtNoPatterm.TabIndex = 17;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(11, 100);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(77, 13);
            this.label10.TabIndex = 16;
            this.label10.Text = "Số mẫu dữ liệu";
            // 
            // txtNoClass
            // 
            this.txtNoClass.Location = new System.Drawing.Point(106, 71);
            this.txtNoClass.Name = "txtNoClass";
            this.txtNoClass.Size = new System.Drawing.Size(60, 20);
            this.txtNoClass.TabIndex = 15;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(11, 74);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(37, 13);
            this.label9.TabIndex = 14;
            this.label9.Text = "Số lớp";
            // 
            // txtNoAttibute
            // 
            this.txtNoAttibute.Location = new System.Drawing.Point(106, 45);
            this.txtNoAttibute.Name = "txtNoAttibute";
            this.txtNoAttibute.Size = new System.Drawing.Size(60, 20);
            this.txtNoAttibute.TabIndex = 13;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(11, 48);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(72, 13);
            this.label8.TabIndex = 12;
            this.label8.Text = "Số thuộc tính";
            // 
            // txtFileName
            // 
            this.txtFileName.Location = new System.Drawing.Point(106, 19);
            this.txtFileName.Name = "txtFileName";
            this.txtFileName.Size = new System.Drawing.Size(164, 20);
            this.txtFileName.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(11, 22);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 13);
            this.label7.TabIndex = 10;
            this.label7.Text = "Tên tệp tin";
            // 
            // btnOptimal
            // 
            this.btnOptimal.Location = new System.Drawing.Point(419, 18);
            this.btnOptimal.Name = "btnOptimal";
            this.btnOptimal.Size = new System.Drawing.Size(120, 23);
            this.btnOptimal.TabIndex = 3;
            this.btnOptimal.Text = "Thực hiện phân lớp";
            this.btnOptimal.UseVisualStyleBackColor = true;
            this.btnOptimal.Click += new System.EventHandler(this.btnOptimal_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnOptimal);
            this.groupBox2.Controls.Add(this.btnSaveAs);
            this.groupBox2.Controls.Add(this.btnSave);
            this.groupBox2.Controls.Add(this.btnOpen);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(3, 366);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(563, 50);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            // 
            // btnSaveAs
            // 
            this.btnSaveAs.Enabled = false;
            this.btnSaveAs.Location = new System.Drawing.Point(176, 19);
            this.btnSaveAs.Name = "btnSaveAs";
            this.btnSaveAs.Size = new System.Drawing.Size(94, 23);
            this.btnSaveAs.TabIndex = 2;
            this.btnSaveAs.Text = "Ghi với tên khác";
            this.btnSaveAs.UseVisualStyleBackColor = true;
            this.btnSaveAs.Click += new System.EventHandler(this.btnSaveAs_Click);
            // 
            // btnOpen
            // 
            this.btnOpen.Location = new System.Drawing.Point(14, 17);
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.Size = new System.Drawing.Size(75, 23);
            this.btnOpen.TabIndex = 0;
            this.btnOpen.Text = "Mở tệp tham số";
            this.btnOpen.UseVisualStyleBackColor = true;
            this.btnOpen.Click += new System.EventHandler(this.btnOpen_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.groupBox1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.frmHAOptimization, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.groupBox2, 0, 2);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30.59937F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 69.40063F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 55F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(569, 419);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.frmHAParam);
            this.groupBox1.Controls.Add(this.txtHAParam);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(563, 105);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Các tham số cho ĐSGT";
            // 
            // frmHAParam
            // 
            this.frmHAParam.Location = new System.Drawing.Point(200, 75);
            this.frmHAParam.Name = "frmHAParam";
            this.frmHAParam.Size = new System.Drawing.Size(156, 23);
            this.frmHAParam.TabIndex = 6;
            this.frmHAParam.Text = "HA Parameters from file";
            this.frmHAParam.UseVisualStyleBackColor = true;
            this.frmHAParam.Click += new System.EventHandler(this.frmHAParam_Click);
            // 
            // txtHAParam
            // 
            this.txtHAParam.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHAParam.Location = new System.Drawing.Point(14, 45);
            this.txtHAParam.Name = "txtHAParam";
            this.txtHAParam.Size = new System.Drawing.Size(525, 20);
            this.txtHAParam.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(211, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "fm(c-) MuyL kj (cách nhau 1 khoảng trống):";
            // 
            // frmOptimalHAExperiment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(569, 419);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "frmOptimalHAExperiment";
            this.TabText = "Thử nghiệm dựa trên các tham số ĐSGT";
            this.Text = "Thử nghiệm dựa trên các tham số ĐSGT";
            this.frmHAOptimization.ResumeLayout(false);
            this.frmHAOptimization.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.GroupBox frmHAOptimization;
        private System.Windows.Forms.TextBox txtNoReceivedRules;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtMaxRuleLength;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox cboResionMethod;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox cboPreScreen;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox cboWeightType;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox cboMethodTest;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtNoPatterm;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtNoClass;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtNoAttibute;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtFileName;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnOptimal;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnSaveAs;
        private System.Windows.Forms.Button btnOpen;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtHAParam;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button frmHAParam;
        private System.Windows.Forms.RadioButton rdTrainingData;
        private System.Windows.Forms.RadioButton rdTestData;
    }
}