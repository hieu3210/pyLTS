﻿using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI;
using PhD.PSO;
using PhD.Common;
using System.Windows;
using System.IO;
using PhD.FRSData;
using PhD.BuildingFuzzyRulesSystem;
using PhD.HA;

namespace UI
{
    public partial class frmOptimalFuzzyRulesPSO : DockContent
    {
        PSOParameters _psoParams;
        PSOExpParameters _exParams;
        OptimalRBO _optHAParam;
        string fname;
        List<float> _HAParam; //Danh sách các tham số ĐSGT

        public frmOptimalFuzzyRulesPSO()
        {
            InitializeComponent();
            _psoParams = new PSOParameters();
            _exParams = new PSOExpParameters();
            _HAParam = new List<float>();
            fname = "";
        }

        private void AssignFormToParamVariables()
        {
            _psoParams.NoGenerations = Convert.ToInt16(txtnoGenerations.Text);
            _psoParams.SizeOfPopulation = Convert.ToInt16(txtpopsize.Text);
            _psoParams.NumberOfDimension = Convert.ToInt16(txtNoReceivedRules.Text); //Convert.ToByte(txtNF.Text);
            _psoParams.IntertiaWeight = Convert.ToSingle(txtInertia.Text);
            _psoParams.C1 = Convert.ToSingle(txtC1.Text);
            _psoParams.C2 = Convert.ToSingle(txtC2.Text);
            _psoParams.R1 = Convert.ToSingle(txtR1.Text);
            _psoParams.R2 = Convert.ToSingle(txtR2.Text);
            //-------------------------------------------------------------
            _psoParams.NumberOfFunction = 1; //Một hàm muc tiêu
            _psoParams.SizeOfRepository = _psoParams.SizeOfPopulation;
            //-------------------------------------------------------------
            _exParams.FileName = txtFileName.Text;
            _exParams.NoAttribute = Convert.ToByte(txtNoAttibute.Text);
            _exParams.NoConsequenClass = Convert.ToByte(txtNoClass.Text);
            _exParams.MaxRuleLength = Convert.ToByte(txtMaxRuleLength.Text);
            _exParams.NoRecievedRules = Convert.ToInt16(txtNoReceivedRules.Text);
            if (cboMethodTest.SelectedIndex == 0)
                _exParams.MethodTest = MethodTestType.All;
            else
                if (cboMethodTest.SelectedIndex == 1)
                    _exParams.MethodTest = MethodTestType.FiftyFolder;
                else
                    if (cboMethodTest.SelectedIndex == 2)
                        _exParams.MethodTest = MethodTestType.TenFolder;
                    else
                        _exParams.MethodTest = MethodTestType.LiveOne;

            if (cboWeightType.SelectedIndex == 0)
                _exParams.WeightType = RuleWeightType.CFI_CONFIDENT;
            else
                if (cboWeightType.SelectedIndex == 1)
                    _exParams.WeightType = RuleWeightType.CFII_CONFIDENT_CAVE;
                else
                    if (cboWeightType.SelectedIndex == 2)
                        _exParams.WeightType = RuleWeightType.CFIII_CONFIDENT_C2ND;
                    else
                        if (cboWeightType.SelectedIndex == 3)
                            _exParams.WeightType = RuleWeightType.CFIV_CONFIDENT_CSUM;
                        else
                            _exParams.WeightType = RuleWeightType.CFV;
            if (cboPreScreen.SelectedIndex == 0)
                _exParams.PreScreenType = PreScreeningType.Conf;
            else
                if (cboPreScreen.SelectedIndex == 1)
                    _exParams.PreScreenType = PreScreeningType.Supp;
                else
                    _exParams.PreScreenType = PreScreeningType.SuppConf;

            if (cboResionMethod.SelectedIndex == 0)
                _exParams.ResionMethod = ResionMethodType.SingleWiner;
            else
                _exParams.ResionMethod = ResionMethodType.Voted;

            if (rdTestData.Checked)
                _exParams.ExperimentType = ExperimentDataType.OnTestingData;
            else
                _exParams.ExperimentType = ExperimentDataType.OnTrainingData;
                    
        }

        private void AssignUpperLowerBounds(int numRules)
        {
            List<float> lb = new List<float>();
            List<float> ub = new List<float>();
            for (int i = 0; i < _psoParams.NumberOfDimension; i++)
            {
                lb.Add(0.0f); //Cận dưới
                ub.Add(numRules - 1); //Cận trên
                //ub.Add(1.0f);
            }
            _psoParams.LowBound = lb;
            _psoParams.UpBound = ub;
        }

        private void AssignUpperLowerBounds(int numRules, int[] idxmin, int[] idxmax)
        {
            List<float> lb = new List<float>();
            List<float> ub = new List<float>();
            int k = _exParams.NoRecievedRules / _exParams.NoConsequenClass;
            int odd = _exParams.NoRecievedRules % _exParams.NoConsequenClass; //Phần lẻ
            int i;

            for (int conseqClass = 0; conseqClass < _exParams.NoConsequenClass; conseqClass++)
            {
                i=0;
                while (i < k)
                {
                    lb.Add(idxmin[conseqClass]); //Cận dưới
                    ub.Add(idxmax[conseqClass]); //Cận trên
                    i++;
                }
            }
            i = 0;
            while (i < odd)
            {
                lb.Add(0.0f); //Cận dưới
                ub.Add(numRules-1); //Cận trên
                i++;
            }
            _psoParams.LowBound = lb;
            _psoParams.UpBound = ub;
        }

        private void btnOptimal_Click(object sender, EventArgs e)
        {
            if (txtHAParam.Text.Trim() == "")
            {
                MessageBox.Show("Chưa nhập các tham số gia tử! Hãy nhập");
                txtHAParam.Focus();
                return;
            }

            //int[] idxmin = new int[_exParams.NoConsequenClass];
            //int[] idxmax = new int[_exParams.NoConsequenClass];
            StreamWriter writer;
            string fname;
            float avrTr = 0.0f, avrTe = 0.0f, temax = 0.0f, avrR = 0.0f, avrL = 0.0f;
            float gavrTr = 0.0f, gavrTe = 0.0f, gavrR = 0.0f, gavrL = 0.0f, gtnoC = 0.0f;
            List<List<float>> rF = new List<List<float>>(); //Chứa các kết quả
            int l, noC = 0, tnoC = 0, nTime = 1;

            AssignFormToParamVariables();
            fname = _exParams.FilePath + "\\finalResult.txt";
            if (File.Exists(fname))
                writer = new StreamWriter(fname);
            else
                writer = File.CreateText(fname);

            long dwOldTime = DateTime.Now.Ticks;

            string[] G = txtHAParam.Text.Split(new char[] { ' ' });
            
            _HAParam.Clear();
            for (l = 0; l < G.Length; l++)
                _HAParam.Add(float.Parse(G[l]));

            _optHAParam = new OptimalRBO(_exParams);
            _optHAParam.CreateFuzzyRuleSystem(_HAParam);

            writer.WriteLine("Number of Generation: " + _psoParams.NoGenerations.ToString() + ", Number of Particle: " + _psoParams.SizeOfPopulation.ToString() + ", Inertia coefficent: " + _psoParams.IntertiaWeight.ToString());
            writer.WriteLine("----------------------------------------------------------");
            writer.WriteLine("Index of features");
            for (int f = 0; f < _exParams.NoAttribute; f++)
                writer.Write("F[" + f.ToString() + "] ");
            writer.WriteLine("");
            writer.WriteLine("Fuzziness measures of c- of every feature");
            for (int f = 0; f < _exParams.NoAttribute; f++)
                writer.Write(_HAParam[3 * f].ToString() + " ");
            writer.WriteLine("");
            writer.WriteLine("Fuzziness measures of L of every feature");
            for (int f = 0; f < _exParams.NoAttribute; f++)
                writer.Write(_HAParam[3 * f + 1].ToString() + " ");
            writer.WriteLine("");
            writer.WriteLine("Kj-similarity of every feature");
            for (int f = 0; f < _exParams.NoAttribute; f++)
                writer.Write(_HAParam[3 * f + 2].ToString() + " ");
            writer.WriteLine("");
            writer.Flush();

            do
            {
                writer.WriteLine("----------------------------------------------------------");
                avrTr = 0.0f; avrTe = 0.0f; temax = 0.0f; avrR = 0.0f; avrL = 0.0f;
                noC = 0; tnoC = 0;
                int _j = 1;
                while (_j <= 10)
                {
                    int m = _j;

                    _optHAParam.SetExecutionFolder(m);

                    AssignUpperLowerBounds(_optHAParam.MaxKRules.Rules.Count);
                    RBOPSOSwarm _pop;
                    _pop = new RBOPSOSwarm(_psoParams, _exParams, _optHAParam.MaxKRules.Rules.Count, m);
                    _pop.f = _optHAParam;
                    frmMyProgress frm = new frmMyProgress(ProgressBarStyle.Continuous);
                    frm.Text = "Thế hệ thứ " + m.ToString();
                    System.Threading.ThreadPool.QueueUserWorkItem(new System.Threading.WaitCallback(_pop.start_fly), frm);
                    //Task task = Task.Factory.StartNew(() =>
                    //{
                    //   _pop.start_fly(frm);
                    //});
                    frm.ShowDialog(this);
                    //task.Wait();
                    //task.Dispose();
                    rF = _pop.getNondominatedF();
                    temax = 0.0f;
                    int _k = 0;
                    for (int _i = 0; _i < rF.Count; _i++)
                    {
                        if (rF[_i][0] > temax)
                        {
                            temax = rF[_i][0];
                            _k = _i;
                        }
                    }
                    avrTe += rF[_k][0];
                    avrTr += rF[_k][1];
                    avrL += rF[_k][2];
                    avrR += rF[_k][3];
                    writer.WriteLine("");
                    writer.WriteLine("Running Index: " + nTime.ToString());
                    writer.WriteLine("Folder " + _j.ToString() + ": The optimal fuzzy rules set of running experiments");
                    noC = _pop._noDomR[_k].WriteRuleToFile(writer, _optHAParam.ListOfHASFISystem);
                    writer.WriteLine("The results of this fuzzy rules set: PTe = " + temax.ToString() + ", PTr = " + rF[_k][1].ToString() + ", #Rule = " + rF[_k][3].ToString() + ", AvrLen = " + rF[_k][2].ToString() + ", #C = " + noC.ToString());
                    writer.WriteLine("");
                    writer.Flush();
                    tnoC += noC;
                    frm = null;
                    _pop = null;
                    _j++;
                    System.Threading.Thread.Sleep(300);
                }
                avrTe /= 10.0f; gavrTe += avrTe;
                avrTr /= 10.0f; gavrTr += avrTr;
                avrR /= 10.0f; gavrR += avrR;
                avrL /= 10.0f; gavrL += avrL;
                gtnoC += tnoC / 10.0f;
                writer.WriteLine("----------------------------------------------------------");
                writer.WriteLine("Average result:");
                writer.WriteLine("PTe = " + avrTe.ToString() + ", PTr = " + avrTr.ToString() + ", #Rule = " + avrR.ToString() + ", AvrLen = " + avrL.ToString() + ", #C_avr = " + (tnoC / 10.0f).ToString() + ", #Rule*#C_avr = " + (avrR * (tnoC / 10.0f)).ToString());
                writer.Flush();
                System.Threading.Thread.Sleep(300);
                nTime++;
            } while (nTime <= 3);
            writer.WriteLine("----------------------------------------------------------");
            writer.WriteLine("Grand total average result:");
            writer.WriteLine("PTe = " + (gavrTe / 3).ToString() + ", PTr = " + (gavrTr / 3).ToString() + ", #Rule = " + (gavrR / 3).ToString() + ", AvrLen = " + (gavrL / 3).ToString() + ", #C_avr = " + (gtnoC / 3).ToString() + ", #Rule*#C_avr = " + ((gavrR / 3.0f) * (gtnoC / 3.0f)).ToString());

            long dwTimeElapsed = (DateTime.Now.Ticks - dwOldTime) / TimeSpan.TicksPerSecond;
            writer.WriteLine("----------------------------------------------------------");
            writer.WriteLine("Chay het: " + dwTimeElapsed.ToString() + " giay");
            writer.Close();

            MessageBox.Show("Chay het: " + dwTimeElapsed.ToString() + " giay");
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Parameter files (*.para)|*.para|All files (*.*)|*.*";
            dialog.InitialDirectory = Application.ExecutablePath;
            dialog.Title = "Chọn tệp tham số";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                fname = dialog.FileName;
                _psoParams.LoadParameters(fname);
                _exParams.LoadParameter(fname);
                txtnoGenerations.Text = _psoParams.NoGenerations.ToString();
                txtpopsize.Text = _psoParams.SizeOfPopulation.ToString();
                //----------------------------------------------------------
                txtFileName.Text = _exParams.FileName;
                txtNoAttibute.Text = _exParams.NoAttribute.ToString();
                txtNoClass.Text = _exParams.NoConsequenClass.ToString();
                txtMaxRuleLength.Text = _exParams.MaxRuleLength.ToString();
                txtNoReceivedRules.Text = _exParams.NoRecievedRules.ToString();
                if (_exParams.MethodTest == MethodTestType.All)
                    cboMethodTest.SelectedIndex = 0;
                else
                    if (_exParams.MethodTest == MethodTestType.FiftyFolder)
                        cboMethodTest.SelectedIndex = 1;
                    else
                        if (_exParams.MethodTest == MethodTestType.TenFolder)
                            cboMethodTest.SelectedIndex = 2;
                        else
                            cboMethodTest.SelectedIndex = 3;
                if (_exParams.WeightType == RuleWeightType.CFI_CONFIDENT)
                    cboWeightType.SelectedIndex = 0;
                else
                    if (_exParams.WeightType == RuleWeightType.CFII_CONFIDENT_CAVE)
                        cboWeightType.SelectedIndex = 1;
                    else
                        if (_exParams.WeightType == RuleWeightType.CFIII_CONFIDENT_C2ND)
                            cboWeightType.SelectedIndex = 2;
                        else
                            if (_exParams.WeightType == RuleWeightType.CFIV_CONFIDENT_CSUM)
                                cboWeightType.SelectedIndex = 3;
                            else
                                cboWeightType.SelectedIndex = 4;
                if (_exParams.PreScreenType == PreScreeningType.Conf)
                    cboPreScreen.SelectedIndex = 0;
                else
                    if (_exParams.PreScreenType == PreScreeningType.Supp)
                        cboPreScreen.SelectedIndex = 1;
                    else
                        cboPreScreen.SelectedIndex = 2;
                if (_exParams.ResionMethod == ResionMethodType.SingleWiner)
                    cboResionMethod.SelectedIndex = 0;
                else
                    cboResionMethod.SelectedIndex = 1;
                btnSave.Enabled = true;
                btnSaveAs.Enabled = true;
                btnOptimal.Enabled = true;
                this.Text = "Tep tham so: " + Path.GetFileName(fname);
            }

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            AssignFormToParamVariables();
            _psoParams.SaveParams(fname);
            _exParams.SaveParams(fname);
            MessageBox.Show("Ghi thành công");
        }

        private void btnSaveAs_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.DefaultExt = "opt";
            saveFileDialog1.Filter = "Parameter files (*.para)|*.para|All files (*.*)|*.*";
            saveFileDialog1.Title = "Ghi voi ten khac";
            saveFileDialog1.InitialDirectory = Application.ExecutablePath;
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                fname = saveFileDialog1.FileName;
                AssignFormToParamVariables();
                _psoParams.SaveParams(fname);
                _exParams.SaveParams(fname);
                MessageBox.Show("Ghi thành công");
            }
        }

        private void frmHAParam_Click(object sender, EventArgs e)
        {
            string lfname, s;

            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Parameter files (*.para)|*.para|All files (*.*)|*.*";
            dialog.InitialDirectory = Application.ExecutablePath;
            dialog.Title = "Chọn tệp tham số";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                lfname = dialog.FileName;
                StreamReader rd = new StreamReader(lfname);
                s = rd.ReadLine();          //Bỏ qua header
                s = rd.ReadLine();
                s.Trim();
                txtHAParam.Text = s;
                rd.Close();
            }
        }
    }
}
