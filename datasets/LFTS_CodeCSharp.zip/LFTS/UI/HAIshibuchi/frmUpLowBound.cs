﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using PhD.Common;
namespace UI
{
    public partial class frmUpLowBound : Form
    {
        GAParameters _gaParam;
        public frmUpLowBound(GAParameters gaParam)
        {            
            InitializeComponent();
            _gaParam = gaParam;
            dtgrid.DataSource = _gaParam.LowBound;
            dtgrid.Refresh();
        }
    }
}
