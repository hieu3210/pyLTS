﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using PhD.GA;
using PhD.Common;
using System.Windows;
using System.IO;
using PhD.FRSData;
using PhD.BuildingFuzzyRulesSystem;
using WeifenLuo.WinFormsUI;
namespace UI
{
    public partial class frmOptimalHAParams : DockContent
    {
        GAParameters _gaParams;
        ExpParameters _exParams;
        //OptimalHAParameter _optHAParam;
        //GAPopulations _pop;
        string fname;
        public frmOptimalHAParams()
        {
            InitializeComponent();
            _exParams = new ExpParameters();
            _gaParams = new GAParameters();
            fname = "";
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Parameter files (*.para)|*.para|All files (*.*)|*.*";
            dialog.InitialDirectory = Application.ExecutablePath;
            dialog.Title = "Chọn tệp tham số";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                fname = dialog.FileName;
                _gaParams.LoadParameters(fname);
                _exParams.LoadParameter(fname);
                txtnoGenerations.Text = _gaParams.NoGenerations.ToString();
                txtpopsize.Text = _gaParams.SizeOfPopulation.ToString();
                txtNoGen.Text = _gaParams.NoGen.ToString();
                txtLengthGen.Text = _gaParams.LengthOfGen.ToString();
                txtPcross.Text = _gaParams.PCross.ToString();
                txtPmut.Text = _gaParams.PMu.ToString();

                txtFileName.Text = _exParams.FileName;
                txtNoAttibute.Text = _exParams.NoAttribute.ToString();
                txtNoClass.Text = _exParams.NoConsequenClass.ToString();
                txtMaxRuleLength.Text = _exParams.MaxRuleLength.ToString();
                txtNoReceivedRules.Text = _exParams.NoRecievedRules.ToString();
                txtW1.Text = _exParams.W1.ToString();
                txtW2.Text = _exParams.W2.ToString();
                if (_exParams.MethodTest == MethodTestType.All)
                    cboMethodTest.SelectedIndex = 0;
                else
                    if (_exParams.MethodTest == MethodTestType.FiftyFolder)
                        cboMethodTest.SelectedIndex = 1;
                    else
                        if (_exParams.MethodTest == MethodTestType.TenFolder)
                            cboMethodTest.SelectedIndex = 2;
                        else
                            cboMethodTest.SelectedIndex = 3;
                if (_exParams.WeightType == RuleWeightType.CFI_CONFIDENT)
                    cboWeightType.SelectedIndex = 0;
                else
                    if (_exParams.WeightType == RuleWeightType.CFII_CONFIDENT_CAVE)
                        cboWeightType.SelectedIndex = 1;
                    else
                        if (_exParams.WeightType == RuleWeightType.CFIII_CONFIDENT_C2ND)
                            cboWeightType.SelectedIndex = 2;
                        else
                            cboWeightType.SelectedIndex = 3;
                if (_exParams.PreScreenType == PreScreeningType.Conf)
                    cboPreScreen.SelectedIndex = 0;
                else
                    if (_exParams.PreScreenType == PreScreeningType.Supp)
                        cboPreScreen.SelectedIndex = 1;
                    else
                        cboPreScreen.SelectedIndex = 2;
                if (_exParams.ResionMethod == ResionMethodType.SingleWiner)
                    cboResionMethod.SelectedIndex = 0;
                else
                    cboResionMethod.SelectedIndex = 1;
                btnUpLowBound.Enabled = true;
                btnSave.Enabled = true;
                btnSaveAs.Enabled = true;
                btnOptimal.Enabled = true;
                this.Text = "Tep tham so: " + Path.GetFileName(fname);
            }

        }
        private void AssignFormToParamVariables()
        {
            _gaParams.NoGenerations = Convert.ToInt16(txtnoGenerations.Text);
            _gaParams.SizeOfPopulation = Convert.ToInt16(txtpopsize.Text);
            _gaParams.NoGen = Convert.ToByte(txtNoGen.Text);
            _gaParams.LengthOfGen = Convert.ToByte(txtLengthGen.Text);
            _gaParams.PCross = Convert.ToSingle(txtPcross.Text);
            _gaParams.PMu = Convert.ToSingle(txtPmut.Text);
            _exParams.FileName = txtFileName.Text;
            _exParams.NoAttribute = Convert.ToByte(txtNoAttibute.Text);
            _exParams.NoConsequenClass = Convert.ToByte(txtNoClass.Text);
            _exParams.MaxRuleLength = Convert.ToByte(txtMaxRuleLength.Text);
            _exParams.NoRecievedRules = Convert.ToInt16(txtNoReceivedRules.Text);
            _exParams.W1 = Convert.ToSingle(txtW1.Text);
            _exParams.W2 = Convert.ToSingle(txtW2.Text);
            if (cboMethodTest.SelectedIndex == 0)
                _exParams.MethodTest = MethodTestType.All;
            else
            if (cboMethodTest.SelectedIndex == 1)
                _exParams.MethodTest = MethodTestType.FiftyFolder;
            else
                if (cboMethodTest.SelectedIndex == 2)
                    _exParams.MethodTest = MethodTestType.TenFolder;
                else
                    _exParams.MethodTest = MethodTestType.LiveOne;

            if (cboWeightType.SelectedIndex == 0)
                _exParams.WeightType = RuleWeightType.CFI_CONFIDENT;
            else
                if (cboWeightType.SelectedIndex == 1)
                    _exParams.WeightType = RuleWeightType.CFII_CONFIDENT_CAVE;
                else
                    if (cboWeightType.SelectedIndex == 2)
                        _exParams.WeightType = RuleWeightType.CFIII_CONFIDENT_C2ND;
                    else
                        _exParams.WeightType = RuleWeightType.CFV;
            if (cboPreScreen.SelectedIndex == 0)
                _exParams.PreScreenType = PreScreeningType.Conf;
            else
                if (cboPreScreen.SelectedIndex == 1)
                    _exParams.PreScreenType = PreScreeningType.Supp;
                else
                    _exParams.PreScreenType = PreScreeningType.SuppConf;

            if (cboResionMethod.SelectedIndex == 0)
                _exParams.ResionMethod = ResionMethodType.SingleWiner;
            else
                _exParams.ResionMethod = ResionMethodType.Voted;
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            AssignFormToParamVariables();
            _gaParams.SaveParams(fname);
            _exParams.SaveParams(fname);
            MessageBox.Show("Ghi thanh cong");
        }

        private void btnSaveAs_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.DefaultExt = "opt";
            saveFileDialog1.Filter = "Parameter files (*.para)|*.para|All files (*.*)|*.*";
            saveFileDialog1.Title = "Ghi voi ten khac";
            saveFileDialog1.InitialDirectory = Application.ExecutablePath;
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                fname = saveFileDialog1.FileName;
                AssignFormToParamVariables();
                _gaParams.SaveParams(fname);
                _exParams.SaveParams(fname);
            }
        }

        private void btnUpLowBound_Click(object sender, EventArgs e)
        {
            if (fname != "")
            {
                frmUpLowBound frm = new frmUpLowBound(_gaParams);
                frm.Show();
            }
        }

        private void txtnoGenerations_TextChanged(object sender, EventArgs e)
        {
            try
            {
                _gaParams.NoGenerations = Convert.ToInt16(txtnoGenerations.Text);
            }
            catch (FormatException ex)
            {
                throw ex;
            }
        }

        private void btnOptimal_Click(object sender, EventArgs e)
        {
           /* AssignFormToParamVariables();
            _optHAParam = new OptimalHAParameter(_exParams);
            _pop = new GAPopulations(_gaParams);
            _pop.f = _optHAParam;
            frmProgress frm = new frmProgress(ProgressBarStyle.Continuous);
            frm.Text = "Thế hệ thứ:";
            System.Threading.ThreadPool.QueueUserWorkItem(new System.Threading.WaitCallback(_pop.GAOpParams), frm);
            frm.ShowDialog(this);

            string fc = "fmc-:", muy = "MuyL: ", k = "kj: ";
            for (int i = 0; i < _exParams.NoAttribute; i++)
            {
                fc = fc + "  " + _pop[3 * i].ToString();
                muy = muy + "  " + _pop[3 * i + 1].ToString();
                k = k + "  " + Convert.ToByte(Math.Ceiling(_pop[3 * i + 2]).ToString());
            }
            string s = fc + "\n" + muy + "\n" + k + "\nGia tri toi uu = " + _pop.OptimalValue.ToString() + "\nBan co muon ghi lai khong?";
            if (MessageBox.Show(s, "Tham so", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                SaveOptimalParameters();
            }
            */
        }
        private void SaveOptimalParameters()
        {
           /* StreamWriter wr = new StreamWriter(_exParams.FilePath + "\\OptimalParameters.opt", true);
            wr.WriteLine(DateTime.Now.ToLongTimeString() + " " + DateTime.Now.ToShortDateString());
            wr.WriteLine("Gia tri doan nhan dung:" + _pop.OptimalValue.ToString());
            string fmc = "Fmc- :";
            string muyL = "MuyL:";
            string k = " Kj: ";
            for (int i = 0; i < _exParams.NoAttribute; i++)
            {
                fmc = fmc + "  " + _pop[3 * i].ToString();
                muyL = muyL + " " + _pop[3 * i + 1].ToString();
                k = k + " " + Convert.ToByte(Math.Ceiling(_pop[3 * i + 2]).ToString());
            }
            wr.WriteLine(fmc);
            wr.WriteLine(muyL);
            wr.WriteLine(k);
            wr.Close();*/
        }



    }
}
