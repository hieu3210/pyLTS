﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PhD.PSO;
using PhD.Common;
using System.IO;
using PhD.FRSData;
using PhD.BuildingFuzzyRulesSystem;


namespace UI
{
    public class ExperimentExecution
    {
        public IObjectFunction f;           //Chứa hàm mục tiêu
        private List<float> _HAParam;
        private PSOExpParameters _exParams;

        public ExperimentExecution(List<float> HAParam, PSOExpParameters exParam)
        {
            _HAParam = HAParam;
            _exParams = exParam;
        }

        public void evaluation(Object obj)
        {
            float[] of = new float[3];
            StreamWriter writer;
            string lfname = _exParams.FilePath + "\\result.txt";
            frmMyProgress frm = obj as PhD.PSO.frmMyProgress;
            float performance;

            frm.SetCaption("Đang tiến hành phân lớp");
            of = f.ObjectiveFunction(_HAParam, 3);

            if (File.Exists(lfname))
                writer = new StreamWriter(lfname);
            else
                writer = File.CreateText(lfname);

            writer.Write("Cac gia tri tham so DSGT: ");
            for (int i = 0; i < _exParams.NoAttribute * 3; i++)
            {
                writer.Write(_HAParam[i].ToString() + " ");
            }
            writer.WriteLine();
            writer.WriteLine("-----------------------------------------");
            writer.WriteLine("Cac bien gia tri muc tieu: ");
            writer.WriteLine("Ty le phan lop dung\t\t So luat\t\t Do dai trung binh");
            performance = of[0];
            writer.WriteLine(performance.ToString() + "\t\t" + of[1].ToString() + "\t\t" + of[2].ToString());
            writer.Close();
            frm.CloseForm();

            //System.Windows.Forms.MessageBox.Show("Hiệu suất phân lớp trung bình: " + performance.ToString(), "Kết quả", System.Windows.Forms.MessageBoxButtons.OK);
        }

    }
}
