﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PhD.FRSData;
using PhD.Common;

namespace PhD.FeatureSelection
{
    public class fcm
    {
        private List<List<ClusterPoint>> centroid; //Trung tam cua cum
        private List<float> Jm; //Ham muc tieu khi tien hanh phan cum
        private List<List<List<float>>> muy_ij; // Muc do thuoc
        private FRSDatatable _table;
        private float m = 2.0f;//He so m
        private float Eps = (float)Math.Pow(10.0f, -5.0f);
        private List<int> numClusters;

        public List<List<List<float>>> GetMembershipValues()
        {
            return muy_ij;
        }

        public List<int> GetListOfCluster()
        {
            return numClusters;
        }

        public fcm(FRSDatatable table)
        {
            _table = table;
            centroid = new List<List<ClusterPoint>>();
            Jm = new List<float>();
            muy_ij = new List<List<List<float>>>();
            numClusters = new List<int>();
            InitialValues(2);
        }

        private float CalculateCi(int Attr, int n, int i)
        {
            float ci = 0, tuso = 0.0f, mauso = 0.0f, r_pow;

            for (int j = 0; j < n; j++)
            {
                r_pow = (float)Math.Pow(muy_ij[Attr][i][j], m);
                mauso += r_pow;
                tuso += r_pow * _table.Rows(j)[Attr];
            }

            ci = tuso / mauso;

            return ci;
        }

        private void CalculateCentroidsOfAttribute(int Attr, int n, int c)
        {
            for (int i = 0; i < c; i++)
            {
                centroid[Attr][i].dataCenter = CalculateCi(Attr, n, i);
            }
        }

        private float Calculate_dij(int Attr, int i, int j)
        {
            float d = 0.0f;

            d = (float)Math.Sqrt(Math.Pow(centroid[Attr][i].dataCenter - _table.Rows(j)[Attr], 2.0f));

            return d;
        }

        private float CalculateMuyij(int Attr, int c, int i, int j)
        {
            float mu = 0.0f;

            float mauso = 0.0f;
            for (int k = 0; k < c; k++)
            {
                mauso += (float)Math.Pow(Calculate_dij(Attr, i, j) / Calculate_dij(Attr, k, j), 2.0f / (m - 1));
            }
            mu = 1.0f / mauso;

            return mu;
        }

        private void CalculateMembershipValues(int Attr, int n, int c)
        {
            for (int i = 0; i < c; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    muy_ij[Attr][i][j] = CalculateMuyij(Attr, c, i, j);
                }
            }
        }

        private float CalculateObjectiveFunction(int Attr, int n, int c)
        {
            float jm = 0.0f;
            for (int i = 0; i < c; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    jm += (float)(Math.Pow(muy_ij[Attr][i][j], m) * Calculate_dij(Attr, i, j));
                }
            }

            return jm;
        }

        private void RecalculateClusterMembershipValues(int Attr)
        {

            for (int j = 0; j < _table.RowsCount; j++)
            {
                float max = float.MinValue;
                float min = float.MaxValue;
                float sum = 0.0f;
                float newmax = max;

                for (int i = 0; i < centroid[Attr].Count; i++)
                {
                    max = muy_ij[Attr][i][j] > max ? muy_ij[Attr][i][j] : max;
                    min = muy_ij[Attr][i][j] < min ? muy_ij[Attr][i][j] : min;
                    sum += muy_ij[Attr][i][j];
                }

                if (sum != 1.0f)
                {
                    for (int i = 0; i < centroid[Attr].Count; i++)
                    {
                        muy_ij[Attr][i][j] = (muy_ij[Attr][i][j] - min) / (max - min);
                        sum += muy_ij[Attr][i][j];
                    }

                    for (int i = 0; i < centroid[Attr].Count; i++)
                    {
                        muy_ij[Attr][i][j] = muy_ij[Attr][i][j] / sum;
                        if (float.IsNaN(muy_ij[Attr][i][j]))
                        {
                            muy_ij[Attr][i][j] = 0.0f;
                        }
                        newmax = muy_ij[Attr][i][j] > newmax ? muy_ij[Attr][i][j] : newmax;
                    }
                }
                else newmax = max;
                _table.Rows(j).SetClusterIndex(Attr, newmax);
            };
        }

        public void InitialValues(int CurrentNoC)
        {
            centroid.Clear();
            Jm.Clear();
            muy_ij.Clear();
            numClusters.Clear();
            for (int i = 0; i < _table.AttibuteCount; i++)
            {
                numClusters.Add(CurrentNoC);
            }

            centroid = new List<List<ClusterPoint>>();
            Jm = new List<float>();
            muy_ij = new List<List<List<float>>>();
            float diff;

            for (int attr = 0; attr < _table.AttibuteCount; attr++)
            {
                List<ClusterPoint> centroidAttr = new List<ClusterPoint>();
                List<float> jmvalue = new List<float>();
                List<List<float>> muyij_attr = new List<List<float>>();
                float maxValue = float.MinValue;
                float minValue = float.MaxValue;

                for (int j = 0; j < _table.RowsCount; j++)
                {
                    if (_table.Rows(j)[attr] > maxValue) maxValue = _table.Rows(j)[attr];
                    if (_table.Rows(j)[attr] < minValue) minValue = _table.Rows(j)[attr];
                }

                for (int i = 0; i < numClusters[attr]; i++)
                {
                    float randomValue = MyRandom.RandomFloatMtoN(minValue, maxValue);
                    ClusterPoint cp = new ClusterPoint(randomValue, 0.0f);
                    centroidAttr.Add(cp);
                }
                Jm.Add(float.MaxValue);
                centroid.Add(centroidAttr);

                for (int i = 0; i < numClusters[attr]; i++)
                {
                    List<float> muyij = new List<float>();
                    for (int j = 0; j < _table.RowsCount; j++)
                    {
                        //diff = Calculate_dij(attr, i, j);
                        diff = CalculateMuyij(attr, numClusters[attr], i, j);
                        muyij.Add((diff == 0.0f) ? Eps : diff);
                    }
                    muyij_attr.Add(muyij);
                }
                muy_ij.Add(muyij_attr);
            }

            for (int attr = 0; attr < _table.AttibuteCount; attr++)
            {
                RecalculateClusterMembershipValues(attr);
            }
        }

        public void ReinitializeValues(int attr, int CurrentNoC)
        {
            float diff;
            float maxValue = float.MinValue;
            float minValue = float.MaxValue;

            numClusters[attr] = CurrentNoC;

            for (int j = 0; j < _table.RowsCount; j++)
            {
                if (_table.Rows(j)[attr] > maxValue) maxValue = _table.Rows(j)[attr];
                if (_table.Rows(j)[attr] < minValue) minValue = _table.Rows(j)[attr];
            }

            for (int i = 0; i < numClusters[attr]; i++)
            {
                float randomValue = MyRandom.RandomFloatMtoN(minValue, maxValue);
                if (i >= centroid[attr].Count)
                    centroid[attr].Add(new ClusterPoint(randomValue, 0.0f));
                else
                    centroid[attr][i].dataCenter = randomValue;
            }
            Jm[attr] = float.MaxValue;

            for (int i = 0; i < numClusters[attr]; i++)
            {
                if (i >= muy_ij[attr].Count)
                {
                    List<float> muyij = new List<float>();
                    for (int j = 0; j < _table.RowsCount; j++)
                    {
                        //diff = Calculate_dij(attr, i, j);
                        diff = CalculateMuyij(attr, numClusters[attr], i, j);
                        muyij.Add((diff == 0.0f) ? Eps : diff);
                    }
                    muy_ij[attr].Add(muyij);
                }
                else
                {
                    for (int j = 0; j < _table.RowsCount; j++)
                    {
                        //diff = Calculate_dij(attr, i, j);
                        diff = CalculateMuyij(attr, numClusters[attr], i, j);
                        muy_ij[attr][i][j] = (diff == 0.0f) ? Eps : diff;
                    }
                }
            }

            RecalculateClusterMembershipValues(attr);
        }

        public void do_fcm(int attr)
        {
            int numRow = _table.RowsCount;
            int c = numClusters[attr];
            int maxIterations = 100;
            float oldJ, newJ, accuracy = 0.00001f;

            int iter = 1;
            oldJ = CalculateObjectiveFunction(attr, numRow, c);
            do
            {
                CalculateCentroidsOfAttribute(attr, numRow, c);
                CalculateMembershipValues(attr, numRow, c);
                RecalculateClusterMembershipValues(attr);
                newJ = CalculateObjectiveFunction(attr, numRow, c);
                Jm[attr] = newJ;
                if (Math.Abs(oldJ - newJ) < accuracy) break;
                iter++;
                oldJ = newJ;
            } while (iter < maxIterations);
        }

        private float CalculateE1(int attr)
        {
            float e1 = 0.0f, v = 0.0f;

            float maxValue = float.MinValue;
            float minValue = float.MaxValue;

            for (int j = 0; j < _table.RowsCount; j++)
            {
                if (_table.Rows(j)[attr] > maxValue) maxValue = _table.Rows(j)[attr];
                if (_table.Rows(j)[attr] < minValue) minValue = _table.Rows(j)[attr];
            }
            v = (maxValue + minValue) / 2.0f;

            for (int j = 0; j < _table.RowsCount; j++)
            {
                e1 += (float)Math.Abs(_table.Rows(j)[attr] - v);
            }

            return e1;
        }

        private float CalculateDc(int attr)
        {
            float dc = float.MinValue, diff = 0.0f;

            for (int i = 0; i < numClusters[attr]; i++)
            {
                for (int j = 0; j < numClusters[attr]; j++)
                {
                    diff = (float)Math.Abs(centroid[attr][i].dataCenter - centroid[attr][j].dataCenter);
                    if (diff > dc) dc = diff;
                }
            }

            return dc;
        }

        public float CalculatePBMFIndex(int attr)
        {
            float v_pbmf = 0.0f;

            v_pbmf = (float)Math.Pow((1.0f / numClusters[attr]) * (CalculateE1(attr) / Jm[attr]) * CalculateDc(attr), 2.0f);

            return v_pbmf;
        }

        public void StartPreprocessing()
        {
            //Bat dau qua trinh xu ly
            for (int attr = 0; attr < _table.AttibuteCount; attr++)
            {
                if (_table.isContinuousAttribute(attr) != 0)
                {
                    int c = 2;
                    float lastPBMF = 0.0f, PBMF_index;
                    do
                    {
                        ReinitializeValues(attr, c);
                        do_fcm(attr);
                        PBMF_index = CalculatePBMFIndex(attr);
                        if (PBMF_index == lastPBMF) break;
                        else lastPBMF = PBMF_index;
                        c++;
                    } while (c <= 30);
                }
            }
        }

    }
}
