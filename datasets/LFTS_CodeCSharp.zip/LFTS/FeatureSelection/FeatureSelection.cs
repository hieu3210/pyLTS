﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;
using PhD.FRSData;
using PhD.Common;
using PhD.PSO;

namespace PhD.FeatureSelection
{
    public class FeatureSelection
    {
        private FRSDatatable _table;
        private List<int> numClusters;
        private List<List<List<float>>> _muy_ij; // Muc do thuoc;
        List<int> listOfSelAttr; //Tap cac feature duoc chon
        PSOExpParameters _psoparam;

        public FeatureSelection(FRSDatatable table, PSOExpParameters psoparam)
        {
            _table = table;
            _psoparam = psoparam;
            numClusters = new List<int>();
            _muy_ij = new List<List<List<float>>>();
            listOfSelAttr = new List<int>();
        }

        private float calculate_px(int attr, int c)
        {
            float p = 0.0f;
            int countx = 0;

            for (int j = 0; j < _table.RowsCount; j++)
            {
                if (_muy_ij[attr][c][j] == _table.Rows(j).GetClusterIndex(attr)) countx++;
            }
            p = countx / _table.RowsCount;

            return p;
        }

        private float[] calculate_all_px(int attr)
        {
            float[] p = new float[numClusters[attr]];
            int[] countx = new int[numClusters[attr]];

            for (int j = 0; j < _table.RowsCount; j++)
            {
                for (int i = 0; i < numClusters[attr]; i++)
                    if (_muy_ij[attr][i][j] == _table.Rows(j).GetClusterIndex(attr)) countx[i]++;
            }

            for (int i = 0; i < numClusters[attr]; i++)
                p[i] = countx[i] * 1.0f / _table.RowsCount;

            return p;
        }

        private float calculate_pxy(int attr, int c, int cls)
        {
            float p = 0.0f;
            int countx = 0;

            for (int j = 0; j < _table.RowsCount; j++)
            {
                if (_muy_ij[attr][c][j] == _table.Rows(j).GetClusterIndex(attr) && _table.Rows(j).ConseqClass == cls) countx++;
            }
            p = countx * 1.0f / _table.RowsCount;

            return p;
        }

        //Tinh p(x, class)
        private float[] calculate_all_pxy(int attr, int cls)
        {
            float[] p = new float[numClusters[attr]];
            int[] countx = new int[numClusters[attr]];

            for (int j = 0; j < _table.RowsCount; j++)
            {
                for (int i = 0; i < numClusters[attr]; i++)
                    if (_muy_ij[attr][i][j] == _table.Rows(j).GetClusterIndex(attr) && _table.Rows(j).ConseqClass == cls) countx[i]++;
            }
            for (int i = 0; i < numClusters[attr]; i++)
                p[i] = countx[i] * 1.0f / _table.RowsCount;

            return p;
        }

        //Tinh p(class, x)
        private float[] calculate_all_p_class_x(int attr, int c)
        {
            float[] p = new float[_table.ConseqClassCount];
            int[] countc = new int[_table.ConseqClassCount];

            for (int j = 0; j < _table.RowsCount; j++)
            {
                if (_muy_ij[attr][c][j] == _table.Rows(j).GetClusterIndex(attr)) countc[_table.Rows(j).ConseqClass]++;
            }
            for (int cls = 0; cls < _table.ConseqClassCount; cls++)
                p[cls] = countc[cls] * 1.0f / _table.RowsCount;

            return p;
        }

        //Tinh p(x,y)
        private float calculate_all_pxy_attr(int attr1, int attr2)
        {
            float p = 0.0f;
            int[] countx = new int[numClusters[attr1]];

            for (int j = 0; j < _table.RowsCount; j++)
            {
                for (int i = 0; i < numClusters[attr1]; i++)
                    for (int c = 0; c < numClusters[attr2]; c++)
                        if (_muy_ij[attr1][i][j] == _table.Rows(j).GetClusterIndex(attr1) && _muy_ij[attr2][c][j] == _table.Rows(j).GetClusterIndex(attr2)) countx[i]++;
            }

            for (int i = 0; i < numClusters[attr1]; i++)
                p += countx[i] * 1.0f / _table.RowsCount;

            return p;
        }

        //Tinh p(x,class,y)
        private float calculate_all_px_class_y(int attr1, int attr2)
        {
            float p = 0.0f;
            int[] countx = new int[_table.ConseqClassCount];

            for (int j = 0; j < _table.RowsCount; j++)
            {
                for (int i = 0; i < numClusters[attr2]; i++)
                    for (int c = 0; c < numClusters[attr1]; c++)
                        if (_muy_ij[attr2][i][j] == _table.Rows(j).GetClusterIndex(attr2) && _muy_ij[attr1][c][j] == _table.Rows(j).GetClusterIndex(attr1)) countx[_table.Rows(j).ConseqClass]++;
            }

            for (int i = 0; i < _table.ConseqClassCount; i++)
                p += countx[i] * 1.0f / _table.RowsCount;

            return p;
        }

        //Tinh p(class)
        private float[] Calculate_py()
        {
            float[] p = new float[_table.ConseqClassCount];
            int[] countp = new int[_table.ConseqClassCount];

            for (int j = 0; j < _table.RowsCount; j++)
                countp[_table.Rows(j).ConseqClass]++;

            for (int l = 0; l < _table.ConseqClassCount; l++)
                p[l] = countp[l] * 1.0f / _table.RowsCount;

            return p;
        }

        //Tinh Entropy cua X
        private float Calculate_HX_discrete(int attr, List<DataPoint> data)
        {
            if (_table.RowsCount < 1) return 0.0f;
            float p = 0.0f, px = 0.0f;

            for (int c = 0; c < data.Count; c++)
            {
                px = data[c].NoOccurence * 1.0f / _table.RowsCount;
                p += px * (float)Math.Log(px, 2);
            }

            return -p;
        }

        //Tinh Entropy cua X
        private float Calculate_HX(int attr)
        {
            float p = 0.0f, px = 0.0f;
            int[] countx = new int[numClusters[attr]];

            for (int j = 0; j < _table.RowsCount; j++)
            {
                for (int c = 0; c < numClusters[attr]; c++)
                {
                    if (_muy_ij[attr][c][j] == _table.Rows(j).GetClusterIndex(attr)) countx[c]++;
                }
            }

            for (int c = 0; c < numClusters[attr]; c++)
            {
                px = countx[c] * 1.0f / _table.RowsCount;
                p += px * (float)Math.Log(px, 2);
            }

            return -p;
        }

        //Tinh Entropy cua Consequence class
        private float Calculate_HY()
        {
            float p = 0.0f, px = 0.0f;
            int[] countx = new int[_table.ConseqClassCount];

            for (int j = 0; j < _table.RowsCount; j++)
            {
                countx[_table.Rows(j).ConseqClass]++;
            }

            for (int c = 0; c < _table.ConseqClassCount; c++)
            {
                px = countx[c] * 1.0f / _table.RowsCount;
                p += px * (float)Math.Log(px, 2);
            }

            return -p;
        }

        //Tinh Matual Information (MI) giua X va Y
        private float Calculate_IXY_discrete(int attr, List<DataPoint> data)
        {
            if (_table.RowsCount < 1) return 0.0f;
            int[] county = new int[_table.ConseqClassCount];

            for (int j = 0; j < _table.RowsCount; j++)
            {
                county[_table.Rows(j).ConseqClass]++;
            }

            float hx = 0.0f;
            float pxy = 0.0f, px = 0.0f, py = 0.0f;
            for (int c = 0; c < data.Count; c++)
            {
                px = data[c].NoOccurence * 1.0f / _table.RowsCount;
                for (int cls = 0; cls < _table.ConseqClassCount; cls++)
                {
                    pxy = data[c].classLabel[cls] * 1.0f / _table.RowsCount;
                    py = county[cls] * 1.0f / _table.RowsCount;
                    if (pxy != 0.0f) hx += pxy * (float)Math.Log(pxy / (px * py), 2);
                }
            }

            return hx;
        }

        //Tinh Matual Information (MI) giua X va Y
        private float Calculate_IXY(int attr)
        {
            float hx = 0.0f;
            int[] countx = new int[numClusters[attr]];
            int[,] countxy = new int[numClusters[attr], _table.ConseqClassCount];
            int[] county = new int[_table.ConseqClassCount];

            for (int cls = 0; cls < _table.ConseqClassCount; cls++)
                county[cls]++;

            for (int j = 0; j < _table.RowsCount; j++)
            {
                county[_table.Rows(j).ConseqClass]++;
                for (int c = 0; c < numClusters[attr]; c++)
                {
                    if (_muy_ij[attr][c][j] == _table.Rows(j).GetClusterIndex(attr))
                    {
                        countx[c]++;
                        countxy[c, _table.Rows(j).ConseqClass]++;
                    }
                }
            }

            float pxy = 0.0f, px = 0.0f, py = 0.0f;
            for (int c = 0; c < numClusters[attr]; c++)
            {
                px = countx[c] * 1.0f / _table.RowsCount;
                for (int cls = 0; cls < _table.ConseqClassCount; cls++)
                {
                    pxy = countxy[c, cls] * 1.0f / _table.RowsCount;
                    py = county[cls] * 1.0f / _table.RowsCount;
                    if (pxy != 0.0f) hx += pxy * (float)Math.Log(pxy / (px * py), 2);
                }
            }

            return hx;
        }

        //Tinh I(X;Y|Z) discrete data
        private float Calculate_IXYZ_discrete(List<DataPoint2Attr> data)
        {
            if (data.Count < 1) return 0.0f;

            float p = 0.0f;
            float pz = 0.0f, pxyz = 0.0f, pxz = 0.0f, pyz = 0.0f;

            for (int j = 0; j < data.Count; j++)
            {
                pz = data[j].NoOccurence2 * 1.0f / _table.RowsCount;
                pxz = data[j].NoOccurence * 1.0f / _table.RowsCount;
                for (int c = 0; c < _table.ConseqClassCount; c++)
                {
                    pxyz = data[j].classLabel[c] * 1.0f / _table.RowsCount;
                    pyz = data[j].classLabel2[c] * 1.0f / _table.RowsCount;
                    if (pz != 0.0f && pxyz != 0.0f && pxz != 0.0f && pyz != 0.0f)
                        p += pxyz * (float)Math.Log(pz * pxyz / (pxz * pyz), 2);
                }
            }

            return p;
        }

        //Tinh I(X;Y|Z)
        private float Calculate_IXYZ(int attr1, int attr2)
        {
            int[, ,] countxyz = new int[numClusters[attr2], _table.ConseqClassCount, numClusters[attr1]];
            int[] countz = new int[numClusters[attr2]];
            int[,] countxz = new int[numClusters[attr1], numClusters[attr2]];
            int[,] countyz = new int[_table.ConseqClassCount, numClusters[attr2]];
            float p = 0.0f;

            for (int j = 0; j < _table.RowsCount; j++)
            {
                for (int z = 0; z < numClusters[attr2]; z++)
                {
                    for (int x = 0; x < numClusters[attr1]; x++)
                    {
                        if (_muy_ij[attr2][z][j] == _table.Rows(j).GetClusterIndex(attr2) && _muy_ij[attr1][x][j] == _table.Rows(j).GetClusterIndex(attr1))
                        {
                            countxyz[z, _table.Rows(j).ConseqClass, x]++;
                            countxz[x, z]++;
                        }
                    }
                    if (_muy_ij[attr2][z][j] == _table.Rows(j).GetClusterIndex(attr2))
                    {
                        countyz[_table.Rows(j).ConseqClass, z]++;
                        countz[z]++;
                    }
                }
            }

            float pz = 0.0f, pxyz = 0.0f, pxz = 0.0f, pyz = 0.0f;
            for (int z = 0; z < numClusters[attr2]; z++)
            {
                pz = countz[z] * 1.0f / _table.RowsCount;
                for (int x = 0; x < numClusters[attr1]; x++)
                {
                    pxz = countxz[x, z] * 1.0f / _table.RowsCount;
                    for (int cls = 0; cls < _table.ConseqClassCount; cls++)
                    {
                        pxyz = countxyz[z, cls, x] * 1.0f / _table.RowsCount;
                        pyz = countyz[cls, z] * 1.0f / _table.RowsCount;
                        if (pz != 0.0f && pxyz != 0.0f && pxz != 0.0f && pyz != 0.0f)
                            p += pxyz * (float)Math.Log(pz * pxyz / (pxz * pyz), 2);
                    }
                }
            }

            return p;
        }

        //Tinh U(X, Y) --> (0 <= U(X, Y) <= 1)
        private float Calculate_UXY(int attr)
        {
            float p = 2 * (Calculate_IXY(attr) / (Calculate_HX(attr) + Calculate_HY()));

            return p;
        }

        //Tinh U(X, Y) --> (0 <= U(X, Y) <= 1)
        private float Calculate_UXY_discrete(int attr)
        {
            List<DataPoint> data = new List<DataPoint>();

            float value = 0.0f;

            if (_table.isContinuousAttribute(attr) != 0)
                value = _table.Rows(0).GetClusterIndex(attr);
            else
                value = _table.Rows(0)[attr];

            int k = 0;
            data.Add(new DataPoint(value, 1, _table.Rows(0).ConseqClass, _table.AttibuteCount));
            for (int j = 1; j < _table.RowsCount; j++)
            {
                if (_table.isContinuousAttribute(attr) != 0)
                    value = _table.Rows(j).GetClusterIndex(attr);
                else
                    value = _table.Rows(j)[attr];
                k = 0;
                while (k < data.Count)
                {
                    if (value == data[k].dataValue)
                    {
                        data[k].NoOccurence++;
                        data[k].classLabel[_table.Rows(j).ConseqClass]++;
                        break;
                    }
                    k++;
                }
                if (k >= data.Count) data.Add(new DataPoint(value, 1, _table.Rows(j).ConseqClass, _table.AttibuteCount));
            }
            //---------------------------------------------
            float p = 2 * (Calculate_IXY_discrete(attr, data) / (Calculate_HX_discrete(attr, data) + Calculate_HY()));

            return p;
        }

        //Tinh RR(i, j) --> (-1 <= RR(i, j) <= 0)
        private float Calculate_RR_ij(int attr1, int attr2)
        {
            float rr = 0.0f;

            rr = 2.0f * (Calculate_IXYZ(attr1, attr2) - Calculate_IXY(attr1)) / (Calculate_HX(attr1) + Calculate_HY());

            return rr;
        }

        private float CR_ij(int attr1, int attr2)
        {
            float cr = 0.0f;

            float ixyz = Calculate_IXYZ(attr1, attr2);
            float ixy = Calculate_IXY(attr1);

            cr = 2.0f * (ixyz - ixy) / (Calculate_HX(attr1) + Calculate_HY());
            if (ixyz > ixy && cr < 0) cr = -cr;
            if (ixyz <= ixy && cr > 0) cr = -cr;

            return cr;
        }

        private float CR_ij_discrete(int attr1, int attr2)
        {
            List<DataPoint> data1 = new List<DataPoint>();
            List<DataPoint> data2 = new List<DataPoint>();
            List<DataPoint2Attr> data = new List<DataPoint2Attr>();
            float value1 = 0.0f;
            float value2 = 0.0f;

            if (_table.isContinuousAttribute(attr1) != 0)
                value1 = _table.Rows(0).GetClusterIndex(attr1);
            else
                value1 = _table.Rows(0)[attr1];

            if (_table.isContinuousAttribute(attr2) != 0)
                value2 = _table.Rows(0).GetClusterIndex(attr2);
            else
                value2 = _table.Rows(0)[attr2];

            int k = 0, occ1 = 1, occ2 = 1, occl1 = 1, occl2 = 1;

            data1.Add(new DataPoint(value1, 1, _table.Rows(0).ConseqClass, _table.AttibuteCount));
            data2.Add(new DataPoint(value2, 1, _table.Rows(0).ConseqClass, _table.AttibuteCount));
            data.Add(new DataPoint2Attr(value1, value2, 1, _table.Rows(0).ConseqClass, _table.AttibuteCount));
            data[0].NoOccurence1 = occ1;
            data[0].classLabel1[_table.Rows(0).ConseqClass] = occl1;
            data[0].NoOccurence2 = occ2;
            data[0].classLabel2[_table.Rows(0).ConseqClass] = occl2;
            for (int j = 1; j < _table.RowsCount; j++)
            {
                if (_table.isContinuousAttribute(attr1) != 0)
                    value1 = _table.Rows(j).GetClusterIndex(attr1);
                else
                    value1 = _table.Rows(j)[attr1];
                k = 0;
                while (k < data1.Count)
                {
                    if (value1 == data1[k].dataValue)
                    {
                        data1[k].NoOccurence++;
                        data1[k].classLabel[_table.Rows(j).ConseqClass]++;
                        occ1 = data1[k].NoOccurence;
                        occl1 = data1[k].classLabel[_table.Rows(j).ConseqClass];
                        break;
                    }
                    k++;
                }
                if (k >= data1.Count)
                {
                    data1.Add(new DataPoint(value1, 1, _table.Rows(j).ConseqClass, _table.AttibuteCount));
                    occ1 = 1;
                    occl1 = 1;
                }
                //-------------------------------------------------------
                if (_table.isContinuousAttribute(attr2) != 0)
                    value2 = _table.Rows(j).GetClusterIndex(attr2);
                else
                    value2 = _table.Rows(j)[attr2];
                k = 0;
                while (k < data2.Count)
                {
                    if (value2 == data2[k].dataValue)
                    {
                        data2[k].NoOccurence++;
                        data2[k].classLabel[_table.Rows(j).ConseqClass]++;
                        occ2 = data2[k].NoOccurence;
                        occl2 = data2[k].classLabel[_table.Rows(j).ConseqClass];
                        break;
                    }
                    k++;
                }
                if (k >= data2.Count)
                {
                    data2.Add(new DataPoint(value2, 1, _table.Rows(j).ConseqClass, _table.AttibuteCount));
                    occ2 = 1;
                    occl2 = 1;
                }
                //-------------------------------------------------------
                k = 0;
                bool isAddNew = true;
                while (k < data.Count)
                {
                    if (value1 == data[k].dataValue1 && (value2 == data[k].dataValue2))
                    {
                        isAddNew = false;
                        data[k].NoOccurence++;
                        data[k].classLabel[_table.Rows(j).ConseqClass]++;
                    }
                    if (data[k].dataValue1 == value1)
                    {
                        data[k].NoOccurence1 = occ1;
                        data[k].classLabel1[_table.Rows(j).ConseqClass] = occl1;
                    }
                    if (data[k].dataValue2 == value2)
                    {
                        data[k].NoOccurence2 = occ2;
                        data[k].classLabel2[_table.Rows(j).ConseqClass] = occl2;
                    }
                    k++;
                }
                if (isAddNew)
                {
                    data.Add(new DataPoint2Attr(value1, value2, 1, _table.Rows(j).ConseqClass, _table.AttibuteCount));
                    k = data.Count - 1;
                    data[k].NoOccurence1 = occ1;
                    data[k].classLabel1[_table.Rows(j).ConseqClass] = occl1;
                    data[k].NoOccurence2 = occ2;
                    data[k].classLabel2[_table.Rows(j).ConseqClass] = occl2;
                }
            }
            //------------------------------------------------------------
            float cr = 0.0f;

            float ixyz = Calculate_IXYZ_discrete(data);
            float ixy = Calculate_IXY_discrete(attr1, data1);

            cr = 2.0f * (ixyz - ixy) / (Calculate_HX_discrete(attr1, data1) + Calculate_HY());
            if (ixyz > ixy && cr < 0) cr = -cr;
            if (ixyz <= ixy && cr > 0) cr = -cr;

            return cr;
        }

        public void DWFS_discrete(Object obj)
        {
            int k = 0, f = 0; //Bien dem cho vong lap while
            int delta = (int)Math.Ceiling(Math.Sqrt(_table.AttibuteCount)) + 1; //So thuoc tinh toi da can chon
            delta = 13;
            List<ClusterAttribute> attr = new List<ClusterAttribute>();
            PhD.PSO.frmMyProgress frm = obj as PhD.PSO.frmMyProgress;
            frm.SetMax(delta);
            frm.SetCaption("Đang khởi tạo ...");

            fcm fuzzyCMean = new fcm(_table);
            fuzzyCMean.StartPreprocessing();
            _muy_ij = fuzzyCMean.GetMembershipValues();
            numClusters = fuzzyCMean.GetListOfCluster();

            //Khoi tao
            for (f = 0; f < _table.AttibuteCount; f++)
            {
                ClusterAttribute at = new ClusterAttribute(f, 1.0f, Calculate_UXY_discrete(f), float.MinValue);
                attr.Add(at);
            }

            listOfSelAttr.Clear();
            while (k < delta)
            {
                frm.SetCaption("Chọn được " + (k + 1).ToString() + "/" + delta.ToString() + " thuộc tính.");
                frm.IncreasePercent();
                int maxJ = 0;
                attr[0].J = attr[0].R * attr[0].Weight;
                float maxJ_value = attr[0].J;
                for (f = 1; f < attr.Count; f++)
                {
                    attr[f].J = attr[f].R * attr[f].Weight;
                    if (attr[f].J > maxJ_value)
                    {
                        maxJ_value = attr[f].J;
                        maxJ = f;
                    }
                }
                listOfSelAttr.Add(attr[maxJ].attr);

                for (f = 0; f < attr.Count; f++)
                {
                    if (f != maxJ)
                    {
                        float CR = CR_ij_discrete(attr[f].attr, attr[maxJ].attr);
                        attr[f].Weight = attr[f].Weight * (1.0f + CR);
                    }
                }
                //Loai maxJ ra khoi tap thuoc tinh
                attr.RemoveAt(maxJ);
                k++;
            }
            WriteSelectedAttribute(_psoparam.FilePath + "\\SelAttr.txt");
            frm.CloseForm();
        }

        public void DWFS(Object obj)
        {
            int k = 0, f = 0; //Bien dem cho vong lap while
            int delta = (int)Math.Ceiling(Math.Sqrt(_table.AttibuteCount)) + 1; //So thuoc tinh toi da can chon
            List<ClusterAttribute> attr = new List<ClusterAttribute>();
            fcm fuzzyCMean = new fcm(_table);
            PhD.PSO.frmMyProgress frm = obj as PhD.PSO.frmMyProgress;
            frm.SetMax(delta);
            frm.SetCaption("Đang khởi tạo ...");

            fuzzyCMean.StartPreprocessing();
            _muy_ij = fuzzyCMean.GetMembershipValues();
            numClusters = fuzzyCMean.GetListOfCluster();

            //Khoi tao
            for (f = 0; f < _table.AttibuteCount; f++)
            {
                ClusterAttribute at = new ClusterAttribute(f, 1.0f, Calculate_UXY(f), float.MinValue);
                attr.Add(at);
            }

            listOfSelAttr.Clear();
            while (k < delta)
            {
                frm.SetCaption("Chọn được " + (k + 1).ToString() + "/" + delta.ToString() + " thuộc tính.");
                frm.IncreasePercent();
                int maxJ = 0;
                attr[0].J = attr[0].R * attr[0].Weight;
                float maxJ_value = attr[0].J;
                for (f = 0; f < attr.Count; f++)
                {
                    attr[f].J = attr[f].R * attr[f].Weight;
                    if (attr[f].J > maxJ_value)
                    {
                        maxJ_value = attr[f].J;
                        maxJ = f;
                    }
                }
                listOfSelAttr.Add(attr[maxJ].attr);

                for (f = 0; f < attr.Count; f++)
                {
                    float CR = CR_ij(attr[f].attr, attr[maxJ].attr);
                    attr[f].Weight = attr[f].Weight * (1.0f + CR);
                }
                //Loai maxJ ra khoi tap thuoc tinh
                attr.RemoveAt(maxJ);
                k++;
            }
            WriteSelectedAttribute(_psoparam.FilePath + "\\SelAttr.txt");
            frm.CloseForm();
        }

        public void WriteSelectedAttribute(string filename)
        {
            StreamWriter writer = new StreamWriter(filename);
            writer.WriteLine("Number of selected attributes: " + listOfSelAttr.Count);
            for (int i = 0; i < listOfSelAttr.Count; i++)
            {
                writer.WriteLine((listOfSelAttr[i] + 1).ToString() + " ");
            }
            writer.WriteLine();
            for (int f = 0; f < _table.AttibuteCount; f++)
            {
                int i = 0;
                while (i < listOfSelAttr.Count)
                {
                    if (f == listOfSelAttr[i]) break;
                    i++;
                }
                if (i >= listOfSelAttr.Count)
                    writer.Write("0,");
                else
                    writer.Write((listOfSelAttr[i] + 1).ToString() + ",");
            }
            writer.WriteLine();
            writer.Close();
        }

    }
}
