﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PhD.FeatureSelection
{
    public class ClusterPoint
    {
        public float dataCenter;
        public float MembershipSum { get; set; }

        public ClusterPoint(float dP, float cMSum)
        {
            this.dataCenter = dP;
            this.MembershipSum = cMSum;
        }
    }

    public class DataPoint
    {
        public float dataValue;
        public int NoOccurence;
        public byte[] classLabel;

        public DataPoint(float val, int NoOcc, byte cls, int clsCount)
        {
            this.dataValue = val;
            this.NoOccurence = NoOcc;
            this.classLabel = new byte[clsCount];
            this.classLabel[cls]++;
        }
    }

    public class DataPoint2Attr
    {
        public float dataValue1;
        public float dataValue2;
        public int NoOccurence;
        public int NoOccurence1;
        public int NoOccurence2;
        public int[] classLabel;
        public int[] classLabel1;
        public int[] classLabel2;

        public DataPoint2Attr(float val1, float val2, int NoOcc, byte cls, int clsCount)
        {
            this.dataValue1 = val1;
            this.dataValue2 = val2;
            this.NoOccurence = NoOcc;
            this.NoOccurence1 = 0;
            this.NoOccurence2 = 0;
            this.classLabel = new int[clsCount];
            this.classLabel1 = new int[clsCount];
            this.classLabel2 = new int[clsCount];
            this.classLabel[cls]++;
        }
    }

    public class ClusterAttribute
    {
        public int attr;
        public float Weight;
        public float R;
        public float J;

        public ClusterAttribute(int attribute, float w, float r, float j)
        {
            attr = attribute;
            Weight = w;
            R = r;
            J = j;
        }
    }

}
