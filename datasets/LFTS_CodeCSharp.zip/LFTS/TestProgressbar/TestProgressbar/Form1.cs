﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace TestProgressbar
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmProgress frm = new frmProgress(ProgressBarStyle.Continuous);
            frm.Text = "Đang test chương trình";
            System.Threading.ThreadPool.QueueUserWorkItem(new System.Threading.WaitCallback(Test), frm);
            frm.ShowDialog(this);
        }

        private void Test(object obj)
        {
            frmProgress frm = obj as frmProgress;
            try
            {
                int n = 500;
                frm.SetMax(n);
                for (int i = 0; i < n; i++)
                {
                    frm.SetCaption("Đang test  chương trình: " + i + "/" + n);
                    System.Threading.Thread.Sleep(10);
                    frm.IncreasePercent();
                }
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                frm.CloseForm();
            }
        }
    }
}
